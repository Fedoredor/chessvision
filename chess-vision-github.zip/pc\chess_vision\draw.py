"""Отрисовка стрелки в RGBA-картинку (PIL, суперсэмплинг для сглаживания)."""

from __future__ import annotations

import math

from PIL import Image, ImageDraw

__all__ = ["render_arrow", "render_dot"]


def _unit(dx: float, dy: float) -> tuple[float, float, float]:
    length = math.hypot(dx, dy)
    if length < 1e-6:
        return 1.0, 0.0, 0.0
    return dx / length, dy / length, length


def render_arrow(p0: tuple[float, float], p1: tuple[float, float], cell: float,
                 color: tuple[int, int, int] = (255, 196, 0),
                 alpha: int = 235, ss: int = 3):
    """Рисует стрелку p0 -> p1.

    Возвращает ``(x, y, image)``: позицию и RGBA-картинку только со стрелкой.
    """
    (x0, y0), (x1, y1) = p0, p1
    ux, uy, length = _unit(x1 - x0, y1 - y0)
    if length < cell * 0.5:
        return None

    shaft = max(6.0, cell * 0.105)
    head_len = max(16.0, min(cell * 0.45, length * 0.42))
    head_w = shaft * 2.15
    pad = shaft * 2.2

    start = (x0 + ux * cell * 0.10, y0 + uy * cell * 0.10)
    tip = (x1 - ux * cell * 0.06, y1 - uy * cell * 0.06)
    base = (tip[0] - ux * head_len, tip[1] - uy * head_len)
    px, py = -uy, ux

    corners = [
        start,
        base,
        (base[0] + px * head_w / 2, base[1] + py * head_w / 2),
        tip,
        (base[0] - px * head_w / 2, base[1] - py * head_w / 2),
    ]
    xs = [c[0] for c in corners]
    ys = [c[1] for c in corners]
    x_min = math.floor(min(xs) - pad)
    y_min = math.floor(min(ys) - pad)
    x_max = math.ceil(max(xs) + pad)
    y_max = math.ceil(max(ys) + pad)
    w, h = max(1, x_max - x_min), max(1, y_max - y_min)

    img = Image.new("RGBA", (w * ss, h * ss), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    def s(p):
        return ((p[0] - x_min) * ss, (p[1] - y_min) * ss)

    outline = max(3.0, shaft * 0.55)
    head_o = outline * 1.15

    # чёрная обводка: читается и на светлых, и на тёмных клетках
    d.line([s(start), s(base)], fill=(10, 10, 10, int(alpha * 0.65)),
           width=int(round((shaft + outline * 2) * ss)))
    d.polygon([
        s(tip),
        s((base[0] + px * (head_w / 2 + head_o), base[1] + py * (head_w / 2 + head_o))),
        s((base[0] - px * (head_w / 2 + head_o), base[1] - py * (head_w / 2 + head_o))),
    ], fill=(10, 10, 10, int(alpha * 0.65)))

    # сама стрелка
    d.line([s(start), s(base)], fill=color + (alpha,), width=int(round(shaft * ss)))
    d.polygon([
        s(tip),
        s((base[0] + px * head_w / 2, base[1] + py * head_w / 2)),
        s((base[0] - px * head_w / 2, base[1] - py * head_w / 2)),
    ], fill=color + (alpha,))

    # кружок у исходной клетки
    r = max(6.0, cell * 0.19)
    box = [(start[0] - r - x_min) * ss, (start[1] - r - y_min) * ss,
           (start[0] + r - x_min) * ss, (start[1] + r - y_min) * ss]
    d.ellipse(box, outline=(10, 10, 10, int(alpha * 0.65)),
              width=int(round((shaft * 0.5 + outline) * ss)))
    d.ellipse(box, outline=color + (alpha,), width=int(round(shaft * 0.5 * ss)))

    img = img.resize((w, h), Image.LANCZOS)
    return x_min, y_min, img


def render_dot(center: tuple[float, float], radius: float,
               color: tuple[int, int, int] = (255, 196, 0), alpha: int = 200, ss: int = 3):
    """Залитый кружок (например, подсветка поля)."""
    x, y = center
    r = radius + 3
    w = h = int(math.ceil(r * 2))
    img = Image.new("RGBA", (w * ss, h * ss), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse([(r - radius) * ss, (r - radius) * ss,
               (r + radius) * ss, (r + radius) * ss],
              fill=color + (alpha,), outline=(10, 10, 10, 160), width=ss)
    return int(x - r), int(y - r), img.resize((w, h), Image.LANCZOS)
