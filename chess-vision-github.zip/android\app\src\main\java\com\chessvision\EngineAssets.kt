package com.chessvision

import android.content.Context
import java.io.File

/**
 * Где взять исполняемый файл движка.
 *
 * ВАЖНО: начиная с Android 10 (API 29) запускать файлы из data-каталога
 * приложения запрещено (SELinux, домен untrusted_app_29) — процесс падает
 * с EACCES (error=13). Поэтому бинарник лежит в jniLibs как
 * `lib/arm64-v8a/libstockfish.so`: система сама распаковывает его в
 * nativeLibraryDir, где лежит исполняемый файл с правами 755.
 */
object EngineAssets {

    fun locate(context: Context): File? {
        val native = File(context.applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (native.isFile) {
            native.setExecutable(true, false)
            return native
        }
        // запасной путь: старые прошивки, где exec из filesDir ещё разрешён
        val legacy = File(File(context.filesDir, "engine"), "stockfish")
        if (legacy.isFile) {
            legacy.setExecutable(true, false)
            return legacy
        }
        return null
    }
}
