plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.chessvision"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.chessvision"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    androidResources {
        // движок больше не в assets: он лежит в jniLibs и распаковывается системой
        noCompress += "so"
    }

    packaging {
        jniLibs {
            // обязательно: .so должны оказаться в nativeLibraryDir, откуда их
            // разрешено запускать (иначе Android 10+ даёт EACCES)
            useLegacyPackaging = true
        }
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    testImplementation("junit:junit:4.13.2")
}
