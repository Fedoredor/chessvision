package com.chessvision.core

/**
 * Рисует синтетическую доску: две темы, простые, но разные силуэты фигур.
 * Нужна, чтобы целиком проверить цепочку автоопределение -> калибровка ->
 * чтение -> трекер без доступа к настоящему chess.com.
 */
object SyntheticBoard {

    private const val CREAM = 0xFFF0E0C0.toInt()
    private const val GREEN = 0xFF88AA66.toInt()
    private const val DARK_GREEN = 0xFF3A5A2A.toInt()
    private const val BG = 0xFF1A1A1A.toInt()

    fun render(cells: IntArray, cell: Int = 80, margin: Int = 20, darkTheme: Boolean = false): Frame {
        val side = cell * 8
        val w = side + margin * 2
        val h = side + margin * 2
        val px = IntArray(w * h) { BG }
        val light = if (darkTheme) 0xFF3355AA.toInt() else CREAM
        val dark = if (darkTheme) 0xFF112244.toInt() else GREEN

        fun put(x: Int, y: Int, c: Int) {
            if (x in 0 until w && y in 0 until h) px[y * w + x] = c
        }

        for (row in 0 until 8) for (col in 0 until 8) {
            val c = if ((row + col) % 2 == 0) light else dark
            val x0 = margin + col * cell
            val y0 = margin + row * cell
            for (y in 0 until cell) for (x in 0 until cell) put(x0 + x, y0 + y, c)
        }

        for (row in 0 until 8) for (col in 0 until 8) {
            // строка 0 сверху = 8-й ранг
            val sq = (7 - row) * 8 + col
            val code = cells[sq]
            if (code == 0) continue
            val cx = margin + col * cell + cell / 2
            val cy = margin + row * cell + cell / 2
            val light0 = Piece.color(code) == Piece.WHITE
            val fill = if (light0) 0xFFF8F8F8.toInt() else 0xFF303030.toInt()
            val outline = if (light0) DARK_GREEN else 0xFFE0E0E0.toInt()
            drawPiece(::put, cx, cy, cell, Piece.type(code), fill, outline)
        }
        return Frame(w, h, px)
    }

    private fun drawPiece(put: (Int, Int, Int) -> Unit, cx: Int, cy: Int, cell: Int,
                          type: Int, fill: Int, outline: Int) {
        val r = (cell * 0.30f).toInt()
        // обводка толще заливки: рисуем контур затем фигуру
        for (pass in 0..1) {
            val color = if (pass == 0) outline else fill
            val grow = if (pass == 0) 2 else 0
            when (type) {
                Piece.PAWN -> circle(put, cx, cy + r / 4, r / 2 + grow, color)
                Piece.KNIGHT -> triangle(put, cx, cy, r + grow, color)
                Piece.BISHOP -> ellipse(put, cx, cy, (r * 0.55f).toInt() + grow, r + grow, color)
                Piece.ROOK -> rect(put, cx - r + grow, cy - r + grow, cx + r - grow, cy + r - grow, color)
                Piece.QUEEN -> {
                    circle(put, cx, cy + r / 3, r * 2 / 3 + grow, color)
                    rect(put, cx - r / 3 - grow, cy - r, cx + r / 3 + grow, cy - r / 3, color)
                }
                Piece.KING -> {
                    rect(put, cx - r + grow, cy - r / 2 + grow, cx + r - grow, cy + r - grow, color)
                    rect(put, cx - grow - 2, cy - r - grow, cx + grow + 2, cy - r / 2, color)
                    rect(put, cx - r / 2 - grow, cy - r + grow, cx + r / 2 + grow, cy - r + 4 + grow, color)
                }
            }
        }
    }

    private fun circle(put: (Int, Int, Int) -> Unit, cx: Int, cy: Int, r: Int, c: Int) {
        for (y in -r..r) for (x in -r..r) if (x * x + y * y <= r * r) put(cx + x, cy + y, c)
    }

    private fun ellipse(put: (Int, Int, Int) -> Unit, cx: Int, cy: Int, rx: Int, ry: Int, c: Int) {
        for (y in -ry..ry) for (x in -rx..rx) {
            if ((x * x).toFloat() / (rx * rx) + (y * y).toFloat() / (ry * ry) <= 1f) put(cx + x, cy + y, c)
        }
    }

    private fun rect(put: (Int, Int, Int) -> Unit, x0: Int, y0: Int, x1: Int, y1: Int, c: Int) {
        for (y in y0..y1) for (x in x0..x1) put(x, y, c)
    }

    private fun triangle(put: (Int, Int, Int) -> Unit, cx: Int, cy: Int, r: Int, c: Int) {
        for (y in 0..r) {
            val half = (r - y) * 3 / 4
            for (x in -half..half) put(cx + x, cy + r - y, c)
        }
    }
}
