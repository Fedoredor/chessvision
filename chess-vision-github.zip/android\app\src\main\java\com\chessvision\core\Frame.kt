package com.chessvision.core

/**
 * Кадр экрана: ARGB-пиксели + размеры.
 *
 * Никаких Android-классов — чтобы это ядро можно было тестировать на обычной JVM
 * (в тестах картинка читается из PNG через ImageIO).
 */
class Frame(val width: Int, val height: Int, val argb: IntArray) {

    init {
        require(argb.size >= width * height) { "массив меньше кадра" }
    }

    fun r(x: Int, y: Int): Int = (argb[y * width + x] ushr 16) and 0xFF
    fun g(x: Int, y: Int): Int = (argb[y * width + x] ushr 8) and 0xFF
    fun b(x: Int, y: Int): Int = argb[y * width + x] and 0xFF

    fun lum(x: Int, y: Int): Int {
        val p = argb[y * width + x]
        val r = (p ushr 16) and 0xFF
        val g = (p ushr 8) and 0xFF
        val b = p and 0xFF
        return (r * 77 + g * 150 + b * 29) ushr 8
    }

    /** Средний цвет прямоугольника (дробные границы, area-усреднение). */
    fun meanColor(x0: Float, y0: Float, x1: Float, y1: Float, out: IntArray) {
        val ix0 = x0.toInt().coerceIn(0, width - 1)
        val iy0 = y0.toInt().coerceIn(0, height - 1)
        val ix1 = x1.toInt().coerceIn(ix0 + 1, width)
        val iy1 = y1.toInt().coerceIn(iy0 + 1, height)
        var sr = 0L; var sg = 0L; var sb = 0L; var n = 0
        for (y in iy0 until iy1) {
            var idx = y * width + ix0
            for (x in ix0 until ix1) {
                val p = argb[idx++]
                sr += (p ushr 16) and 0xFF
                sg += (p ushr 8) and 0xFF
                sb += p and 0xFF
                n++
            }
        }
        if (n == 0) {
            out[0] = 0; out[1] = 0; out[2] = 0
            return
        }
        out[0] = (sr / n).toInt()
        out[1] = (sg / n).toInt()
        out[2] = (sb / n).toInt()
    }

    fun meanLum(x0: Float, y0: Float, x1: Float, y1: Float): Float {
        val c = IntArray(3)
        meanColor(x0, y0, x1, y1, c)
        return (c[0] * 77 + c[1] * 150 + c[2] * 29) / 256f
    }
}

/** Прямоугольник доски на экране (8x8 клеток). */
class BoardGeometry(
    var left: Float,
    var top: Float,
    var width: Float,
    var height: Float,
    var flipped: Boolean,
) {
    val cellW: Float get() = width / 8f
    val cellH: Float get() = height / 8f

    fun rect(sq: Int): FloatArray {
        val file = sq and 7
        val rank = sq ushr 3
        val col = if (flipped) 7 - file else file
        val row = if (flipped) rank else 7 - rank
        val x0 = left + col * cellW
        val y0 = top + row * cellH
        return floatArrayOf(x0, y0, x0 + cellW, y0 + cellH)
    }

    fun center(sq: Int): FloatArray {
        val r = rect(sq)
        return floatArrayOf((r[0] + r[2]) / 2f, (r[1] + r[3]) / 2f)
    }

    fun withFlipped(value: Boolean) = BoardGeometry(left, top, width, height, value)

    fun copy() = BoardGeometry(left, top, width, height, flipped)

    override fun toString(): String =
        "BoardGeometry(${left.toInt()},${top.toInt()} ${width.toInt()}x${height.toInt()} flip=$flipped)"
}
