package com.chessvision

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

/**
 * Экран настроек. Во время игры приложение уходит в фон,
 * а над доской остаётся панель со ходом и стрелка.
 */
class MainActivity : Activity() {

    private val REQ_CAPTURE = 1

    private lateinit var status: TextView
    private lateinit var overlayButton: Button
    private lateinit var startButton: Button
    private var strengthButtons = ArrayList<Button>()
    private lateinit var timeLabel: TextView
    private lateinit var timeBar: SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // отладочные команды из adb: am start ... -e cmd calibrate
        intent?.getStringExtra("cmd")?.let { cmd ->
            val svc = Intent(this, CaptureService::class.java)
            when (cmd) {
                "calibrate" -> svc.action = CaptureService.ACTION_CALIBRATE
                "join" -> svc.action = CaptureService.ACTION_JOIN
                "arrow" -> {
                    svc.action = CaptureService.ACTION_ARROW
                    svc.putExtra("from", intent.getIntExtra("from", -1))
                    svc.putExtra("to", intent.getIntExtra("to", -1))
                }
            }
            startService(svc)
            finish()
            return
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#14151C"))
            setPadding(36, 48, 36, 48)
        }

        root.addView(text("♞ Chess Vision", 26f, "#37D67A", bold = true))
        root.addView(text("Читает доску на экране и подсказывает ход. Всё локально: движок в приложении, без интернета.", 13f, "#8B90A6"))

        status = text("", 14f, "#E8EAF2")
        status.setPadding(0, 32, 0, 24)
        root.addView(status)

        overlayButton = button("Разрешить рисовать поверх окон") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        root.addView(overlayButton)

        startButton = button("Начать захват экрана") { requestCapture() }
        root.addView(startButton)

        root.addView(text("Сила", 12f, "#8B90A6").apply { setPadding(0, 36, 0, 8) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, key) in Prefs.keys().withIndex()) {
            val b = Button(this).apply {
                text = Prefs.labels()[i]
                textSize = 12f
                setOnClickListener {
                    Prefs.setStrength(this@MainActivity, key)
                    Prefs.setThinkMs(this@MainActivity, defaultThink(key))
                    refreshStrength()
                }
            }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            row.addView(b, lp)
            strengthButtons.add(b)
        }
        root.addView(row)

        timeLabel = text("", 12f, "#8B90A6").apply { setPadding(0, 28, 0, 4) }
        root.addView(timeLabel)
        timeBar = SeekBar(this).apply {
            max = 29
            progress = ((Prefs.thinkMs(this@MainActivity) - 1000) / 1000).coerceIn(0, 29)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                    val ms = (value + 1) * 1000
                    Prefs.setThinkMs(this@MainActivity, ms)
                    timeLabel.text = "Время на ход: ${ms / 1000} с"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        root.addView(timeBar)

        root.addView(text("Как пользоваться", 12f, "#8B90A6").apply { setPadding(0, 36, 0, 8) })
        root.addView(text(
            "1. Разреши рисовать поверх окон и начни захват экрана.\n" +
            "2. Открой chess.com и вернись к партии.\n" +
            "3. На плавающей панели нажми «Калибровать», когда доска в начальной позиции.\n" +
            "4. Дальше стрелка появляется сама, когда твой ход.\n" +
            "5. Начал партию с середины — нажми «Подключиться».",
            13f, "#8B90A6",
        ))

        val stop = button("Остановить") {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
            status.text = "остановлено"
        }
        stop.setPadding(0, 24, 0, 0)
        root.addView(stop)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        refreshStrength()
    }

    private fun defaultThink(key: String): Int = when (key) {
        Prefs.WEAK -> 400
        Prefs.MEDIUM -> 800
        Prefs.STRONG -> 2000
        else -> 4000
    }

    private fun refreshStrength() {
        val current = Prefs.strength(this)
        for ((i, key) in Prefs.keys().withIndex()) {
            val on = key == current
            strengthButtons[i].setBackgroundColor(if (on) Color.parseColor("#37D67A") else Color.parseColor("#242735"))
            strengthButtons[i].setTextColor(if (on) Color.parseColor("#07130C") else Color.parseColor("#E8EAF2"))
        }
        timeBar.progress = ((Prefs.thinkMs(this) - 1000) / 1000).coerceIn(0, 29)
        timeLabel.text = "Время на ход: ${Prefs.thinkMs(this) / 1000} с"
    }

    override fun onResume() {
        super.onResume()
        val canOverlay = Settings.canDrawOverlays(this)
        overlayButton.visibility = if (canOverlay) View.GONE else View.VISIBLE
        status.text = when {
            !canOverlay -> "Нужно разрешение «поверх других приложений»"
            CaptureService.alive -> "захват работает — открой chess.com"
            else -> "готово к запуску"
        }
    }

    private fun requestCapture() {
        val mgr = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, CaptureService::class.java).apply {
                action = CaptureService.ACTION_START
                putExtra(CaptureService.EXTRA_CODE, resultCode)
                putExtra(CaptureService.EXTRA_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
            else startService(intent)
            status.text = "захват запущен — открой chess.com"
        }
    }

    private fun text(value: String, size: Float, color: String, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(Color.parseColor(color))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun button(title: String, action: () -> Unit): Button =
        Button(this).apply {
            text = title
            textSize = 14f
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#242735"))
            setTextColor(Color.parseColor("#E8EAF2"))
            setOnClickListener { action() }
        }
}
