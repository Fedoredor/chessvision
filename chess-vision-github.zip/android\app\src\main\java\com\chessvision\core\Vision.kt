package com.chessvision.core

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Зрение: поиск доски и распознавание фигур.
 *
 * Порт python-версии на Kotlin, но без OpenCV: всё считается вручную на массивах.
 * Ключевая идея та же — силуэт фигуры (маска «цвет отличается от фона клетки»),
 * а не яркость, потому что белая фигура на кремовой клетке почти не отличается
 * по яркости, зато отличается по синему каналу.
 */
object Vision {

    const val CELL = 48
    const val CELL_AREA = CELL * CELL

    private const val MIN_SCORE = 0.62f
    private const val MIN_AREA = 0.07f
    private const val SHIFT = 1

    // ------------------------------------------------------------------ клетка

    class CellFeatures {
        val shape = FloatArray(CELL_AREA)
        var lum: Float = 0f
        var area: Float = 0f
        var bg = IntArray(3)
    }

    private fun downscaleCell(frame: Frame, r: FloatArray, out: FloatArrayArray) {
        // box-average в сетку CELL x CELL
        val x0 = r[0]; val y0 = r[1]; val x1 = r[2]; val y1 = r[3]
        val bw = (x1 - x0) / CELL
        val bh = (y1 - y0) / CELL
        val rr = out.r; val gg = out.g; val bb = out.b
        val tmp = IntArray(3)
        for (cy in 0 until CELL) {
            val sy0 = y0 + cy * bh
            val sy1 = sy0 + bh
            for (cx in 0 until CELL) {
                val sx0 = x0 + cx * bw
                frame.meanColor(sx0, sy0, sx0 + bw, sy1, tmp)
                val i = cy * CELL + cx
                rr[i] = tmp[0].toFloat(); gg[i] = tmp[1].toFloat(); bb[i] = tmp[2].toFloat()
            }
        }
    }

    class FloatArrayArray {
        val r = FloatArray(CELL_AREA)
        val g = FloatArray(CELL_AREA)
        val b = FloatArray(CELL_AREA)
    }

    /** Мода канала: самый частый уровень — это фон клетки. */
    private fun modeOf(ch: FloatArray): Int {
        val hist = IntArray(256)
        for (v in ch) hist[v.toInt().coerceIn(0, 255)]++
        var best = 0
        for (i in 1 until 256) if (hist[i] > hist[best]) best = i
        return best
    }

    private fun percentile99(dist: FloatArray): Float {
        val hist = IntArray(512)
        for (v in dist) hist[min(511, v.toInt())]++
        val need = (dist.size * 0.995f).toInt().coerceAtLeast(1)
        var acc = 0
        for (i in 0 until 512) {
            acc += hist[i]
            if (acc >= need) return i.toFloat()
        }
        return 511f
    }

    fun cellFeatures(frame: Frame, rect: FloatArray): CellFeatures {
        val buf = FloatArrayArray()
        downscaleCell(frame, rect, buf)
        val bg = intArrayOf(modeOf(buf.r), modeOf(buf.g), modeOf(buf.b))

        val dist = FloatArray(CELL_AREA)
        for (i in 0 until CELL_AREA) {
            val dr = abs(buf.r[i] - bg[0])
            val dg = abs(buf.g[i] - bg[1])
            val db = abs(buf.b[i] - bg[2])
            dist[i] = max(dr, max(dg, db))
        }
        val peak = percentile99(dist)
        val f = CellFeatures()
        f.bg = bg
        if (peak < 22f) return f

        val thr = max(16f, 0.12f * peak)
        val mask = ByteArray(CELL_AREA)
        var area = 0
        for (i in 0 until CELL_AREA) {
            if (dist[i] > thr) {
                mask[i] = 1
                area++
            }
        }
        if (area < CELL_AREA * 0.02f) return f

        // открытие/закрытие 3x3 — убираем тонкие линии сетки и дырки
        val m2 = morph(morph(mask, CELL, true), CELL, false)
        var area2 = 0
        for (v in m2) if (v.toInt() != 0) area2++
        if (area2 < CELL_AREA * 0.02f) return f
        f.area = area2.toFloat() / CELL_AREA

        // яркость — по «ядру» силуэта, без обводки
        val core = erode(m2, CELL)
        var hasCore = false
        for (v in core) if (v.toInt() != 0) { hasCore = true; break }
        val sel = if (hasCore) core else m2
        val lums = FloatArray(CELL_AREA)
        var n = 0
        for (i in 0 until CELL_AREA) {
            if (sel[i].toInt() != 0) {
                lums[n++] = (buf.r[i] * 77 + buf.g[i] * 150 + buf.b[i] * 29) / 256f
            }
        }
        if (n > 0) {
            lums.sort(0, n)
            f.lum = lums[n / 2]
        }

        // размытие маски, чтобы силуэт был мягким (как GaussianBlur в python)
        val blur = FloatArray(CELL_AREA)
        for (y in 0 until CELL) for (x in 0 until CELL) {
            var s = 0f; var c = 0
            for (dy in -1..1) for (dx in -1..1) {
                val yy = y + dy; val xx = x + dx
                if (yy in 0 until CELL && xx in 0 until CELL) {
                    s += m2[yy * CELL + xx].toFloat(); c++
                }
            }
            blur[y * CELL + x] = if (c > 0) s / c else 0f
        }
        System.arraycopy(blur, 0, f.shape, 0, CELL_AREA)
        return f
    }

    private fun morph(src: ByteArray, n: Int, erode: Boolean): ByteArray {
        val out = ByteArray(src.size)
        for (y in 0 until n) for (x in 0 until n) {
            var v = if (erode) 1 else 0
            for (dy in -1..1) for (dx in -1..1) {
                val yy = y + dy; val xx = x + dx
                val s = if (yy in 0 until n && xx in 0 until n) src[yy * n + xx].toInt() else 0
                v = if (erode) min(v, s) else max(v, s)
            }
            out[y * n + x] = v.toByte()
        }
        return out
    }

    private fun erode(src: ByteArray, n: Int): ByteArray {
        val out = ByteArray(src.size)
        for (y in 0 until n) for (x in 0 until n) {
            var v = 1
            for (dy in -1..1) for (dx in -1..1) {
                val yy = y + dy; val xx = x + dx
                val s = if (yy in 0 until n && xx in 0 until n) src[yy * n + xx].toInt() else 0
                v = min(v, s)
            }
            out[y * n + x] = v.toByte()
        }
        return out
    }

    // ------------------------------------------------------------------ шаблоны

    class Reader(val keys: IntArray, templates: Array<FloatArray>) {
        val unit: Array<FloatArray>

        init {
            unit = Array(templates.size) { i ->
                val t = templates[i]
                var mean = 0f
                for (v in t) mean += v
                mean /= t.size
                val c = FloatArray(t.size) { t[it] - mean }
                var norm = 0f
                for (v in c) norm += v * v
                norm = sqrt(norm)
                if (norm < 1e-6f) norm = 1f
                FloatArray(c.size) { c[it] / norm }
            }
        }

        fun similarity(shape: FloatArray, type: Int): Float {
            val idx = keys.indexOf(type)
            if (idx < 0) return 0f
            return ncc(shape, unit[idx])
        }

        /** Сохранить шаблоны, чтобы после перезапуска можно было подключаться к идущей партии. */
        fun save(file: java.io.File) {
            java.io.DataOutputStream(java.io.BufferedOutputStream(file.outputStream())).use { o ->
                o.writeInt(keys.size)
                for (i in keys.indices) {
                    o.writeInt(keys[i])
                    o.writeInt(unit[i].size)
                    for (v in unit[i]) o.writeFloat(v)
                }
            }
        }

        companion object {
            fun load(file: java.io.File): Reader? = try {
                if (!file.isFile) null else
                    java.io.DataInputStream(java.io.BufferedInputStream(file.inputStream())).use { i ->
                        val n = i.readInt()
                        val keys = IntArray(n)
                        val templates = Array(n) { FloatArray(0) }
                        for (k in 0 until n) {
                            keys[k] = i.readInt()
                            val size = i.readInt()
                            val arr = FloatArray(size)
                            for (j in 0 until size) arr[j] = i.readFloat()
                            templates[k] = arr
                        }
                        Reader(keys, templates)
                    }
            } catch (e: Exception) {
                null
            }
        }
    }

    private fun ncc(shape: FloatArray, unit: FloatArray): Float {
        var mean = 0f
        for (v in shape) mean += v
        mean /= shape.size
        var norm = 0f
        var dot = 0f
        for (i in shape.indices) {
            val c = shape[i] - mean
            norm += c * c
            dot += c * unit[i]
        }
        norm = sqrt(norm)
        return if (norm < 1e-6f) 0f else dot / norm
    }

    class ReadResult(
        val pieces: IntArray,
        val scores: FloatArray,
        val areas: FloatArray,
        val lums: FloatArray,
        val confident: BooleanArray,
        val threshold: Float,
    ) {
        val count: Int get() = confident.count { it }
        val meanScore: Float
            get() {
                var s = 0f; var n = 0
                for (i in 0 until 64) if (confident[i]) { s += scores[i]; n++ }
                return if (n == 0) 0f else s / n
            }
    }

    fun read(reader: Reader, frame: Frame, geom: BoardGeometry, ox: Float = 0f, oy: Float = 0f): ReadResult {
        val shapes = Array(64) { FloatArray(CELL_AREA) }
        val lums = FloatArray(64)
        val areas = FloatArray(64)
        val feats = Array(64) { CellFeatures() }
        for (sq in 0 until 64) {
            val r = geom.rect(sq)
            r[0] -= ox; r[2] -= ox; r[1] -= oy; r[3] -= oy
            val f = cellFeatures(frame, r)
            feats[sq] = f
            shapes[sq] = f.shape
            lums[sq] = f.lum
            areas[sq] = f.area
        }

        val scores = FloatArray(64)
        val best = IntArray(64)
        for (sq in 0 until 64) {
            var bestScore = -1f
            var bestIdx = 0
            for (k in reader.keys.indices) {
                // сдвиги ±1: сетка уточнена, но пара пикселей люфта бывает
                var s = nccShift(shapes[sq], reader.unit[k], 0, 0)
                for (dy in -SHIFT..SHIFT) for (dx in -SHIFT..SHIFT) {
                    if (dx == 0 && dy == 0) continue
                    val v = nccShift(shapes[sq], reader.unit[k], dx, dy)
                    if (v > s) s = v
                }
                if (s > bestScore) {
                    bestScore = s; bestIdx = k
                }
            }
            scores[sq] = bestScore
            best[sq] = bestIdx
        }

        val confident = BooleanArray(64) { scores[it] >= MIN_SCORE && areas[it] >= MIN_AREA }
        // порог «белая/чёрная» по Отсу на всей доске
        var thr = 150f
        val lumsSel = ArrayList<Float>()
        for (i in 0 until 64) if (confident[i]) lumsSel.add(lums[i])
        if (lumsSel.size >= 2) {
            val minL = lumsSel.min(); val maxL = lumsSel.max()
            if (maxL - minL > 60f) {
                val bins = 32
                val hist = IntArray(bins)
                for (v in lumsSel) {
                    val b = (((v - minL) / (maxL - minL)) * (bins - 1)).toInt().coerceIn(0, bins - 1)
                    hist[b]++
                }
                var bestT = 150f; var bestV = -1f
                for (i in 1 until bins) {
                    var w0 = 0; var w1 = 0
                    var s0 = 0f; var s1 = 0f
                    for (j in 0 until i) { w0 += hist[j]; s0 += hist[j] * j }
                    for (j in i until bins) { w1 += hist[j]; s1 += hist[j] * j }
                    if (w0 == 0 || w1 == 0) continue
                    val m0 = s0 / w0; val m1 = s1 / w1
                    val v = w0.toFloat() * w1 * (m1 - m0) * (m1 - m0)
                    if (v > bestV) {
                        bestV = v
                        val center = (m0 + m1) / 2f / (bins - 1)
                        bestT = minL + center * (maxL - minL)
                    }
                }
                thr = bestT
            }
        }

        val pieces = IntArray(64)
        for (sq in 0 until 64) {
            if (!confident[sq]) continue
            val type = reader.keys[best[sq]]
            val color = if (lums[sq] >= thr) Piece.WHITE else Piece.BLACK
            pieces[sq] = Piece.of(type, color)
        }
        return ReadResult(pieces, scores, areas, lums, confident, thr)
    }

    private fun nccShift(shape: FloatArray, unit: FloatArray, dx: Int, dy: Int): Float {
        var mean = 0f; var n = 0
        for (y in 0 until CELL) for (x in 0 until CELL) {
            val yy = y + dy; val xx = x + dx
            if (yy in 0 until CELL && xx in 0 until CELL) { mean += shape[yy * CELL + xx]; n++ }
        }
        if (n == 0) return 0f
        mean /= n
        var norm = 0f; var dot = 0f
        for (y in 0 until CELL) for (x in 0 until CELL) {
            val yy = y + dy; val xx = x + dx
            if (yy !in 0 until CELL || xx !in 0 until CELL) continue
            val c = shape[yy * CELL + xx] - mean
            norm += c * c
            dot += c * unit[y * CELL + x]
        }
        norm = sqrt(norm)
        return if (norm < 1e-6f) 0f else dot / norm
    }

    // ------------------------------------------------------------------ калибровка

    class Calibration(
        val reader: Reader,
        val geometry: BoardGeometry,
        val matched: Int,
        val problems: List<String>,
    ) {
        val ok: Boolean get() = matched >= 28 && problems.size <= 1
    }

    fun calibrate(frame: Frame, rect: FloatArray, ox: Float = 0f, oy: Float = 0f): Calibration {
        val start = Position.startPosition()
        var best: Calibration? = null
        for (flipped in booleanArrayOf(false, true)) {
            val geom = BoardGeometry(rect[0], rect[1], rect[2], rect[3], flipped)
            val byType = HashMap<Int, MutableList<FloatArray>>()
            for (sq in 0 until 64) {
                val code = start.cells[sq]
                if (code == 0) continue
                val r = geom.rect(sq)
                r[0] -= ox; r[2] -= ox; r[1] -= oy; r[3] -= oy
                val f = cellFeatures(frame, r)
                byType.getOrPut(Piece.type(code)) { ArrayList() }.add(f.shape)
            }
            val keys = byType.keys.sorted().toIntArray()
            val tpl = Array(keys.size) { i ->
                val list = byType[keys[i]]!!
                val avg = FloatArray(CELL_AREA)
                for (s in list) for (j in 0 until CELL_AREA) avg[j] += s[j]
                for (j in 0 until CELL_AREA) avg[j] /= list.size
                avg
            }
            val reader = Reader(keys, tpl)
            val res = read(reader, frame, geom, ox, oy)
            var matched = 0
            for (sq in 0 until 64) {
                val want = start.cells[sq]
                if (want != 0 && res.pieces[sq] == want) matched++
            }
            val problems = validateStart(byType, reader, res)
            val cand = Calibration(reader, geom, matched, problems)
            if (best == null) {
                best = cand
            } else {
                val better = (cand.problems.isEmpty() && best.problems.isNotEmpty()) ||
                        (cand.problems.isEmpty() == best.problems.isEmpty() && cand.matched > best.matched)
                if (better) best = cand
            }
        }
        return best!!
    }

    private fun validateStart(
        byType: Map<Int, List<FloatArray>>,
        reader: Reader,
        res: ReadResult,
    ): List<String> {
        val problems = ArrayList<String>()
        val total = byType.values.sumOf { it.size }
        if (total != 32) problems.add("на доске $total фигур вместо 32 — нужна начальная позиция")
        val pawns = byType[Piece.PAWN]
        if (pawns != null && pawns.size >= 8) {
            val sims = pawns.map { reader.similarity(it, Piece.PAWN) }
            val good = sims.count { it >= 0.65f }
            if (good < sims.size - 4) problems.add("пешки не похожи на начальную позицию")
        }
        val start = Position.startPosition()
        var extra = 0
        for (sq in 0 until 64) {
            if (start.cells[sq] == 0 && res.pieces[sq] != 0) extra++
        }
        if (extra > 8) problems.add("рамка сдвинута: в середине доски $extra фигур")
        else if (extra > 1) problems.add("партия уже начата — позиция не начальная")
        if (res.count < 31) problems.add("распознано меньше 31 фигуры")
        if (res.count > 0 && res.meanScore < 0.84f) problems.add("фигуры распознаны неуверенно")
        return problems
    }

    // ------------------------------------------------------------------ автоопределение

    /** Ищет доску по периодическому узору 8x8. Возвращает [x, y, w, h] или null. */
    fun autodetect(frame: Frame, maxWidth: Int = 360): FloatArray? {
        val scale = min(1f, maxWidth.toFloat() / frame.width)
        val w = max(64, (frame.width * scale).toInt())
        val h = max(64, (frame.height * scale).toInt())
        val gray = FloatArray(w * h)
        val cellPx = frame.width.toFloat() / w
        for (y in 0 until h) for (x in 0 until w) {
            gray[y * w + x] = frame.meanLum(x * cellPx, y * cellPx, (x + 1) * cellPx, (y + 1) * cellPx)
        }
        // интегральное изображение для быстрых сумм
        val ii = DoubleArray((w + 1) * (h + 1))
        for (y in 0 until h) {
            var rowSum = 0.0
            for (x in 0 until w) {
                rowSum += gray[y * w + x]
                ii[(y + 1) * (w + 1) + (x + 1)] = ii[y * (w + 1) + (x + 1)] + rowSum
            }
        }
        val box = { x: Int, y: Int, cw: Int, ch: Int ->
            val x1 = min(w, x + cw); val y1 = min(h, y + ch)
            val x0 = max(0, x); val y0 = max(0, y)
            val a = ii[y0 * (w + 1) + x0]
            val b = ii[y0 * (w + 1) + x1]
            val c = ii[y1 * (w + 1) + x0]
            val d = ii[y1 * (w + 1) + x1]
            d - b - c + a
        }

        var bestScore = 0.0
        var bestRect = FloatArray(4)
        val cMin = max(5, min(w, h) / 40)
        val cMax = min(w, h) / 8
        for (c in cMin..cMax) {
            val side = 8 * c
            if (side > w || side > h) continue
            val step = max(1, c / 2)
            var y = 0
            while (y + side <= h) {
                var x = 0
                while (x + side <= w) {
                    val sc = checkerScore(box, x, y, c)
                    if (sc > bestScore) {
                        bestScore = sc
                        bestRect = floatArrayOf(
                            (x / scale), (y / scale),
                            (side / scale), (side / scale),
                        )
                    }
                    x += step
                }
                y += step
            }
        }
        if (bestScore < 25.0) return null
        return refine(frame, bestRect)
    }

    private fun checkerScore(box: (Int, Int, Int, Int) -> Double, x: Int, y: Int, c: Int): Double {
        var sumA = 0.0; var sumB = 0.0
        for (i in 0 until 8) for (j in 0 until 8) {
            val m = box(x + j * c, y + i * c, c, c)
            if ((i + j) % 2 == 0) sumA += m else sumB += m
        }
        val area = (c * c).toDouble()
        val a = sumA / 32.0 / area
        val b = sumB / 32.0 / area
        return abs(a - b)
    }

    private fun checkerScoreAt(frame: Frame, x0: Float, y0: Float, w: Float, h: Float): Double {
        val cw = w / 8f; val ch = h / 8f
        var sumA = 0.0; var sumB = 0.0
        val tmp = IntArray(3)
        for (i in 0 until 8) for (j in 0 until 8) {
            frame.meanColor(x0 + j * cw, y0 + i * ch, x0 + (j + 1) * cw, y0 + (i + 1) * ch, tmp)
            val l = (tmp[0] * 77 + tmp[1] * 150 + tmp[2] * 29) / 256.0
            if ((i + j) % 2 == 0) sumA += l else sumB += l
        }
        val a = sumA / 32.0; val b = sumB / 32.0
        return abs(a - b)
    }

    /** Уточнение границ координатным спуском. */
    fun refine(frame: Frame, rect: FloatArray): FloatArray {
        var l = rect[0]; var t = rect[1]; var w = rect[2]; var h = rect[3]
        var best = checkerScoreAt(frame, l, t, w, h)
        var stepL = w / 40f; var stepT = h / 40f
        repeat(6) {
            var improved = false
            for (dl in intArrayOf(-1, 0, 1)) for (dt in intArrayOf(-1, 0, 1)) for (dw in intArrayOf(-1, 0, 1)) {
                val nl = l + dl * stepL
                val nt = t + dt * stepT
                val nw = w + dw * stepL * 2
                val nh = h + dw * stepT * 2
                if (nw < 100 || nh < 100) continue
                val s = checkerScoreAt(frame, nl, nt, nw, nh)
                if (s > best + 1e-4) {
                    best = s; l = nl; t = nt; w = nw; h = nh; improved = true
                }
            }
            if (!improved) {
                stepL /= 2f; stepT /= 2f
            }
        }
        return floatArrayOf(l, t, w, h)
    }

    // ------------------------------------------------------------------ здоровье доски

    /** Цвет фона по углам клетки (быстро, фигура в центре не мешает). */
    fun cornerColor(frame: Frame, rect: FloatArray, out: IntArray) {
        val x0 = rect[0]; val y0 = rect[1]; val x1 = rect[2]; val y1 = rect[3]
        val k = (min(x1 - x0, y1 - y0) * 0.18f).toInt().coerceAtLeast(3)
        val tmp = IntArray(3)
        var r = 0f; var g = 0f; var b = 0f; var n = 0
        frame.meanColor(x0 + 2, y0 + 2, x0 + 2 + k, y0 + 2 + k, tmp)
        r += tmp[0]; g += tmp[1]; b += tmp[2]; n++
        frame.meanColor(x1 - 2 - k, y0 + 2, x1 - 2, y0 + 2 + k, tmp)
        r += tmp[0]; g += tmp[1]; b += tmp[2]; n++
        frame.meanColor(x0 + 2, y1 - 2 - k, x0 + 2 + k, y1 - 2, tmp)
        r += tmp[0]; g += tmp[1]; b += tmp[2]; n++
        frame.meanColor(x1 - 2 - k, y1 - 2 - k, x1 - 2, y1 - 2, tmp)
        r += tmp[0]; g += tmp[1]; b += tmp[2]; n++
        out[0] = (r / n).toInt(); out[1] = (g / n).toInt(); out[2] = (b / n).toInt()
    }

    class Health(val covered: Int, val lightLevel: Float = 0f, val darkLevel: Float = 0f)

    /**
     * Проверка «доска видна целиком».
     *
     * Раньше смотрели только углы клетки — и пузырь чата, накрывший середину
     * клетки, не замечался. Теперь берём сетку точек по всей клетке и считаем
     * клетку «чужой», если большинство точек не похожи ни на светлый,
     * ни на тёмный цвет доски.
     */
    fun boardHealth(frame: Frame, geom: BoardGeometry): Health {
        // точки по периметру клетки: там всегда фон, а не фигура,
        // поэтому «пузырь» чата, накрывший клетку, сразу виден
        val pos = floatArrayOf(0.15f, 0.5f, 0.85f)
        val perCell = 8
        val colors = IntArray(64 * perCell * 3)
        val levels = FloatArray(64 * perCell)
        val tmp = IntArray(3)
        var n = 0
        for (sq in 0 until 64) {
            val r = geom.rect(sq)
            val w2 = r[2] - r[0]
            val h2 = r[3] - r[1]
            for (sy in pos) for (sx in pos) {
                if (sx == 0.5f && sy == 0.5f) continue
                val x = r[0] + sx * w2
                val y = r[1] + sy * h2
                frame.meanColor(x - w2 * 0.04f, y - h2 * 0.04f,
                    x + w2 * 0.04f, y + h2 * 0.04f, tmp)
                colors[n * 3] = tmp[0]; colors[n * 3 + 1] = tmp[1]; colors[n * 3 + 2] = tmp[2]
                levels[n] = (tmp[0] * 77 + tmp[1] * 150 + tmp[2] * 29) / 256f
                n++
            }
        }
        // два доминирующих уровня яркости (светлые и тёмные клетки)
        val hist = IntArray(32)
        for (i in 0 until n) hist[(levels[i] / 8f).toInt().coerceIn(0, 31)]++
        var best1 = 0
        for (i in 1 until 32) if (hist[i] > hist[best1]) best1 = i
        var best2 = -1
        for (i in 0 until 32) {
            if (kotlin.math.abs(i - best1) < 3) continue
            if (best2 < 0 || hist[i] > hist[best2]) best2 = i
        }
        if (best2 < 0) return Health(64)

        // средний ЦВЕТ для каждого уровня — так «белый пузырь» не спутать
        // с кремовой клеткой (по яркости они почти совпадают)
        fun refColor(bin: Int): IntArray {
            var r = 0L; var g = 0L; var b = 0L; var c = 0
            for (i in 0 until n) {
                if ((levels[i] / 8f).toInt().coerceIn(0, 31) != bin) continue
                r += colors[i * 3]; g += colors[i * 3 + 1]; b += colors[i * 3 + 2]; c++
            }
            if (c == 0) return intArrayOf(bin * 8, bin * 8, bin * 8)
            return intArrayOf((r / c).toInt(), (g / c).toInt(), (b / c).toInt())
        }
        val refA = refColor(best1)
        val refB = refColor(best2)

        fun near(i: Int, ref: IntArray): Boolean {
            val d = kotlin.math.abs(colors[i * 3] - ref[0]) +
                    kotlin.math.abs(colors[i * 3 + 1] - ref[1]) +
                    kotlin.math.abs(colors[i * 3 + 2] - ref[2])
            return d < 60
        }

        var covered = 0
        for (sq in 0 until 64) {
            var ok = 0
            for (k in 0 until perCell) {
                val i = sq * perCell + k
                if (near(i, refA) || near(i, refB)) ok++
            }
            if (ok < 5) covered++
        }
        return Health(covered, maxOf(best1, best2) * 8f + 4f, minOf(best1, best2) * 8f + 4f)
    }

    fun paletteOk(h: Health): Boolean =
        kotlin.math.abs(h.lightLevel - h.darkLevel) > 30f


    // ------------------------------------------------------------------ подсветка хода

    /** Поле, КУДА пришла фигура последним ходом (по подсветке хода). */
    fun lastMoveHint(frame: Frame, geom: BoardGeometry, pieces: IntArray): Int {
        val cols = Array(64) { IntArray(3) }
        val lums = FloatArray(64)
        for (sq in 0 until 64) {
            cornerColor(frame, geom.rect(sq), cols[sq])
            lums[sq] = (cols[sq][0] * 77 + cols[sq][1] * 150 + cols[sq][2] * 29) / 256f
        }
        val sorted = lums.sortedArray()
        val mid = sorted[32]
        val light = BooleanArray(64) { lums[it] > mid }
        val lightCols = (0 until 64).filter { light[it] }.map { cols[it] }
        val darkCols = (0 until 64).filter { !light[it] }.map { cols[it] }
        if (lightCols.isEmpty() || darkCols.isEmpty()) return -1
        fun median(list: List<IntArray>, ch: Int): Int {
            val v = list.map { it[ch] }.sorted()
            return v[v.size / 2]
        }
        val refL = IntArray(3) { median(lightCols, it) }
        val refD = IntArray(3) { median(darkCols, it) }
        val dev = IntArray(64)
        for (sq in 0 until 64) {
            val ref = if (light[sq]) refL else refD
            dev[sq] = abs(cols[sq][0] - ref[0]) + abs(cols[sq][1] - ref[1]) +
                    abs(cols[sq][2] - ref[2])
        }
        val cands = (0 until 64).sortedByDescending { dev[it] }.filter { dev[it] > 30 }.take(4)
        var bestScore = -1
        var bestSq = -1
        for (i in cands.indices) for (j in i + 1 until cands.size) {
            val a = cands[i]; val b = cands[j]
            val hasA = pieces[a] != 0
            val hasB = pieces[b] != 0
            if (hasA != hasB) {
                val score = dev[a] + dev[b]
                if (score > bestScore) {
                    bestScore = score
                    bestSq = if (hasB) b else a
                }
            }
        }
        return bestSq
    }
}
