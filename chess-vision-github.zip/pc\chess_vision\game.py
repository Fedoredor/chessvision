"""Ведение партии: сверка распознанной позиции с историей ходов.

Распознавание может ошибиться, поэтому каждая новая картинка проверяется
на то, что позиция получается из предыдущей одним-двумя легальными ходами.
Так мы одновременно и обновляем доску, и валидируем зрение.
"""

from __future__ import annotations

from dataclasses import dataclass

import chess

__all__ = ["Tracker", "Update", "castling_for"]


def castling_for(pieces: dict[int, chess.Piece]) -> str:
    """Права на рокировку по картинке: король и ладья на своих местах.

    Точнее с экрана не узнать, но для оценки позиции этого достаточно:
    если король и ладья стоят на исходных полях, право почти всегда есть.
    """
    rights = ""
    pairs = ((chess.E1, chess.H1, chess.KING, chess.ROOK, chess.WHITE, "K"),
             (chess.E1, chess.A1, chess.KING, chess.ROOK, chess.WHITE, "Q"),
             (chess.E8, chess.H8, chess.KING, chess.ROOK, chess.BLACK, "k"),
             (chess.E8, chess.A8, chess.KING, chess.ROOK, chess.BLACK, "q"))
    for king_sq, rook_sq, king, rook, color, letter in pairs:
        k = pieces.get(king_sq)
        r = pieces.get(rook_sq)
        if (k is not None and k.piece_type == king and k.color == color
                and r is not None and r.piece_type == rook and r.color == color):
            rights += letter
    return rights or "-"


@dataclass
class Update:
    status: str                    # same | move | resync | lost | gameover
    board: chess.Board | None = None
    move: chess.Move | None = None
    detail: str = ""

    @property
    def changed(self) -> bool:
        return self.status in ("move", "resync", "lost")


class Tracker:
    """Держит актуальную доску и умеет «догонять» пропущенные ходы."""

    MAX_PLIES = 2

    def __init__(self, player_color: bool = chess.WHITE):
        self.player_color = player_color
        self.board: chess.Board | None = None
        self.history: list[chess.Move] = []
        self.resynced = False

    # ------------------------------------------------------------------ сброс
    def reset(self, board: chess.Board | None = None) -> None:
        self.board = board if board is not None else chess.Board()
        self.history = []
        self.resynced = False

    def set_turn(self, turn: bool) -> None:
        if self.board is not None:
            self.board.turn = turn

    # ------------------------------------------------------------- наблюдение
    def observe(self, pieces: dict[int, chess.Piece],
                turn_hint: bool | None = None) -> Update:
        if self.board is None:
            return self._rebuild(pieces, "доска не была инициализирована", turn_hint)

        if self.board.is_game_over(claim_draw=False):
            if self.board.piece_map() == pieces:
                return Update("gameover", self.board, None, "партия окончена")
            return self._rebuild(pieces, "партия окончена, позиция изменилась", turn_hint)

        if self.board.piece_map() == pieces:
            return Update("same", self.board)

        # 1) обычный ход (или два подряд, если кадр пропущен)
        board = self.board.copy(stack=False)
        path: list[chess.Move] = []
        if self._dfs(board, pieces, self.MAX_PLIES, path):
            self.board = board
            self.history.extend(path)
            return Update("move" if len(path) == 1 else "resync", self.board,
                          path[-1] if path else None,
                          "" if len(path) == 1 else f"поймано {len(path)} полухода")

        # 2) очередь могла быть перепутана: пробуем отдать ход сопернику
        flipped = self.board.copy(stack=False)
        flipped.turn = not flipped.turn
        path2: list[chess.Move] = []
        if self._dfs(flipped, pieces, 1, path2):
            self.board = flipped
            self.history.extend(path2)
            self.resynced = True
            return Update("resync", self.board, path2[-1] if path2 else None,
                          "очередь хода была перепутана — исправлено")

        # 3) не сошлось: пересобираем по картинке
        return self._rebuild(pieces, "позиция не следует из предыдущей", turn_hint)

    # ------------------------------------------------------------------ поиск
    def _dfs(self, board: chess.Board, target: dict[int, chess.Piece],
             depth: int, path: list[chess.Move]) -> bool:
        if board.piece_map() == target:
            return True
        if depth == 0:
            return False
        for move in list(board.legal_moves):
            board.push(move)
            path.append(move)
            if self._dfs(board, target, depth - 1, path):
                return True
            path.pop()
            board.pop()
        return False

    def _rebuild(self, pieces: dict[int, chess.Piece], why: str,
                 turn: bool | None = None) -> Update:
        from .vision import placement_fen

        if turn is None:
            turn = self.player_color
        fen = placement_fen(pieces, turn, castling_for(pieces))
        try:
            board = chess.Board(fen)
        except ValueError:
            return Update("lost", self.board, None, f"{why}: некорректная позиция")
        self.board = board
        self.history = []
        self.resynced = True
        return Update("lost", board, None, why)

    def adopt(self, pieces: dict[int, chess.Piece], turn: bool) -> None:
        """Подключение к идущей партии: берём позицию с экрана как есть."""
        from .vision import placement_fen

        self.board = chess.Board(placement_fen(pieces, turn, castling_for(pieces)))
        self.history = []
        self.resynced = True

    # ------------------------------------------------------------------ вывод
    @property
    def my_turn(self) -> bool:
        return self.board is not None and self.board.turn == self.player_color

    @property
    def fen(self) -> str:
        return self.board.fen() if self.board else "-"
