package com.chessvision.core

import kotlin.math.abs

/**
 * Мозг приложения: кадр -> позиция -> ход движка.
 *
 * Не зависит от Android, поэтому проверяется обычными тестами.
 */
class Coach(
    private val engine: UciEngine?,
    private val log: (String) -> Unit = {},
) {
    var reader: Vision.Reader? = null
        private set
    var geometry: BoardGeometry? = null
        private set
    val tracker = Tracker { fen -> engine?.legalMoves(fen) ?: emptyList() }

    var playerColor: Int = Piece.WHITE
    var thinkMs: Int = 4000
    var threads: Int = 8
    var hashMb: Int = 1024
    var elo: Int? = null

    private var lastFen: String? = null
    private var drawnMove: String? = null
    private var lostKey: IntArray? = null
    private var lostCount = 0
    private var coveredTicks = 0
    private var resyncStreak = 0
    private var turnMismatch = 0
    private var prevPieces: IntArray? = null
    private var ticksSinceDetect = 0

    /** Есть ли шаблоны фигур (с диска или после калибровки). */
    val hasTemplates: Boolean get() = reader != null

    /** Последний удачный ответ: пока позиция не подтверждена, стрелку не трогаем. */
    private var lastGood: Result? = null

    class Result(
        val status: String = "",
        val arrowFrom: Int = -1,
        val arrowTo: Int = -1,
        val moveText: String = "",
        val evalText: String = "",
        val fen: String = "",
        val depth: Int = 0,
        val covered: Int = 0,
        val mine: Boolean = false,
    )

    val calibrated: Boolean get() = reader != null && geometry != null

    /** Файл с шаблонами фигур: переживает перезапуск приложения. */
    var templateFile: java.io.File? = null

    /** Загрузить шаблоны с диска — после этого «Подключиться» работает без калибровки. */
    fun loadTemplates(): Boolean {
        val f = templateFile ?: return false
        val r = Vision.Reader.load(f) ?: return false
        reader = r
        log("шаблоны фигур загружены")
        return true
    }

    // ------------------------------------------------------------- калибровка

    fun calibrate(frame: Frame): Result {
        val rect = Vision.autodetect(frame)
            ?: return Result(status = "доска не найдена — обведите вручную")
        val cal = Vision.calibrate(frame, rect)
        if (!cal.ok) {
            val why = cal.problems.joinToString("; ").ifEmpty { "позиция не начальная" }
            log("калибровка не прошла: $why")
            return Result(status = "калибровка: $why")
        }
        reader = cal.reader
        geometry = cal.geometry
        playerColor = if (cal.geometry.flipped) Piece.BLACK else Piece.WHITE
        tracker.playerColor = playerColor
        try {
            templateFile?.let { cal.reader.save(it) }
        } catch (e: Exception) {
            log("шаблоны не сохранились: ${e.message}")
        }
        tracker.reset()
        lastFen = null
        drawnMove = null
        lostKey = null
        lostCount = 0
        prevPieces = null
        lastGood = null
        log("калибровка ок: ${cal.matched}/32, ${if (cal.geometry.flipped) "чёрные" else "белые"} снизу")
        return Result(status = "доска готова")
    }

    fun setGeometry(rect: FloatArray, flipped: Boolean) {
        geometry = BoardGeometry(rect[0], rect[1], rect[2], rect[3], flipped)
    }

    fun join(frame: Frame): Result {
        // шаблоны могли остаться с прошлого раза — тогда калибровка не нужна
        val r = reader ?: return Result(status = "сначала калибровка (начальная позиция)")
        // доска могла не находиться: ищем её прямо сейчас
        val g = geometry ?: run {
            val rect = Vision.autodetect(frame) ?: return Result(status = "доска не найдена")
            val gm = BoardGeometry(rect[0], rect[1], rect[2], rect[3], playerColor == Piece.BLACK)
            geometry = gm
            log("доска найдена при подключении")
            gm
        }
        val health = Vision.boardHealth(frame, g)
        if (health.covered > 6) {
            return Result(status = "доска перекрыта (${health.covered} клеток)",
                covered = health.covered)
        }
        val res = Vision.read(r, frame, g)
        if (res.count < 10) return Result(status = "не читается позиция")

        val hintSq = Vision.lastMoveHint(frame, g, res.pieces)
        val turn = when {
            hintSq >= 0 && res.pieces[hintSq] != 0 ->
                Piece.color(res.pieces[hintSq]) == Piece.BLACK
            else -> playerColor == Piece.WHITE
        }
        tracker.adopt(res.pieces, turn)
        lastFen = null
        drawnMove = null
        lostKey = null
        lostCount = 0
        prevPieces = null
        lastGood = null
        log("подключился: ход ${if (turn) "белых" else "чёрных"}, фигур ${res.count}")
        return Result(status = "подключился", fen = tracker.fen, mine = turn == (playerColor == Piece.WHITE))
    }

    // ------------------------------------------------------------------ такт

    fun tick(frame: Frame): Result {
        val r = tickInternal(frame)
        if (r.arrowFrom >= 0) lastGood = r
        return r
    }

    private fun tickInternal(frame: Frame): Result {
        var g = geometry ?: return Result(status = "нет калибровки")
        val r = reader ?: return Result(status = "нет калибровки")

        // Доска на экране «ездит»: чат тренера растёт и сдвигает её.
        // Поэтому раз в ~4 секунды (и когда чтение подозрительное) перепроверяем
        // положение доски заново — иначе программа слепнет и советует наугад.
        ticksSinceDetect++
        if (ticksSinceDetect >= 8) {
            ticksSinceDetect = 0
            val rect = Vision.autodetect(frame)
            if (rect != null && (kotlin.math.abs(rect[0] - g.left) > 4f ||
                        kotlin.math.abs(rect[1] - g.top) > 4f ||
                        kotlin.math.abs(rect[2] - g.width) > 4f)) {
                val moved = Vision.refine(frame, rect) ?: rect
                g = BoardGeometry(moved[0], moved[1], moved[2], moved[3], g.flipped)
                geometry = g
                prevPieces = null
                log("доска сдвинулась — пересчитал положение")
            }
        }

        val health = Vision.boardHealth(frame, g)
        if (health.covered > 6 || !Vision.paletteOk(health)) {
            coveredTicks++
            return Result(status = "доска перекрыта (${health.covered})", covered = health.covered)
        }
        coveredTicks = 0

        val res = Vision.read(r, frame, g)

        // мало фигур — почти наверняка промахнулись по доске, ищем заново
        if (res.count < 20) {
            val rect = Vision.autodetect(frame)
            if (rect != null) {
                val moved = Vision.refine(frame, rect) ?: rect
                val ng = BoardGeometry(moved[0], moved[1], moved[2], moved[3], g.flipped)
                if (kotlin.math.abs(ng.left - g.left) > 3f || kotlin.math.abs(ng.top - g.top) > 3f) {
                    geometry = ng
                    prevPieces = null
                    log("перепроверил доску: фигур было ${res.count}")
                    return Result(status = "пересчитываю доску…", fen = tracker.fen)
                }
            }
        }
        val hintSq = Vision.lastMoveHint(frame, g, res.pieces)
        val hint: Boolean? = if (hintSq >= 0 && res.pieces[hintSq] != 0) {
            Piece.color(res.pieces[hintSq]) == Piece.BLACK
        } else null

        // Позиция принимается только если совпала на двух кадрах подряд:
        // иначе стрелка «мигает» и очередь хода прыгает.
        val stable = prevPieces != null && prevPieces!!.contentEquals(res.pieces)
        prevPieces = res.pieces.copyOf()
        if (!stable) {
            return lastGood ?: Result(status = "читаю позицию…", fen = tracker.fen)
        }

        val before = tracker.position?.cells?.copyOf()
        val upd = tracker.observe(res.pieces, hint)

        if (upd.status == Status.LOST && before != null) {
            if (lostKey != null && lostKey!!.contentEquals(res.pieces)) {
                lostCount++
            } else {
                lostKey = res.pieces.copyOf()
                lostCount = 1
            }
            if (lostCount < 4) {
                tracker.position?.cells?.let { System.arraycopy(before, 0, it, 0, 64) }
                return Result(status = "…", fen = tracker.fen)
            }
            lostKey = null
            lostCount = 0
            log("пересобрал позицию: ${upd.detail}")
        } else {
            lostKey = null
            lostCount = 0
        }

        val pos = tracker.position ?: return Result(status = "нет позиции")
        if (pos.kingSquare(Piece.WHITE) < 0 || pos.kingSquare(Piece.BLACK) < 0) {
            return Result(status = "позиция не распознана", fen = tracker.fen)
        }

        // Подсветка последнего хода — самый надёжный источник «чей ход».
        // ВАЖНО: раньше её применяли только когда она «за нас», и очередь
        // залипала на «ход соперника». Теперь она задаёт очередь всегда.
        if (hint != null) tracker.position?.whiteToMove = hint
        val mine = pos.whiteToMove == (playerColor == Piece.WHITE)
        if (!mine) {
            lastFen = null
            drawnMove = null
            return Result(status = "ход соперника", fen = tracker.fen, mine = false)
        }

        val fen = pos.fen()
        if (fen == lastFen && drawnMove != null) {
            return arrowOf(drawnMove!!, status = "готово", fen = fen, mine = true)
        }

        val eng = engine ?: return Result(status = "движок не готов", fen = fen, mine = true)
        if (!eng.running) {
            try {
                eng.start(threads, hashMb, elo)
            } catch (e: Exception) {
                return Result(status = "движок не запустился: ${e.message}", fen = fen)
            }
        }
        val ana = eng.analyse(fen, thinkMs, multipv = 1)
        val best = ana.best ?: return Result(status = "движок не дал хода", fen = fen, mine = true)

        lastFen = fen
        drawnMove = best
        log("ход ${fmtMove(best)} ${ana.scoreText}")
        val res2 = arrowOf(best, status = "", fen = fen, mine = true)
        return Result(
            status = res2.status, arrowFrom = res2.arrowFrom, arrowTo = res2.arrowTo,
            moveText = fmtMove(best), evalText = ana.scoreText, fen = fen,
            depth = ana.depth, covered = 0, mine = true,
        )
    }

    private fun arrowOf(uci: String, status: String, fen: String, mine: Boolean): Result {
        if (uci.length < 4) return Result(status = status, fen = fen, mine = mine)
        val from = sq(uci.substring(0, 2))
        val to = sq(uci.substring(2, 4))
        return Result(
            status = status, arrowFrom = from, arrowTo = to,
            moveText = fmtMove(uci), fen = fen, mine = mine,
        )
    }

    private fun fmtMove(uci: String): String {
        if (uci.length < 4) return uci
        val base = "${uci.substring(0, 2)}-${uci.substring(2, 4)}"
        return if (uci.length == 5) base + uci[4].uppercase() else base
    }

    private fun sq(s: String): Int = (s[1] - '1') * 8 + (s[0] - 'a')

    /** Оценка в сантипешках для полоски преимущества. */
    fun evalToProb(cp: Int?): Float {
        val v = (cp ?: 0).toDouble() / 100.0
        return (1.0 / (1.0 + Math.pow(10.0, -v / 4.0))).toFloat()
    }

    fun absEval(cp: Int?): Int = cp?.let { abs(it) } ?: 0
}
