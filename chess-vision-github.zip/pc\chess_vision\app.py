"""Приложение Chess Vision: панель управления + рабочий поток зрения и движка."""

from __future__ import annotations

import json
import os
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk

import chess
import cv2
import numpy as np

from . import vision
from .engine import PRESETS, PRESET_ORDER, Analysis, ChessEngine
from .game import Tracker, Update
from .geometry import BoardGeometry
from .overlay import ALT_COLOR, MAIN_COLOR, ArrowOverlay
from .screen import ScreenCapture, enable_dpi_awareness, virtual_screen

APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.path.join(APP_DIR, "config.json")
TEMPLATES_PATH = os.path.join(APP_DIR, "templates.npz")
DEBUG_DIR = os.path.join(APP_DIR, "debug")

DEFAULTS = {
    "geometry": None,
    "engine": None,
    "think_ms": 1500,
    "auto": True,
    "autoplay": False,
    "show_alt": False,
    "play_as": "white",
    "strength": "max",
    "window": None,
    "compact": False,
}

BG = "#14151c"        # фон окна
CARD = "#1d1f29"      # карточки
CARD2 = "#242735"     # поля ввода/неактивные кнопки
BORDER = "#2c3040"
FG = "#e8eaf2"
DIM = "#8b90a6"
GREEN = "#37d67a"
YELLOW = "#ffc400"
RED = "#ff6b6b"
BLUE = "#5aa0ff"


def plural(n: int, one: str, few: str, many: str) -> str:
    """2 потока / 5 потоков — чтобы не было «2 потоков»."""
    n = abs(int(n)) % 100
    if 11 <= n <= 19:
        return many
    n %= 10
    if n == 1:
        return one
    if 2 <= n <= 4:
        return few
    return many


# --------------------------------------------------------------------- конфиг
def load_config() -> dict:
    cfg = dict(DEFAULTS)
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            cfg.update(json.load(f))
    except (OSError, ValueError):
        pass
    return cfg


def save_config(cfg: dict) -> None:
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


# ------------------------------------------------------------ рабочий поток
class VisionWorker(threading.Thread):
    """Всё, что трогает экран, движок и оверлей, живёт здесь (свой поток)."""

    def __init__(self, cfg: dict, events: queue.Queue):
        super().__init__(daemon=True, name="vision")
        self.events = events
        self.cmds: queue.Queue = queue.Queue()
        self.stop = threading.Event()

        self.cfg = dict(cfg)
        self.capture: ScreenCapture | None = None
        self.engine = ChessEngine(cfg.get("engine"), cfg.get("strength", "max"))
        self.overlay: ArrowOverlay | None = None
        self.reader: vision.PieceReader | None = None
        self.geom: BoardGeometry | None = None
        self.tracker: Tracker | None = None

        self.auto = bool(cfg.get("auto"))
        self.autoplay = bool(cfg.get("autoplay"))
        self.show_alt = bool(cfg.get("show_alt"))
        self.think = max(0.1, cfg.get("think_ms", 800) / 1000.0)
        self.interval = 0.32

        self._last_fen: str | None = None
        self._last_moves: list = []
        self._last_tick = 0.0
        self._excl: bool | None = None
        self._busy = False
        self._autoplay_cooldown = 0.0
        self._game_over = False
        self._lost_key = None
        self._lost_count = 0
        self._bad_reads = 0
        self._pending_fen = None
        self._drawn_key = None
        self._prev_pieces = None
        self._resync_streak = 0
        self._drawn_move = None
        self._covered_ticks = 0
        self._turn_mismatch = 0
        # CHESSVISION_NO_EXCLUDE=1 — не исключать оверлей из скриншотов
        self._no_exclude = bool(os.environ.get("CHESSVISION_NO_EXCLUDE"))

    # ------------------------------------------------------------------ API
    def send(self, cmd: str, arg=None) -> None:
        self.cmds.put((cmd, arg))

    def emit(self, kind: str, payload=None) -> None:
        self.events.put((kind, payload))

    # ---------------------------------------------------------------- поток
    def run(self) -> None:
        enable_dpi_awareness()
        try:
            self.capture = ScreenCapture()
        except Exception as exc:  # pragma: no cover
            self.emit("error", f"не удалось получить доступ к экрану: {exc}")
            return
        try:
            self.overlay = ArrowOverlay()
        except Exception as exc:  # pragma: no cover
            self.emit("error", f"не удалось создать оверлей: {exc}")
        if not self.engine.available:
            self.emit("error", "Stockfish не найден: положите stockfish*.exe в папку engine")
        self._restore_calibration()
        self.emit("ready", None)
        self.emit("engine_info", self.engine.info)
        try:
            while not self.stop.is_set():
                try:
                    cmd, arg = self.cmds.get(timeout=0.05)
                except queue.Empty:
                    cmd = None
                if cmd:
                    try:
                        self.handle(cmd, arg)
                    except Exception as exc:  # pragma: no cover
                        import traceback
                        self.emit("error", f"{cmd}: {exc}")
                        self.emit("log", traceback.format_exc(limit=3).replace("\n", " | "))
                now = time.monotonic()
                if (self.auto and self.geom is not None and not self._busy
                        and now - self._last_tick >= self.interval
                        and now >= self._autoplay_cooldown):
                    try:
                        self.tick(force=False)
                    except Exception:  # pragma: no cover
                        import traceback
                        self.emit("error", "сбой авто-режима (см. журнал)")
                        self.emit("log", traceback.format_exc(limit=3).replace("\n", " | "))
                        self._last_tick = now + 1.0
        finally:
            self.engine.close()
            if self.overlay:
                self.overlay.close()
            if self.capture:
                self.capture.close()

    # -------------------------------------------------------------- команды
    def handle(self, cmd: str, arg) -> None:
        if cmd == "calibrate":
            self.do_calibrate(arg)
        elif cmd == "autodetect":
            self.do_autodetect()
        elif cmd == "analyze":
            self.tick(force=True)
        elif cmd == "join":
            self.do_join()
        elif cmd == "show":
            self.do_show()
        elif cmd == "flip":
            if self.geom is not None:
                self.geom = self.geom.with_flipped(not self.geom.flipped)
                self._last_fen = None
                self._drawn_key = None
                self._prev_pieces = None
                self._excl = None
                if self.tracker is not None:
                    self.tracker.player_color = (
                        chess.BLACK if self.geom.flipped else chess.WHITE)
                self.emit("geometry", self.geom.to_dict())
                self.emit("log", f"доска перевёрнута: {'чёрные' if self.geom.flipped else 'белые'} снизу")
                self.tick(force=True)
        elif cmd == "clear":
            self.clear()
        elif cmd == "auto":
            self.auto = bool(arg)
            self.emit("auto", self.auto)
        elif cmd == "autoplay":
            self.autoplay = bool(arg)
            if not self.autoplay:
                self._autoplay_cooldown = 0.0
        elif cmd == "alt":
            self.show_alt = bool(arg)
        elif cmd == "think":
            self.think = max(0.1, float(arg) / 1000.0)
        elif cmd == "strength":
            self.engine.set_profile(str(arg))
            self.think = max(0.1, PRESETS[self.engine.profile]["ms"] / 1000.0)
            self._last_fen = None
            self.emit("engine_info", self.engine.info)
            th = PRESETS[self.engine.profile]["threads"] or self.engine.info["threads"]
            self.emit("log", f"сила: {PRESETS[self.engine.profile]['title']} "
                             f"({th} {plural(th, 'поток', 'потока', 'потоков')}, "
                             f"{self.engine.info['hash']} МБ)")
            self.tick(force=True)
        elif cmd == "reset":
            self.reset_game()
        elif cmd == "turn":
            if self.tracker and self.tracker.board is not None:
                self.tracker.set_turn(not self.tracker.board.turn)
                self._last_fen = None
                self.tick(force=True)
        elif cmd == "play_as":
            if self.tracker:
                self.tracker.player_color = chess.WHITE if arg == "white" else chess.BLACK
                self._last_fen = None
                self.tick(force=True)
        elif cmd == "quit":
            self.stop.set()

    # ------------------------------------------------- переезд доски
    def _retry_geometry(self) -> bool:
        """Доска может переехать или измениться в размере (окно, зум, скролл).

        Шаблоны фигур от этого не портятся — достаточно заново найти рамку.
        Принимаем новую рамку только если позиция читается уверенно.
        """
        if self.reader is None:
            return False
        shot, ox, oy = self.capture.grab_full()
        cands = vision.autodetect_candidates(shot, (ox, oy), limit=4)
        best = None
        for score, left, top, w, h in cands:
            # ориентацию НЕ трогаем: она определяется калибровкой и меняется
            # только кнопкой ⇄. Иначе «переезд доски» незаметно переворачивал всё
            g = BoardGeometry(left, top, w, h, self.geom.flipped)
            res = self.reader.read(shot, g, (ox, oy))
            if len(res.pieces) < 20 or not res.confident.any():
                continue
            board = res.as_board(self.tracker.player_color if self.tracker else True)
            if board.king(chess.WHITE) is None or board.king(chess.BLACK) is None:
                continue
            quality = res.mean_score * len(res.pieces)
            if res.mean_score < 0.80:
                continue
            if best is None or quality > best[0]:
                best = (quality, g, res.mean_score, len(res.pieces))
        if best is None:
            return False
        self.geom = best[1]
        self._last_fen = None
        self._drawn_key = None
        self._prev_pieces = None
        self._excl = None
        self._resync_streak = 0
        self.emit("geometry", best[1].to_dict())
        self.emit("log", f"доска переехала — рамка подхвачена заново "
                         f"({best[1].width:.0f}px, фигур {best[3]})")
        return True

    # ------------------------------------------------------------ калибровка
    def _restore_calibration(self) -> None:
        """Подхватывает шаблоны и рамку доски, сохранённые в прошлый раз."""
        geo = self.cfg.get("geometry")
        if not geo or not os.path.exists(TEMPLATES_PATH):
            return
        try:
            self.reader = vision.PieceReader.load(TEMPLATES_PATH)
            self.geom = BoardGeometry.from_dict(geo)
            player = chess.BLACK if self.geom.flipped else chess.WHITE
            self.tracker = Tracker(player)
            self.tracker.reset()
            self.emit("log", "калибровка восстановлена из прошлого запуска")
            self.emit("restored", {"flipped": self.geom.flipped,
                                   "rect": (self.geom.left, self.geom.top,
                                            self.geom.width, self.geom.height)})
        except Exception as exc:  # pragma: no cover
            self.emit("log", f"калибровка не восстановлена: {exc}")

    def _turn_hint(self, shot, res, origin) -> bool | None:
        """Чей ход — по подсветке последнего хода chess.com."""
        if self.geom is None:
            return None
        try:
            dst = vision.last_move_hint(shot, self.geom, res.pieces, origin)
        except Exception:
            return None
        if dst is None:
            return None
        piece = res.pieces.get(dst)
        return None if piece is None else (not piece.color)

    def do_join(self) -> None:
        """Подключиться к уже начатой партии (нужны шаблоны фигур)."""
        if self.reader is None or self.geom is None:
            self.emit("error", "нет шаблонов фигур — начните новую партию и нажмите F8 один раз")
            return
        shot, ox, oy = self.capture.grab_full()
        health = vision.board_health(shot, self.geom, (ox, oy))
        if health["covered"] > 6:
            self.emit("error", f"доска перекрыта другим окном ({health['covered']} клеток) — "
                               f"подвиньте его и повторите Ctrl+F8")
            return
        res = self.reader.read(shot, self.geom, (ox, oy))
        if len(res.pieces) < 12 and self._retry_geometry():
            shot, ox, oy = self.capture.grab_full()
            res = self.reader.read(shot, self.geom, (ox, oy))
        if len(res.pieces) < 12:
            self.emit("error", "не получается прочитать позицию — проверьте доску (F8)")
            return

        hint = self._turn_hint(shot, res, (ox, oy))
        turn = hint if hint is not None else (
            chess.BLACK if self.geom.flipped else chess.WHITE)
        if self.tracker is None:
            self.tracker = Tracker(chess.BLACK if self.geom.flipped else chess.WHITE)
        self.tracker.adopt(res.pieces, turn)
        self.auto = True
        self._last_fen = None
        self._drawn_key = None
        self._prev_pieces = res.pieces
        self._resync_streak = 0
        self.emit("joined", {
            "fen": self.tracker.board.fen(),
            "turn": "белые" if turn == chess.WHITE else "чёрные",
            "by_hint": hint is not None,
            "pieces": len(res.pieces),
        })
        self.emit("auto", True)
        self.emit("log", f"подключился к партии: ход {'белых' if turn else 'чёрных'}, "
                         f"фигур {len(res.pieces)}")
        self.tick(force=True)

    def do_show(self) -> None:
        """Сохранить картинку «что программа видит» и открыть её."""
        if self.geom is None or self.reader is None:
            self.emit("error", "сначала определите доску (F8)")
            return
        shot, ox, oy = self.capture.grab_full()
        l = max(0, int(self.geom.left - ox))
        t = max(0, int(self.geom.top - oy))
        w, h = int(self.geom.width), int(self.geom.height)
        crop = shot[t:t + h, l:l + w].copy()
        if crop.size == 0:
            return
        g = BoardGeometry(0, 0, w, h, self.geom.flipped)
        res = self.reader.read(shot, self.geom, (ox, oy))
        health = vision.board_health(shot, self.geom, (ox, oy))
        img = vision.annotate(crop, g, res, (0, 0))
        cv2.putText(img, f"covered={health['covered']}  pieces={len(res.pieces)}",
                    (8, h - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 4, cv2.LINE_AA)
        cv2.putText(img, f"covered={health['covered']}  pieces={len(res.pieces)}",
                    (8, h - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 1, cv2.LINE_AA)
        os.makedirs(DEBUG_DIR, exist_ok=True)
        path = os.path.join(DEBUG_DIR, "read_now.png")
        cv2.imwrite(path, img)
        self.emit("open_file", path)

    def do_autodetect(self) -> None:
        shot, ox, oy = self.capture.grab_full()
        cands = vision.autodetect_candidates(shot, (ox, oy), limit=5)
        # сначала пробуем уже известную рамку: чаще всего доска не двигалась
        if self.geom is not None:
            cands.insert(0, (99.0, int(self.geom.left), int(self.geom.top),
                             int(self.geom.width), int(self.geom.height)))
        if not cands:
            self.emit("autodetect", None)
            self.emit("manual_needed", None)
            return
        self.emit("autodetect", cands[-1] if self.geom is not None else cands[0])
        # проверяем гипотезы по очереди: калибровка сама отбракует неверные
        for score, left, top, w, h in cands:
            cal = vision.calibrate(shot, left, top, w, h, (ox, oy))
            if cal.ok:
                self.calibrate_from_shot(shot, (ox, oy), left, top, w, h, auto=True, cal=cal)
                return
        sc, left, top, w, h = cands[0]
        self.calibrate_from_shot(shot, (ox, oy), left, top, w, h, auto=True)

    def do_calibrate(self, rect) -> None:
        left, top, w, h = rect
        self._calibrate_rect(left, top, w, h, auto=False)

    def _calibrate_rect(self, left, top, w, h, auto: bool) -> None:
        """До трёх попыток: анимация хода или перерисовка могут испортить кадр."""
        shot = origin = cal = None
        for attempt in range(3):
            shot, ox, oy = self.capture.grab_full()
            origin = (ox, oy)
            cal = vision.calibrate(shot, left, top, w, h, origin)
            if cal.ok:
                break
            if attempt < 2:
                time.sleep(0.22)
        assert cal is not None and shot is not None
        self.calibrate_from_shot(shot, origin, left, top, w, h, auto=auto, cal=cal)

    def calibrate_from_shot(self, shot, origin, left, top, w, h,
                            auto: bool = False, cal=None) -> None:
        if cal is None:
            cal = vision.calibrate(shot, left, top, w, h, origin)
        if not cal.ok:
            diff = []
            res = cal.reader.read(shot, cal.geometry, origin)
            for sq, p in chess.Board().piece_map().items():
                if res.pieces.get(sq) != p:
                    diff.append(chess.square_name(sq))
            sims = [cal.reader.similarity(s, chess.PAWN)
                    for s in (cal.samples.get(chess.PAWN) or [])]
            if sims and min(sims) < 0.65:
                self.emit("log", f"пешки похожи лишь на {min(sims):.2f} — "
                                 f"калибровка не годится")
            self.emit("calibrated", {
                "ok": False, "matched": cal.matched, "total": cal.total,
                "problems": cal.problems, "flipped": cal.geometry.flipped,
                "rect": (left, top, w, h), "auto": auto, "diff": diff,
            })
            return

        self.reader = cal.reader
        self.geom = cal.geometry
        self._last_fen = None
        self._last_moves = []
        self._excl = None
        try:
            cal.reader.save(TEMPLATES_PATH)
        except OSError as exc:
            self.emit("log", f"шаблоны не сохранены: {exc}")

        res = cal.reader.read(shot, cal.geometry, origin)
        player = chess.BLACK if cal.geometry.flipped else chess.WHITE
        self.tracker = Tracker(player)
        self.tracker.reset(chess.Board())
        upd = self.tracker.observe(res.pieces)
        self.emit("calibrated", {
            "ok": True, "matched": cal.matched, "total": cal.total,
            "problems": [], "flipped": cal.geometry.flipped,
            "rect": (left, top, w, h), "player": player,
            "mismatch": None if upd.status == "same" else upd.detail,
        })
        self._save_debug(shot, origin, res)

    def _save_debug(self, shot, origin, res) -> None:
        try:
            os.makedirs(DEBUG_DIR, exist_ok=True)
            ox, oy = origin
            l = int(self.geom.left - ox)
            t = int(self.geom.top - oy)
            s = int(max(self.geom.width, self.geom.height))
            crop = shot[max(0, t):t + s, max(0, l):l + s].copy()
            g = BoardGeometry(0, 0, self.geom.width, self.geom.height, self.geom.flipped)
            img = vision.annotate(crop, g, res, (0, 0))
            cv2.imwrite(os.path.join(DEBUG_DIR, "calibration.png"), img)
            self.emit("log", f"снимок калибровки: {DEBUG_DIR}\\calibration.png")
        except Exception as exc:  # pragma: no cover
            self.emit("log", f"отладка не сохранена: {exc}")

    def reset_game(self) -> None:
        if self.tracker:
            self.tracker.reset(chess.Board())
        self._last_fen = None
        self.clear()

    # ------------------------------------------------------------------ такт
    def tick(self, force: bool = False) -> None:
        if self.geom is None or self.reader is None or self.tracker is None:
            if force:
                self.emit("error", "сначала определите доску (F8)")
            return
        self._busy = True
        self._last_tick = time.monotonic()
        try:
            self._tick_inner(force)
        finally:
            self._busy = False

    def _tick_inner(self, force: bool) -> None:
        g = self.geom
        pad = 0
        cx = int(np.floor(g.left)) - pad
        cy = int(np.floor(g.top)) - pad
        cw = int(np.ceil(g.width)) + 2 * pad + 1
        ch = int(np.ceil(g.height)) + 2 * pad + 1

        excl = self._excl
        if excl is None:
            excl = self._check_exclusion((cx, cy, cw, ch))
            self._excl = excl
        if not excl:
            self.overlay.hide()
            time.sleep(0.02)

        shot = self.capture.grab(cx, cy, cw, ch)

        # если доску накрыло чужое окно, читать её бессмысленно:
        # фигур не видно, и любая «позиция» будет выдумкой
        health = vision.board_health(shot, g, (cx, cy))
        if health["covered"] > 6 or not vision.board_palette_ok(health):
            self._covered_ticks += 1
            if self._covered_ticks in (2, 20):
                self.emit("error",
                          f"доска перекрыта другим окном ({health['covered']} клеток) — "
                          f"подвиньте окно, которое её закрывает")
            if self.overlay.visible and self._covered_ticks > 2:
                self.overlay.hide()
            return
        self._covered_ticks = 0

        res = self.reader.read(shot, g, (cx, cy))

        # Одиночный кадр не доверяем: во время перерисовки браузера, анимации
        # хода или перетаскивания фигуры картинка на миг «врёт». Позиция
        # принимается только если совпала на двух кадрах подряд.
        if not force:
            if self._prev_pieces is not None and res.pieces != self._prev_pieces:
                self._prev_pieces = res.pieces
                return
        self._prev_pieces = res.pieces

        before = self.tracker.board.copy(stack=False) if self.tracker.board else None
        upd: Update = self.tracker.observe(res.pieces, self._turn_hint(shot, res, (cx, cy)))

        if upd.status == "lost" and before is not None:
            # «мусорный» кадр (анимация, перерисовка) не должен ломать партию:
            # пересобираем доску, только если мусор повторился несколько раз
            if self._lost_key == res.pieces:
                self._lost_count += 1
            else:
                self._lost_key = res.pieces
                self._lost_count = 1
            if self._lost_count < 4:
                self.tracker.board = before
                return
            self._lost_key = None
            self._lost_count = 0
            self.emit("warning", upd.detail)
        else:
            self._lost_key = None
            self._lost_count = 0
        if upd.status == "resync" and upd.detail:
            self.emit("log", upd.detail)

        # несколько пересборок подряд без единого распознанного хода —
        # почти наверняка рамка сбилась, а не «сложная позиция»
        if upd.status in ("move", "same"):
            self._resync_streak = 0
        elif upd.status in ("resync", "lost"):
            self._resync_streak += 1
            if self._resync_streak >= 3 and self._retry_geometry():
                self._resync_streak = 0
                return
        board = self.tracker.board
        if board is None:
            return

        # защита от «пустого» распознавания: доска без королей — это не позиция,
        # а сбитая калибровка (сменился масштаб окна, доска уехала)
        if board.king(chess.WHITE) is None or board.king(chess.BLACK) is None:
            self._bad_reads += 1
            if self._bad_reads == 2 and self._retry_geometry():
                self._bad_reads = 0
                return
            if self._bad_reads in (4, 15):
                self.emit("error", "доска не распознаётся — нажмите F8 и обведите доску заново")
                self.emit("auto", False)
                self.auto = False
            return
        self._bad_reads = 0

        self.emit("board", {
            "fen": board.fen(),
            "turn": "белые" if board.turn == chess.WHITE else "чёрные",
            "mine": board.turn == self.tracker.player_color,
            "n": len(res.pieces),
        })

        if board.is_game_over(claim_draw=False):
            self.clear()
            if not self._game_over:
                self._game_over = True
                self.emit("gameover", board.result(claim_draw=False))
            return
        self._game_over = False

        if board.turn != self.tracker.player_color:
            # если подсветка последнего хода уверенно говорит, что ход наш,
            # значит очередь в трекере сбилась — исправляем сами
            hint = self._turn_hint(shot, res, (cx, cy))
            if hint is not None and hint == self.tracker.player_color:
                self._turn_mismatch += 1
                if self._turn_mismatch >= 3:
                    self.tracker.set_turn(self.tracker.player_color)
                    self._turn_mismatch = 0
                    self.emit("log", "очередь хода исправлена по подсветке")
                    self._last_fen = None
                    return
            else:
                self._turn_mismatch = 0
            if self.overlay.visible:
                self.overlay.hide()
            self._last_moves = []
            self._last_fen = None
            self._drawn_key = None
            self.emit("waiting", "ход соперника")
            return
        self._turn_mismatch = 0

        fen = board.fen()
        if not force and self.auto and fen != self._last_fen:
            # подтверждаем смену позиции вторым кадром: одиночный «дрожащий»
            # кадр не должен перерисовывать стрелку (иначе она мерцает)
            if self._pending_fen != fen:
                self._pending_fen = fen
                return
        self._pending_fen = None

        if not force and fen == self._last_fen and self._last_moves:
            if not excl or not self.overlay.visible:
                self.overlay.draw(g, self._last_moves)
            return

        ana = self.engine.analyse(board, self.think)
        if ana.best is None or ana.best not in board.legal_moves:
            self.emit("error", f"движок не дал хода: {ana.score_text}")
            return

        best = ana.best
        # если прежний ход всё ещё почти так же хорош — не дёргаем стрелку
        # (e4 +0.22 и d4 +0.26 равноценны, а глаз видит «мерцание»)
        prev = self._drawn_move
        if prev is not None and prev != best and prev in board.legal_moves:
            for line in ana.lines[:3]:
                if line.move == prev:
                    cp_now = ana.cp if ana.cp is not None else (9999 * (1 if (ana.mate or 0) > 0 else -1))
                    cp_prev = line.cp if line.cp is not None else (9999 * (1 if (line.mate or 0) > 0 else -1))
                    if abs(cp_prev - cp_now) <= 8:
                        best = prev
                    break
        san = board.san(best) if best != ana.best else ana.san

        moves = [(best, MAIN_COLOR)]
        if self.show_alt and len(ana.lines) > 1:
            moves.append((ana.lines[1].move, ALT_COLOR, 140))
        key = (fen, tuple(m[0].uci() for m in moves))
        if key != self._drawn_key:
            # перерисовываем только когда реально меняется ход — иначе стрелка мерцает
            self.overlay.draw(g, moves)
            self._drawn_key = key
            self._drawn_move = best
            self.emit("log", f"стрелка: {san} {ana.score_text}")
        self._last_fen = fen
        self._last_moves = moves
        self.emit("analysis", ana)

        if self.autoplay and upd.status in ("same", "move"):
            # двигаем мышью только когда позиция уверенно опознана
            self._autoplay(best)
            self._last_fen = None
            self._autoplay_cooldown = time.monotonic() + 0.6

    # ------------------------------------------------------------ автоигра
    def _autoplay(self, move: chess.Move) -> None:
        try:
            from pynput.mouse import Button, Controller
        except Exception as exc:  # pragma: no cover
            self.emit("error", f"pynput недоступен: {exc}")
            return
        g = self.geom
        assert g is not None
        p0 = g.square_center(move.from_square)
        p1 = g.square_center(move.to_square)
        mouse = Controller()
        mouse.position = (p0[0], p0[1])
        time.sleep(0.08)
        mouse.press(Button.left)
        time.sleep(0.06)
        for k in range(1, 11):
            mouse.position = (p0[0] + (p1[0] - p0[0]) * k / 10.0,
                              p0[1] + (p1[1] - p0[1]) * k / 10.0)
            time.sleep(0.012)
        time.sleep(0.06)
        mouse.release(Button.left)
        piece = self.tracker.board.piece_at(move.from_square) if self.tracker.board else None
        promo = chess.square_rank(move.to_square) in (0, 7)
        if promo and piece is not None and piece.piece_type == chess.PAWN:
            time.sleep(0.35)
            mouse.position = (p1[0], p1[1] - g.cell * 1.15)
            time.sleep(0.05)
            mouse.click(Button.left)
        self.emit("log", f"авто-ход: {move.uci()}")

    # -------------------------------------------------------------- оверлей
    def clear(self) -> None:
        if self.overlay:
            self.overlay.hide()
        self._last_moves = []
        self._last_fen = None
        self._drawn_key = None

    def _check_exclusion(self, rect) -> bool:
        """Проверяет, что оверлей не попадает в скриншот (иначе мигаем)."""
        if self._no_exclude:
            return False
        cx, cy, cw, ch = rect
        self.overlay.hide()
        time.sleep(0.05)
        a = self.capture.grab(cx, cy, cw, ch)
        ok = self.overlay.exclude_from_capture(True)
        probe = BoardGeometry(cx + cw * 0.25, cy + ch * 0.25, cw * 0.5, ch * 0.5)
        self.overlay.draw(probe, [(chess.Move.from_uci("a1h8"), (255, 0, 255))])
        time.sleep(0.10)
        b = self.capture.grab(cx, cy, cw, ch)
        self.overlay.hide()
        if a.shape != b.shape:
            return False
        diff = float(np.abs(a.astype(np.int16) - b.astype(np.int16)).mean())
        works = ok and diff < 1.0
        self.emit("log", f"оверлей исключён из захвата: {'да' if works else 'нет'} "
                         f"(разница {diff:.2f})")
        return works


# ------------------------------------------------------------ выбор области
class RegionSelector:
    """Полноэкранный слой, где мышью обводится доска."""

    def __init__(self, root: tk.Tk, on_done):
        self.on_done = on_done
        vx, vy, vw, vh = virtual_screen()
        self.vx, self.vy = vx, vy
        self.top = tk.Toplevel(root)
        self.top.overrideredirect(True)
        self.top.attributes("-topmost", True)
        self.top.attributes("-alpha", 0.35)
        self.top.configure(bg="black")
        self.top.geometry(f"{vw}x{vh}+{vx}+{vy}")
        self.canvas = tk.Canvas(self.top, bg="black", highlightthickness=0,
                                cursor="crosshair", width=vw, height=vh)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.create_text(vw // 2, 40, fill="#9fe6a0",
                                font=("Segoe UI", 20, "bold"),
                                text="Обведите шахматную доску мышью — Enter подтвердить, Esc отмена")
        self.start = None
        self.rect_id = None
        self.canvas.bind("<ButtonPress-1>", self._press)
        self.canvas.bind("<B1-Motion>", self._drag)
        self.canvas.bind("<ButtonRelease-1>", self._release)
        self.top.bind("<Return>", self._confirm)
        self.top.bind("<Escape>", self._cancel)
        self.top.bind("<Double-Button-1>", self._confirm)
        self.top.focus_force()
        self.box = None
        self.finished = False

    def _press(self, e):
        self.start = (e.x, e.y)
        if self.rect_id:
            self.canvas.delete(self.rect_id)
        self.rect_id = self.canvas.create_rectangle(e.x, e.y, e.x, e.y,
                                                    outline=GREEN, width=3)

    def _drag(self, e):
        if self.start and self.rect_id:
            self.canvas.coords(self.rect_id, self.start[0], self.start[1], e.x, e.y)

    def _release(self, e):
        if not self.start:
            return
        x0, y0 = self.start
        x1, y1 = e.x, e.y
        left, top = min(x0, x1), min(y0, y1)
        side = min(abs(x1 - x0), abs(y1 - y0))
        if side >= 160:
            self.box = (left + self.vx, top + self.vy, side, side)
            self.canvas.create_text(left + side // 2, top + side // 2, fill=GREEN,
                                    font=("Segoe UI", 13, "bold"),
                                    text=f"{side}x{side} — Enter")

    def _confirm(self, _e=None):
        if self.finished:
            return
        if not self.box:
            return
        self.finished = True
        box = self.box
        self.top.destroy()
        self.on_done(box)

    def _cancel(self, _e=None):
        if self.finished:
            return
        self.finished = True
        self.top.destroy()
        self.on_done(None)


# ------------------------------------------------------------------- окно
class App:
    def __init__(self) -> None:
        enable_dpi_awareness()
        self.cfg = load_config()
        self.events: queue.Queue = queue.Queue()
        self.ui_events: queue.Queue = queue.Queue()
        self.worker = VisionWorker(self.cfg, self.events)
        self.worker.start()
        self.game_over_shown = False

        self.root = tk.Tk()
        self.root.title("Chess Vision")
        self.root.configure(bg=BG)
        self.root.resizable(True, True)
        self.root.minsize(330, 240)
        self.root.attributes("-topmost", True)
        self.compact = False
        self._bar_p = 0.5
        self._auto_on = bool(self.cfg.get("auto"))
        self._play_on = bool(self.cfg.get("autoplay"))
        self._time_job = None
        self._cfg_job = None
        self._saved_geom = None
        self._saved_size = (440, 680)
        self._build_ui()
        self._restore_window()
        self._start_hotkeys()
        self.root.protocol("WM_DELETE_WINDOW", self._quit)
        self.root.after(60, self._pump)
        self._banner("Нажмите F8, чтобы определить доску")

    # ------------------------------------------------------------------ UI
    def _build_ui(self) -> None:
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TCheckbutton", background=BG, foreground=FG,
                        font=("Segoe UI", 9))
        style.map("TCheckbutton", background=[("active", BG)])
        style.configure("TCombobox", font=("Segoe UI", 9))

        root = self.root
        for r, w in ((0, 0), (1, 0), (2, 4), (3, 0), (4, 3)):
            root.grid_rowconfigure(r, weight=w)
        root.grid_columnconfigure(0, weight=1)

        # ---------------------------------------------------------- заголовок
        head = tk.Frame(root, bg=BG)
        head.grid(row=0, column=0, sticky="ew", padx=12, pady=(10, 0))
        tk.Label(head, text="♞", bg=BG, fg=GREEN,
                 font=("Segoe UI", 14, "bold")).pack(side="left")
        tk.Label(head, text="Chess Vision", bg=BG, fg=FG,
                 font=("Segoe UI", 12, "bold")).pack(side="left", padx=(7, 0))
        self.btn_compact = self._ghost(head, "▾", self.toggle_compact, size=12, pad=4)
        self.btn_compact.pack(side="right")
        self.lbl_engine = tk.Label(head, text="…", bg=BG, fg=DIM,
                                   font=("Segoe UI", 8))
        self.lbl_engine.pack(side="right", padx=(0, 8))

        # ------------------------------------------------------------- статус
        self.lbl_state = tk.Label(root, text="", bg=BG, fg=FG, justify="left",
                                  anchor="w", wraplength=380, font=("Segoe UI", 9))
        self.lbl_state.grid(row=1, column=0, sticky="ew", padx=12, pady=(3, 7))
        self._auto_wrap(self.lbl_state)

        # ------------------------------------------------- карточка с ходом
        self.card = tk.Frame(root, bg=CARD, highlightbackground=BORDER,
                             highlightthickness=1)
        self.card.grid(row=2, column=0, sticky="nsew", padx=12, pady=(0, 8))
        self.card.grid_columnconfigure(0, weight=1)
        self.card.grid_rowconfigure(3, weight=1)

        top = tk.Frame(self.card, bg=CARD)
        top.grid(row=0, column=0, sticky="ew", padx=12, pady=(10, 0))
        self.lbl_best = tk.Label(top, text="—", bg=CARD, fg=FG,
                                 font=("Segoe UI", 21, "bold"))
        self.lbl_best.pack(side="left")
        self.lbl_eval = tk.Label(top, text="", bg=CARD, fg=YELLOW,
                                 font=("Consolas", 15, "bold"))
        self.lbl_eval.pack(side="right")

        self.bar = tk.Canvas(self.card, height=10, bg=CARD, highlightthickness=0, bd=0)
        self.bar.grid(row=1, column=0, sticky="ew", padx=12, pady=(7, 5))
        self.bar.bind("<Configure>", lambda e: self._draw_bar(self._bar_p))

        self.lbl_meta = tk.Label(self.card, text="", bg=CARD, fg=DIM, anchor="w",
                                 font=("Segoe UI", 8))
        self.lbl_meta.grid(row=2, column=0, sticky="ew", padx=12)

        self.lbl_lines = tk.Label(self.card, text="", bg=CARD, fg=DIM, justify="left",
                                  anchor="nw", font=("Consolas", 9))
        self.lbl_lines.grid(row=3, column=0, sticky="nsew", padx=12, pady=(6, 10))

        # ------------------------------------------------------------ органы
        self.ctl = tk.Frame(root, bg=BG)
        self.ctl.grid(row=3, column=0, sticky="ew", padx=12)
        self.ctl.grid_columnconfigure(0, weight=1)
        self.ctl.grid_columnconfigure(1, weight=1)

        self.btn_cal = self._flat(self.ctl, "Определить доску  F8", self.calibrate, True)
        self.btn_cal.grid(row=0, column=0, sticky="ew", padx=(0, 4), pady=2)
        self.btn_an = self._flat(self.ctl, "Анализ  F9", self.analyze)
        self.btn_an.grid(row=0, column=1, sticky="ew", padx=(4, 0), pady=2)

        srow = tk.Frame(self.ctl, bg=BG)
        srow.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        tk.Label(srow, text="сила", bg=BG, fg=DIM, width=5, anchor="w",
                 font=("Segoe UI", 8)).pack(side="left")
        seg = tk.Frame(srow, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
        seg.pack(side="left", fill="x", expand=True)
        self.seg: dict[str, tk.Button] = {}
        for key in PRESET_ORDER:
            b = tk.Button(seg, text=PRESETS[key]["title"], relief="flat", bd=0,
                          bg=CARD, fg=DIM, activebackground=CARD2,
                          activeforeground=FG, font=("Segoe UI", 9),
                          cursor="hand2", pady=4,
                          command=lambda k=key: self.set_strength(k))
            b.pack(side="left", fill="x", expand=True)
            self.seg[key] = b

        trow = tk.Frame(self.ctl, bg=BG)
        trow.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        tk.Label(trow, text="время", bg=BG, fg=DIM, width=5, anchor="w",
                 font=("Segoe UI", 8)).pack(side="left")
        self.var_think = tk.IntVar(value=int(self.cfg.get("think_ms", 1500)))
        tk.Scale(trow, from_=500, to=30000, resolution=500, orient="horizontal",
                 variable=self.var_think, command=self._time_moved,
                 bg=BG, fg=DIM, troughcolor=CARD2, highlightthickness=0, bd=0,
                 showvalue=False, sliderrelief="flat", activebackground=GREEN,
                 length=120).pack(side="left", fill="x", expand=True)
        self.lbl_time = tk.Label(trow, text="", bg=BG, fg=FG, width=6, anchor="e",
                                 font=("Consolas", 9))
        self.lbl_time.pack(side="right")

        tgl = tk.Frame(self.ctl, bg=BG)
        tgl.grid(row=3, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        self.btn_auto = self._chip(tgl, "Авто  Ctrl+F11", self.toggle_auto)
        self.btn_auto.pack(side="left", padx=(0, 5))
        self.btn_play = self._chip(tgl, "Авто-ход  Ctrl+F12", self.toggle_autoplay)
        self.btn_play.pack(side="left", padx=(0, 5))
        self.btn_alt = self._chip(tgl, "2-й вариант", self.toggle_alt)
        self.btn_alt.pack(side="left")

        small = tk.Frame(self.ctl, bg=BG)
        small.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(5, 0))
        self.btn_join = tk.Button(
            small, text="подключиться", command=self.join_game, relief="flat",
            bg=BG, fg=GREEN, bd=0, activebackground=BG, activeforeground=GREEN,
            cursor="hand2", font=("Segoe UI", 8, "bold"))
        self.btn_join.pack(side="left", padx=(0, 10))
        for text, cmd in (("вручную ⇧F8", self.calibrate_manual),
                          ("очередь ⇧F9", self.switch_turn),
                          ("сброс", self.reset)):
            tk.Button(small, text=text, command=cmd, relief="flat", bg=BG, fg=DIM,
                      activebackground=BG, activeforeground=FG, bd=0,
                      cursor="hand2", font=("Segoe UI", 8)).pack(side="left", padx=(0, 10))
        self.btn_color = tk.Button(
            small, command=self._toggle_color, relief="flat", bg=BG, fg=DIM, bd=0,
            activebackground=BG, activeforeground=FG, cursor="hand2",
            font=("Segoe UI", 8),
            text=f"играю: {'чёрные' if self.cfg.get('play_as') == 'black' else 'белые'}")
        self.btn_color.pack(side="right")
        tk.Button(small, text="⇄", command=self.toggle_flip, relief="flat", bg=BG,
                  fg=DIM, activebackground=BG, activeforeground=FG, bd=0,
                  cursor="hand2", font=("Segoe UI", 10)).pack(side="right", padx=(0, 6))

        # ------------------------------------------------- FEN и журнал
        self.bottom = tk.Frame(root, bg=BG)
        self.bottom.grid(row=4, column=0, sticky="nsew", padx=12, pady=(6, 10))
        self.bottom.grid_columnconfigure(0, weight=1)
        self.bottom.grid_rowconfigure(1, weight=1)

        self.lbl_fen = tk.Label(self.bottom, text="", bg=BG, fg=DIM, justify="left",
                                anchor="w", font=("Consolas", 8))
        self.lbl_fen.grid(row=0, column=0, sticky="ew", pady=(0, 3))
        self._auto_wrap(self.lbl_fen)

        self.log = tk.Text(self.bottom, height=4, bg="#0f1016", fg=DIM,
                           insertbackground=FG, relief="flat", bd=0,
                           font=("Consolas", 8), wrap="word", padx=6, pady=4)
        self.log.grid(row=1, column=0, sticky="nsew")
        self.log.configure(state="disabled")

        # ------------------------------------------------- компактный вид
        self.compact_lbl = tk.Label(root, text="—", bg=BG, fg=FG,
                                    font=("Segoe UI", 20, "bold"))
        self.compact_lbl.bind("<Double-Button-1>", lambda e: self.toggle_compact())
        self._refresh_seg()
        self._refresh_chips()
        self._time_moved(self.var_think.get())

    # --------------------------------------------------------- мелкие детали
    def _auto_wrap(self, lbl: tk.Label, pad: int = 30) -> None:
        lbl.bind("<Configure>",
                 lambda e: lbl.configure(wraplength=max(140, e.width - pad)))

    def _ghost(self, parent, text, cmd, size=10, pad=6):
        b = tk.Button(parent, text=text, command=cmd, relief="flat", bd=0, bg=BG,
                      fg=DIM, activebackground=BG, activeforeground=FG,
                      font=("Segoe UI", size), cursor="hand2", padx=pad)
        b.bind("<Enter>", lambda e: b.configure(fg=FG))
        b.bind("<Leave>", lambda e: b.configure(fg=DIM))
        return b

    def _flat(self, parent, text, cmd, primary=False):
        bg = GREEN if primary else CARD2
        fg = "#07130c" if primary else FG
        hover = "#4ae58c" if primary else "#2f3345"
        b = tk.Button(parent, text=text, command=cmd, relief="flat", bd=0, bg=bg, fg=fg,
                      activebackground=hover, activeforeground=fg,
                      font=("Segoe UI", 9, "bold" if primary else "normal"),
                      cursor="hand2", pady=6)
        b.bind("<Enter>", lambda e: b.configure(bg=hover))
        b.bind("<Leave>", lambda e: b.configure(bg=bg))
        return b

    def _chip(self, parent, text, cmd):
        b = tk.Button(parent, text=text, command=cmd, relief="flat", bd=0, bg=CARD2,
                      fg=FG, activebackground=CARD, activeforeground=FG,
                      font=("Segoe UI", 8), cursor="hand2", padx=8, pady=4)
        return b

    def _refresh_chips(self) -> None:
        for btn, on in ((self.btn_auto, self._auto_on), (self.btn_play, self._play_on),
                        (self.btn_alt, bool(self.cfg.get("show_alt")))):
            btn.configure(bg=GREEN if on else CARD2, fg="#07130c" if on else FG,
                          activebackground="#4ae58c" if on else CARD)

    def _refresh_seg(self) -> None:
        active = self.cfg.get("strength", "max")
        for key, btn in self.seg.items():
            on = key == active
            btn.configure(bg=CARD2 if on else CARD, fg=FG if on else DIM,
                          activebackground=CARD2, font=("Segoe UI", 9, "bold" if on else "normal"))

    def _draw_bar(self, p: float) -> None:
        self._bar_p = p
        c = self.bar
        c.delete("all")
        w = max(20, c.winfo_width())
        h = max(6, c.winfo_height())
        c.create_rectangle(0, 0, w, h, fill="#282b3a", outline="")
        mid = w / 2.0
        off = (max(0.0, min(1.0, p)) - 0.5) * w
        if off >= 0:
            c.create_rectangle(mid, 0, mid + off, h, fill=GREEN, outline="")
        else:
            c.create_rectangle(mid + off, 0, mid, h, fill=RED, outline="")
        c.create_line(mid, 0, mid, h, fill="#14151c", width=1)

    # ------------------------------------------------------- окно и компакт
    def _restore_window(self) -> None:
        win = self.cfg.get("window")
        if win and len(win) == 4 and win[2] > 200 and win[3] > 200:
            self.root.geometry(f"{int(win[2])}x{int(win[3])}+{int(win[0])}+{int(win[1])}")
        else:
            self.root.geometry("440x680")
            self.root.update_idletasks()
            self._place_window()
        self.root.bind("<Configure>", self._on_configure)
        if self.cfg.get("compact"):
            self.compact = True
            self._apply_compact()

    def _on_configure(self, event) -> None:
        if event.widget is not self.root:
            return
        if self._cfg_job:
            self.root.after_cancel(self._cfg_job)
        self._cfg_job = self.root.after(700, self._save_window)

    def _save_window(self) -> None:
        self._cfg_job = None
        if self.compact or self.root.state() != "normal":
            return
        self.cfg["window"] = [self.root.winfo_x(), self.root.winfo_y(),
                              self.root.winfo_width(), self.root.winfo_height()]
        save_config(self.cfg)

    def toggle_compact(self) -> None:
        self.compact = not self.compact
        self.cfg["compact"] = self.compact
        save_config(self.cfg)
        try:
            self._apply_compact()
            self._log("свернул" if self.compact else "развернул")
        except Exception as exc:  # pragma: no cover
            self._log(f"компакт не сработал: {exc}")

    def _apply_compact(self) -> None:
        parts = [self.lbl_state, self.card, self.ctl, self.bottom]
        if self.compact:
            self._save_window()
            self._saved_size = (max(360, self.root.winfo_width()),
                                max(300, self.root.winfo_height()))
            for w in parts:
                w.grid_remove()
            self.compact_lbl.grid(row=1, column=0, sticky="nsew", padx=14, pady=(2, 8))
            self.root.minsize(280, 78)
            self.root.geometry("340x96")
            self.btn_compact.configure(text="▴")
        else:
            self.compact_lbl.grid_remove()
            for w in parts:
                w.grid()
            self.root.minsize(330, 240)
            w, h = getattr(self, "_saved_size", (440, 680))
            self.root.geometry(f"{w}x{h}")
            self.btn_compact.configure(text="▾")

    # -------------------------------------------------------------- события
    def _place_window(self, avoid: tuple | None = None) -> None:
        """Ставит панель в угол, который не накрывает доску."""
        self.root.update_idletasks()
        w = max(self.root.winfo_width(), 330)
        h = max(self.root.winfo_height(), 240)
        vx, vy, vw, vh = virtual_screen()
        corners = [
            (vx + vw - w - 12, vy + vh - h - 60),
            (vx + 12, vy + vh - h - 60),
            (vx + vw - w - 12, vy + 12),
            (vx + 12, vy + 12),
        ]
        target = corners[0]
        if avoid is not None:
            bl, bt, bw, bh = avoid
            m = 14
            cx0, cy0 = self.root.winfo_x(), self.root.winfo_y()
            cur_overlap = not (cx0 + w + m < bl or cx0 > bl + bw + m
                               or cy0 + h + m < bt or cy0 > bt + bh + m)
            if not cur_overlap:
                return  # текущее место доску не закрывает — не трогаем
            for cx, cy in corners:
                overlap = not (cx + w + m < bl or cx > bl + bw + m
                               or cy + h + m < bt or cy > bt + bh + m)
                if not overlap:
                    target = (cx, cy)
                    break
            else:
                # все углы заняты — берём самый далёкий от доски
                bcx, bcy = bl + bw / 2, bt + bh / 2
                target = max(corners, key=lambda c: (c[0] + w / 2 - bcx) ** 2
                             + (c[1] + h / 2 - bcy) ** 2)
        self.root.geometry(f"+{int(target[0])}+{int(target[1])}")

    def _banner(self, text: str, color: str = FG) -> None:
        self.lbl_state.configure(text=text, fg=color)

    def _log(self, text: str) -> None:
        self.log.configure(state="normal")
        self.log.insert("end", time.strftime("%H:%M:%S ") + text + "\n")
        self.log.see("end")
        lines = int(self.log.index("end-1c").split(".")[0])
        if lines > 300:
            self.log.delete("1.0", "50.0")
        self.log.configure(state="disabled")

    def _pump(self) -> None:
        """UI-поток: разбираем события рабочего потока и команды хоткеев."""
        while True:
            try:
                kind, payload = self.events.get_nowait()
            except queue.Empty:
                break
            self._handle_event(kind, payload)
        while True:
            try:
                cmd = self.ui_events.get_nowait()
            except queue.Empty:
                break
            cmd()
        self.root.after(60, self._pump)

    def _handle_event(self, kind: str, payload) -> None:
        if kind == "ready":
            name = self.worker.engine.name
            self.lbl_engine.configure(text=name if len(name) <= 26 else name[:25] + "…")
        elif kind == "engine_info":
            th = payload["threads"]
            self.lbl_engine.configure(
                text=f"{th} {plural(th, 'поток', 'потока', 'потоков')} · "
                     f"{payload['hash']} МБ")
            self.cfg["strength"] = payload["profile"]
            self._refresh_seg()
        elif kind == "restored":
            side = "чёрными" if payload.get("flipped") else "белыми"
            self._banner(f"Доска восстановлена, играю {side}. F9 — анализ.", GREEN)
            self.root.after(60, lambda: self._place_window(tuple(payload["rect"])))
        elif kind == "geometry":
            self.cfg["geometry"] = payload
            save_config(self.cfg)
            self.root.after(60, lambda: self._place_window(
                (payload["left"], payload["top"], payload["width"], payload["height"])))
        elif kind == "joined":
            src = "чьей ход — по подсветке" if payload.get("by_hint") else "ход угадан"
            self._banner(f"Подключился к партии: ход {payload['turn']} ({src}). "
                         f"Авто включено — стрелка появится сама.", GREEN)
            self._log(f"подключение: {payload['fen']}")
        elif kind == "open_file":
            self._log(f"снимок распознавания: {payload}")
            try:
                os.startfile(payload)  # noqa: S606 - открыть картинку в просмотрщике
            except Exception as exc:
                self._log(f"не открылось: {exc}")
        elif kind == "error":
            self._banner(f"⚠ {payload}", RED)
            self._log(f"ошибка: {payload}")
        elif kind == "warning":
            self._log(f"внимание: {payload}")
        elif kind == "log":
            self._log(str(payload))
        elif kind == "autodetect":
            if payload:
                self._log(f"доска найдена автоматически (score {payload[0]:.2f})")
            else:
                self._log("автоопределение не удалось, обведите доску вручную")
        elif kind == "manual_needed":
            self.root.after(400, self.calibrate_manual)
        elif kind == "calibrated":
            self._on_calibrated(payload)
        elif kind == "board":
            turn = "ваш ход" if payload["mine"] else "ход соперника"
            self.lbl_fen.configure(
                text=f"{payload['fen']}\n{turn}, фигур: {payload['n']}")
        elif kind == "waiting":
            self._banner(f"{payload} — думаю только на своём ходу", DIM)
        elif kind == "gameover":
            self._banner(f"Партия окончена: {payload}", YELLOW)
            self._log(f"партия окончена: {payload}")
        elif kind == "analysis":
            self._on_analysis(payload)
        elif kind == "auto":
            self._auto_on = bool(payload)
            self._refresh_chips()
            self._log("авто-режим " + ("вкл" if payload else "выкл"))

    def _on_calibrated(self, data: dict) -> None:
        if not data.get("ok"):
            matched = data.get("matched", 0)
            total = data.get("total", 32)
            probs = "; ".join(data.get("problems") or [])
            if "начат" in probs or "вместо 32" in probs or matched < 28:
                self._banner(
                    f"Партия уже идёт ({matched} из {total} фигур на стартовых полях), "
                    f"а для калибровки нужна начальная позиция. Начните новую партию "
                    f"с ботом и нажмите F8.", RED)
            else:
                self._banner(f"Калибровка не удалась: {probs}. Если доска точно "
                             f"в начале — обведите её вручную (⇧F8).", RED)
            self._log(f"калибровка: {matched}/{total} ({probs})")
            if data.get("diff"):
                self._log("не сошлось на полях: " + ", ".join(data["diff"][:12]))
            return
        side = "чёрными" if data.get("flipped") else "белыми"
        self._banner(f"Доска готова. Играю {side}. Жмите F9 или включите авто.", GREEN)
        self._log(f"калибровка ок: {data['matched']}/{data['total']}, {side}, "
                  f"rect={tuple(round(v) for v in data['rect'])}")
        self.root.after(50, lambda: self._place_window(tuple(data["rect"])))
        self.cfg["geometry"] = BoardGeometry(*data["rect"],
                                             data["flipped"]).to_dict()
        self.cfg["play_as"] = "black" if data.get("flipped") else "white"
        self.btn_color.configure(
            text=f"играю: {'чёрные' if data.get('flipped') else 'белые'}")
        save_config(self.cfg)
        self.game_over_shown = False

    def _on_analysis(self, ana: Analysis) -> None:
        cp = ana.cp if ana.cp is not None else (4000 if (ana.mate or 0) > 0 else -4000)
        self.lbl_best.configure(text=ana.san)
        self.lbl_eval.configure(text=ana.score_text, fg=GREEN if cp >= 0 else RED)
        strength = PRESETS.get(self.cfg.get("strength", "max"), {}).get("title", "?")
        self.lbl_meta.configure(
            text=f"{strength} · глубина {ana.depth} · {ana.elapsed:.2f} с")
        lines = []
        for i, ln in enumerate(ana.lines[:3], 1):
            lines.append(f"{i}. {ln.san:<6} {ln.score_text}")
        if ana.pv_san:
            lines.append("   " + " ".join(ana.pv_san[:6]))
        self.lbl_lines.configure(text="\n".join(lines))
        self._draw_bar(1.0 / (1.0 + 10 ** (-cp / 400.0)))
        self.compact_lbl.configure(text=f"{ana.san}   {ana.score_text}")
        self._banner(f"Лучший ход: {ana.san}   {ana.score_text}", GREEN)

    # ---------------------------------------------------------------- команды
    def calibrate(self) -> None:
        self._banner("Ищу доску на экране…", DIM)
        self.worker.send("autodetect")

    def calibrate_manual(self) -> None:
        RegionSelector(self.root, self._region_selected)

    def _region_selected(self, box) -> None:
        if not box:
            self._banner("Выбор доски отменён", DIM)
            return
        self._banner("Снимаю шаблоны фигур…", DIM)
        self.root.after(180, lambda: self.worker.send("calibrate", box))

    def analyze(self) -> None:
        self.worker.send("analyze")

    def join_game(self) -> None:
        self._banner("Подключаюсь к текущей позиции…", DIM)
        self.worker.send("join")

    def show_read(self) -> None:
        self._banner("Смотрю, что видит программа…", DIM)
        self.worker.send("show")

    def clear(self) -> None:
        self.worker.send("clear")
        self.lbl_eval.configure(text="—", fg=DIM)
        self.lbl_best.configure(text="—")
        self.lbl_lines.configure(text="")
        self.lbl_meta.configure(text="")
        self.compact_lbl.configure(text="—")
        self._draw_bar(0.5)

    def toggle_auto(self) -> None:
        self._auto_on = not self._auto_on
        self.cfg["auto"] = self._auto_on
        save_config(self.cfg)
        self._refresh_chips()
        self.worker.send("auto", self._auto_on)

    def toggle_autoplay(self) -> None:
        self._play_on = not self._play_on
        self.cfg["autoplay"] = self._play_on
        save_config(self.cfg)
        self._refresh_chips()
        self.worker.send("autoplay", self._play_on)

    def toggle_alt(self) -> None:
        self.cfg["show_alt"] = not self.cfg.get("show_alt", False)
        save_config(self.cfg)
        self._refresh_chips()
        self.worker.send("alt", self.cfg["show_alt"])

    # ---------------------------------------------------------- сила и время
    def set_strength(self, key: str) -> None:
        if key not in PRESETS:
            return
        self.cfg["strength"] = key
        save_config(self.cfg)
        self._refresh_seg()
        ms = int(PRESETS[key]["ms"])
        self.var_think.set(ms)
        self._time_moved(ms)
        self.worker.send("strength", key)

    def _time_moved(self, value=None) -> None:
        try:
            ms = int(float(value if value is not None else self.var_think.get()))
        except (TypeError, ValueError):
            return
        self.lbl_time.configure(text=f"{ms / 1000:.1f} с")
        if self._time_job:
            self.root.after_cancel(self._time_job)
        self._time_job = self.root.after(220, lambda: self._send_time(ms))

    def _send_time(self, ms: int) -> None:
        self._time_job = None
        self.cfg["think_ms"] = ms
        save_config(self.cfg)
        self.worker.send("think", ms)

    def _toggle_color(self) -> None:
        val = "black" if self.cfg.get("play_as", "white") == "white" else "white"
        self.cfg["play_as"] = val
        save_config(self.cfg)
        self.btn_color.configure(text=f"играю: {'чёрные' if val == 'black' else 'белые'}")
        self.worker.send("play_as", val)

    def toggle_flip(self) -> None:
        """Перевернуть доску (если фигуры читаются зеркально)."""
        self.worker.send("flip")

    def switch_turn(self) -> None:
        self.worker.send("turn", True)
        self._log("очередь переключена на белых")

    def reset(self) -> None:
        self.worker.send("reset")
        self.game_over_shown = False

    # --------------------------------------------------------------- хоткеи
    def _start_hotkeys(self) -> None:
        """Свои горячие клавиши.

        F11/F12 в браузере заняты (полный экран и DevTools), поэтому
        переключения повешены на Ctrl+F11 и Ctrl+F12.
        """
        try:
            from pynput import keyboard
        except Exception as exc:  # pragma: no cover
            self._log(f"хоткеи недоступны: {exc}")
            return

        K = keyboard.Key
        plain = {K.f8: self.calibrate, K.f9: self.analyze, K.f10: self.clear,
                 K.f7: self.show_read}
        with_ctrl = {K.f11: self._hotkey_auto, K.f12: self._hotkey_autoplay,
                     K.f10: self.toggle_compact, K.f8: self.join_game}
        with_shift = {K.f8: self.calibrate_manual, K.f9: self.switch_turn,
                      K.f7: self.toggle_flip}
        shift_keys = (K.shift, K.shift_l, K.shift_r)
        ctrl_keys = (K.ctrl, K.ctrl_l, K.ctrl_r)
        self._shift = False
        self._ctrl = False

        def on_press(key):
            if key in shift_keys:
                self._shift = True
                return
            if key in ctrl_keys:
                self._ctrl = True
                return
            if self._ctrl:
                action = with_ctrl.get(key)
            elif self._shift:
                action = with_shift.get(key)
            else:
                action = plain.get(key)
            if action is not None:
                self.ui_events.put(action)

        def on_release(key):
            if key in shift_keys:
                self._shift = False
            if key in ctrl_keys:
                self._ctrl = False

        self._listener = keyboard.Listener(on_press=on_press, on_release=on_release)
        self._listener.daemon = True
        self._listener.start()
        self._log("хоткеи: F8 F9 F10, Ctrl+F8 подключиться, Ctrl+F11 авто, "
                  "Ctrl+F12 авто-ход, Ctrl+F10 свернуть, ⇧F7 перевернуть, ⇧F8, ⇧F9")

    def _hotkey_auto(self) -> None:
        self.toggle_auto()

    def _hotkey_autoplay(self) -> None:
        self.toggle_autoplay()

    # ----------------------------------------------------------------- жизнь
    def _quit(self) -> None:
        try:
            self._listener.stop()
        except Exception:
            pass
        self._save_window()
        self.worker.send("quit")
        self.worker.join(timeout=2.0)
        save_config(self.cfg)
        self.root.destroy()

    def run(self) -> None:
        self.root.mainloop()


def _acquire_single_instance():
    """Не даёт запустить второй экземпляр: две стрелки = мерцание и мусор."""
    try:
        import ctypes
        handle = ctypes.windll.kernel32.CreateMutexW(None, False, "Local\\ChessVisionOne")
        if ctypes.windll.kernel32.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
            return None
        return handle
    except Exception:
        return True  # не смогли проверить — не блокируем запуск


def main() -> None:
    mutex = _acquire_single_instance()
    if mutex is None:
        try:
            import tkinter.messagebox as mb
            from tkinter import Tk
            r = Tk()
            r.withdraw()
            mb.showwarning("Chess Vision", "Программа уже запущена.\n"
                                           "Второе окно только мешает: две стрелки и мерцание.")
            r.destroy()
        except Exception:
            pass
        return
    App().run()
