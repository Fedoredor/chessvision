"""Слой со стрелкой: геометрия доски + отрисовка + прозрачное окно."""

from __future__ import annotations

import chess
from PIL import Image

from .draw import render_arrow
from .geometry import BoardGeometry
from .layered import OverlayWindow

__all__ = ["ArrowOverlay", "MAIN_COLOR", "ALT_COLOR"]

MAIN_COLOR = (46, 204, 64)      # зелёный — рекомендуемый ход
ALT_COLOR = (90, 160, 255)      # синий — второй вариант


class ArrowOverlay:
    """Показывает одну или несколько стрелок поверх экрана."""

    def __init__(self) -> None:
        self._win = OverlayWindow("arrow")

    # ------------------------------------------------------------------ показ
    def draw(self, geom: BoardGeometry, moves, alpha: int = 235) -> bool:
        """moves: список (chess.Move, (r,g,b[,a])). Возвращает True, если что-то нарисовано."""
        parts = []
        for item in moves:
            move, color = item[0], item[1]
            a = item[2] if len(item) > 2 else alpha
            res = render_arrow(geom.square_center(move.from_square),
                               geom.square_center(move.to_square),
                               geom.cell, color[:3], a)
            if res:
                parts.append(res)
        if not parts:
            self.hide()
            return False

        x0 = min(p[0] for p in parts)
        y0 = min(p[1] for p in parts)
        x1 = max(p[0] + p[2].width for p in parts)
        y1 = max(p[1] + p[2].height for p in parts)
        canvas = Image.new("RGBA", (int(x1 - x0), int(y1 - y0)), (0, 0, 0, 0))
        for x, y, img in parts:
            canvas.alpha_composite(img, (int(x - x0), int(y - y0)))
        self._win.show(int(x0), int(y0), canvas)
        return True

    def hide(self) -> None:
        self._win.hide()

    @property
    def visible(self) -> bool:
        return self._win.visible

    # -------------------------------------------------------- захват экрана
    def exclude_from_capture(self, enabled: bool = True) -> bool:
        """Просит Windows не показывать окно в скриншотах (Win10 2004+)."""
        return self._win.set_display_affinity(enabled)

    def close(self) -> None:
        self._win.destroy()
