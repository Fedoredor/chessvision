package com.chessvision

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.chessvision.core.BoardGeometry
import com.chessvision.core.Coach
import com.chessvision.core.Frame
import com.chessvision.core.UciEngine
import com.chessvision.core.Vision
import java.io.File

/**
 * Захват экрана + оверлей. Живёт одним foreground-сервисом:
 * MediaProjection требует FGS, а стрелку рисуем поверх всех окон.
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val ACTION_CALIBRATE = "calibrate"
        const val ACTION_JOIN = "join"
        const val ACTION_ARROW = "testarrow"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val CHANNEL = "chessvision"

        @Volatile
        var alive: Boolean = false

        @Volatile
        var lastMove: String = ""
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var imageThread: HandlerThread? = null

    @Volatile
    private var lastFrame: Frame? = null

    private var width = 0
    private var height = 0

    private lateinit var windowManager: WindowManager
    private var arrowView: ArrowView? = null
    private var panel: View? = null
    private var panelText: TextView? = null

    private var worker: HandlerThread? = null
    private var handler: Handler? = null

    private var coach: Coach? = null
    private var engine: UciEngine? = null

    private var auto = true
    private var arrowFrom = -1
    private var arrowTo = -1

    override fun onCreate() {
        super.onCreate()
        alive = true
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        width = metrics.widthPixels
        height = metrics.heightPixels
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.i("ChessVision", "onStart action=${intent?.action} " +
                "data=${intent?.hasExtra(EXTRA_DATA)}")
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        // отладочные команды для проверки без тапов по оверлею
        when (intent?.action) {
            ACTION_CALIBRATE -> {
                handler?.post { coach?.let { c -> grab()?.let { f -> showResult(c.calibrate(f)) } } }
                return START_STICKY
            }
            ACTION_JOIN -> {
                handler?.post { coach?.let { c -> grab()?.let { f -> showResult(c.join(f)) } } }
                return START_STICKY
            }
            ACTION_ARROW -> {
                if (intent.hasExtra("x")) {
                    coach?.setGeometry(floatArrayOf(
                        intent.getIntExtra("x", 0).toFloat(),
                        intent.getIntExtra("y", 0).toFloat(),
                        intent.getIntExtra("w", 0).toFloat(),
                        intent.getIntExtra("h", 0).toFloat(),
                    ), false)
                }
                val from = intent.getIntExtra("from", -1)
                val to = intent.getIntExtra("to", -1)
                val g = coach?.geometry
                if (g != null && from >= 0 && to >= 0) {
                    arrowFrom = from
                    arrowTo = to
                    arrowView?.update(g, from, to)
                    Log.i("ChessVision", "test arrow ${'$'}from -> ${'$'}to")
                }
                return START_STICKY
            }
        }
        startInForeground()

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        // ВАЖНО: Activity.RESULT_OK == -1, поэтому проверять code >= 0 нельзя
        if (data != null && projection == null) {
            val mgr = getSystemService(MediaProjectionManager::class.java)
            projection = mgr.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSelf()
                }
            }, Handler(mainLooper))
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            imageThread = HandlerThread("frames").also { it.start() }
            imageReader?.setOnImageAvailableListener({ r ->
                val img = try {
                    r.acquireLatestImage()
                } catch (e: Exception) {
                    null
                } ?: return@setOnImageAvailableListener
                try {
                    lastFrame = convert(img)
                } finally {
                    img.close()
                }
            }, Handler(imageThread!!.looper))
            virtualDisplay = projection?.createVirtualDisplay(
                "chessvision", width, height, resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface, null, null,
            )
            installOverlay()
            startWorker()
            Log.i("ChessVision", "overlay installed, worker started")
        } else {
            Log.w("ChessVision", "no projection: code=$code data=${data != null} proj=${projection != null}")
        }
        return START_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Chess Vision", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification: Notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL)
                .setContentTitle("Chess Vision")
                .setContentText("читает доску и подсказывает ход")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Chess Vision")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notification)
        }
    }

    // ------------------------------------------------------------- оверлей

    private fun overlayParams(): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }
    }

    private fun installOverlay() {
        val view = ArrowView(this)
        arrowView = view
        try {
            windowManager.addView(view, overlayParams())
        } catch (e: Exception) {
            Log.e("ChessVision", "arrow overlay: ${e.message}", e)
        }
        installPanel()
    }

    private fun installPanel() {
        val ctx = this
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        // ---------- развёрнутая карточка ----------
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(Color.argb(244, 22, 24, 32))
                setStroke(dp(1), Color.parseColor("#2E3446"))
            }
            setPadding(dp(14), dp(10), dp(14), dp(12))
        }

        val header = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val title = TextView(ctx).apply {
            text = "♞  Chess Vision"
            setTextColor(Color.parseColor("#37D67A"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val minimize = TextView(ctx).apply {
            text = "—"
            setTextColor(Color.parseColor("#8B90A6"))
            textSize = 18f
            setPadding(dp(12), 0, dp(4), 0)
        }
        header.addView(minimize)
        card.addView(header)

        panelText = TextView(ctx).apply {
            setTextColor(Color.parseColor("#E8EAF2"))
            textSize = 14f
            setPadding(0, dp(6), 0, dp(8))
            text = "жду позицию…"
        }
        card.addView(panelText)

        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        fun chip(t: String, action: () -> Unit): TextView {
            val v = TextView(ctx).apply {
                text = t
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(8), dp(12), dp(8))
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = dp(12).toFloat()
                    setColor(Color.parseColor("#2A2F40"))
                }
                setTextColor(Color.parseColor("#E8EAF2"))
                setOnClickListener { action() }
            }
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = dp(8)
            row.addView(v, lp)
            return v
        }
        chip("Калибровать") { runCommand { c, f -> c.calibrate(f) } }
        chip("Подключиться") { runCommand { c, f -> c.join(f) } }
        val autoChip = chip("Авто: вкл") { auto = !auto; refreshAutoChip(null) }
        autoChip.tag = "auto"
        card.addView(row)

        // ---------- свёрнутый кружок ----------
        val bubble = TextView(ctx).apply {
            text = "♞"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#07130C"))
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.parseColor("#37D67A"))
            }
            visibility = View.GONE
        }

        val root = FrameLayout(ctx)
        root.addView(card, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(bubble, FrameLayout.LayoutParams(dp(56), dp(56)))

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(10)
            y = dp(90)
        }

        var dx = 0
        var dy = 0
        var sx = 0f
        var sy = 0f
        var drag = false

        fun makeDraggable(v: View, onClick: (() -> Unit)? = null) {
            v.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        dx = params.x; dy = params.y; sx = e.rawX; sy = e.rawY; drag = false
                        true   // ВАЖНО: иначе жест не наш и движение не приходит
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (!drag && kotlin.math.abs(e.rawX - sx) +
                            kotlin.math.abs(e.rawY - sy) > dp(14)) drag = true
                        if (drag) {
                            params.x = dx + (e.rawX - sx).toInt()
                            params.y = dy + (e.rawY - sy).toInt()
                            try { windowManager.updateViewLayout(root, params) } catch (_: Exception) {}
                            true
                        } else false
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!drag) onClick?.invoke()
                        true
                    }
                    else -> false
                }
            }
        }

        minimize.setOnClickListener {
            card.visibility = View.GONE
            bubble.visibility = View.VISIBLE
            try { windowManager.updateViewLayout(root, params) } catch (_: Exception) {}
        }
        makeDraggable(title)
        makeDraggable(bubble) {
            bubble.visibility = View.GONE
            card.visibility = View.VISIBLE
            try { windowManager.updateViewLayout(root, params) } catch (_: Exception) {}
        }

        autoChipRef = autoChip
        refreshAutoChip(null)

        panel = root
        try {
            windowManager.addView(root, params)
            Log.d("ChessVision", "panel added")
        } catch (e: Exception) {
            Log.e("ChessVision", "panel overlay: ${e.message}", e)
        }
    }

    private var autoChipRef: TextView? = null

    /** Пока идёт это время, такт не затирает ответ на нажатую кнопку. */
    private var holdTextUntil = 0L

    /** Сколько тактов подряд приходит чёрный кадр (включена защита экрана). */
    private var blackTicks = 0

    /** Подсветка «Авто»: состояние должно быть видно. */
    private fun refreshAutoChip(unused: Button?) {
        val v = autoChipRef ?: return
        v.text = if (auto) "Авто: вкл" else "Авто: выкл"
        (v.background as? android.graphics.drawable.GradientDrawable)?.setColor(
            if (auto) Color.parseColor("#37D67A") else Color.parseColor("#2A2F40")
        )
        v.setTextColor(if (auto) Color.parseColor("#07130C") else Color.parseColor("#E8EAF2"))
    }

    /** Кнопка «Авто» должна показывать состояние, иначе непонятно, включено ли. */
    private fun refreshAuto(button: Button) {
        button.text = if (auto) "Авто: вкл" else "Авто: выкл"
        button.setBackgroundColor(
            if (auto) Color.parseColor("#37D67A") else Color.parseColor("#3A3F52")
        )
        button.setTextColor(
            if (auto) Color.parseColor("#07130C") else Color.parseColor("#E8EAF2")
        )
    }

    private fun runCommand(action: (Coach, Frame) -> Coach.Result) {
        val c = coach ?: return
        val frame = grab()
        if (frame == null) {
            updateText("нет кадра с экрана — проверь захват")
            return
        }
        val r = action(c, frame)
        holdTextUntil = System.currentTimeMillis() + 5000
        showResult(r)
        // запоминаем положение доски, чтобы потом подключаться без поиска
        c.geometry?.let { g ->
            Prefs.setGeometry(this, "${'$'}{g.left},${'$'}{g.top},${'$'}{g.width},${'$'}{g.height},${'$'}{g.flipped}")
        }
    }

    // -------------------------------------------------------------- рабочий цикл

    private fun startWorker() {
        worker = HandlerThread("coach").also { it.start() }
        handler = Handler(worker!!.looper)
        handler?.post {
            val binary = EngineAssets.locate(this)
            if (binary == null) {
                Log.e("ChessVision", "движок не найден в nativeLibraryDir")
                updateText("движок не найден в APK")
            } else {
                Log.i("ChessVision", "engine ${binary.absolutePath} exec=${binary.canExecute()}")
                engine = UciEngine(binary)
            }
            val c = Coach(engine) { msg ->
                Log.i("ChessVision", "coach: " + msg)
                handler?.post { updateText(msg) }
            }
            // положение доски с прошлого раза: сразу можно подключаться
            Prefs.savedGeometry(this)?.split(",")?.let { p ->
                if (p.size == 5) {
                    try {
                        c.setGeometry(floatArrayOf(
                            p[0].toFloat(), p[1].toFloat(), p[2].toFloat(), p[3].toFloat()
                        ), p[4] == "true")
                        Log.i("ChessVision", "geometry restored")
                    } catch (_: Exception) {
                    }
                }
            }
            c.templateFile = File(filesDir, "templates.bin")
            val loaded = c.loadTemplates()
            Log.i("ChessVision", "templates loaded=$loaded")
            c.thinkMs = Prefs.thinkMs(this)
            c.threads = Prefs.threads()
            c.hashMb = Prefs.hash(this)
            c.elo = Prefs.elo(this)
            coach = c
            loop()
        }
    }

    private fun loop() {
        handler?.postDelayed({
            try {
                if (auto) {
                    val frame = grab()
                    // FLAG_SECURE у чужого приложения даёт чёрный кадр:
                    // MediaProjection бессилен, нужно играть через браузер
                    if (frame != null && frame.meanLum(
                            0f, 0f, frame.width.toFloat(), frame.height.toFloat()) < 4f) {
                        blackTicks++
                        if (blackTicks == 6) {
                            holdTextUntil = System.currentTimeMillis() + 600000
                            updateText("экран защищён от записи (чёрный кадр). " +
                                    "Открой chess.com в Chrome — там захват работает")
                            Log.w("ChessVision", "black frames: FLAG_SECURE?")
                        }
                        if (blackTicks > 6) return@postDelayed
                    } else {
                        blackTicks = 0
                    }
                    if (frame != null) {
                        val co = coach
                        if (co != null && co.calibrated) {
                            val r = co.tick(frame)
                            showResult(r)
                        } else if (co != null && System.currentTimeMillis() > holdTextUntil) {
                            updateText(
                                if (!co.hasTemplates) "нет шаблонов фигур — нажми «Калибровать»"
                                else "доска не найдена — нажми «Подключиться»"
                            )
                        }
                    } else {
                        Log.w("ChessVision", "нет кадра с экрана")
                    }
                }
            } catch (t: Throwable) {
                // ловим и Error (например OutOfMemory): цикл не должен умирать
                Log.e("ChessVision", "tick: ${t}", t)
                updateText("сбой: ${t.message}")
            } finally {
                loop()   // перезапуск в любом случае
            }
        }, 500)
    }

    /** Последний кадр: экран может не меняться, тогда новых кадров нет. */
    private fun grab(): Frame? = lastFrame

    private fun convert(image: android.media.Image): Frame? = try {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val w = image.width
        val h = image.height
        val argb = IntArray(w * h)
        val row = ByteArray(rowStride)
        var offset = 0
        for (y in 0 until h) {
            buffer.position(offset)
            val n = minOf(rowStride, buffer.remaining())
            buffer.get(row, 0, n)
            offset += rowStride
            var p = 0
            val base = y * w
            for (x in 0 until w) {
                val r = row[p].toInt() and 0xFF
                val g = row[p + 1].toInt() and 0xFF
                val b = row[p + 2].toInt() and 0xFF
                val a = row[p + 3].toInt() and 0xFF
                argb[base + x] = (a shl 24) or (r shl 16) or (g shl 8) or b
                p += pixelStride
            }
        }
        Frame(w, h, argb)
    } catch (e: Exception) {
        null
    }

    // ------------------------------------------------------------- отрисовка

    private fun showResult(r: Coach.Result) {
        handler?.post {
            if (r.status.isNotEmpty()) updateText(r.status)
            if (r.moveText.isNotEmpty()) {
                lastMove = r.moveText
                updateText("${r.moveText}  ${r.evalText}")
            }
            arrowFrom = r.arrowFrom
            arrowTo = r.arrowTo
            val g = coach?.geometry
            arrowView?.update(g, arrowFrom, arrowTo)
        }
    }

    private fun updateText(text: String) {
        panelText?.post { panelText?.text = text }
    }

    override fun onDestroy() {
        alive = false
        try {
            handler?.removeCallbacksAndMessages(null)
            worker?.quitSafely()
        } catch (_: Exception) {
        }
        engine?.quit()
        virtualDisplay?.release()
        imageReader?.close()
        projection?.stop()
        arrowView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        panel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ------------------------------------------------------------- стрелка

    /** Полноэкранный слой, рисует стрелку над доской. */
    class ArrowView(context: Context) : View(context) {
        private var geom: BoardGeometry? = null
        private var from = -1
        private var to = -1
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#2ECC40")
        }
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.parseColor("#2ECC40")
            strokeWidth = 6f
        }

        fun update(g: BoardGeometry?, f: Int, t: Int) {
            geom = g
            from = f
            to = t
            postInvalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val g = geom ?: return
            if (from < 0 || to < 0) return
            // окно оверлея может быть смещено относительно кадра (статус-бар,
            // вырез камеры). Берём реальную позицию вьюхи и вычитаем её,
            // иначе стрелка уезжает на клетку вниз.
            val loc = IntArray(2)
            getLocationOnScreen(loc)
            val shiftX = loc[0].toFloat()
            val shiftY = loc[1].toFloat()
            val a0 = g.center(from)
            val b0 = g.center(to)
            val a = floatArrayOf(a0[0] - shiftX, a0[1] - shiftY)
            val b = floatArrayOf(b0[0] - shiftX, b0[1] - shiftY)
            val cell = minOf(g.cellW, g.cellH)
            val dx = b[0] - a[0]
            val dy = b[1] - a[1]
            val len = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
            if (len < 4f) return
            val ux = dx / len
            val uy = dy / len
            val shaft = cell * 0.10f
            val head = minOf(cell * 0.42f, len * 0.42f)
            val tipX = b[0] - ux * cell * 0.08f
            val tipY = b[1] - uy * cell * 0.08f
            val baseX = tipX - ux * head
            val baseY = tipY - uy * head
            val px = -uy
            val py = ux

            stroke.strokeWidth = shaft * 1.6f
            stroke.color = Color.argb(120, 0, 0, 0)
            canvas.drawLine(a[0], a[1], baseX, baseY, stroke)
            stroke.color = Color.parseColor("#2ECC40")
            stroke.strokeWidth = shaft
            canvas.drawLine(a[0], a[1], baseX, baseY, stroke)

            val path = Path()
            path.moveTo(tipX, tipY)
            path.lineTo(baseX + px * shaft, baseY + py * shaft)
            path.lineTo(baseX - px * shaft, baseY - py * shaft)
            path.close()
            canvas.drawPath(path, paint)

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = shaft * 0.5f
            canvas.drawCircle(a[0], a[1], cell * 0.18f, paint)
            paint.style = Paint.Style.FILL
        }
    }
}


