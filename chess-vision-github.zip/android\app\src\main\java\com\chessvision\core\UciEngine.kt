package com.chessvision.core

import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/** Один вариант из движка. */
data class Line(val move: String, val scoreText: String, val cp: Int?, val mate: Int?)

/** Результат анализа. */
data class Analysis(
    val best: String?,
    val scoreText: String,
    val cp: Int?,
    val mate: Int?,
    val depth: Int,
    val pv: List<String>,
    val lines: List<Line>,
    val elapsedMs: Long,
)

/**
 * Клиент UCI: запускает Stockfish как процесс и общается по stdin/stdout.
 *
 * Отдельно умеет отдавать список легальных ходов через `go perft 1` —
 * так трекеру не нужен собственный генератор ходов.
 */
class UciEngine(private val binary: File) {

    private var process: Process? = null
    private var out: BufferedWriter? = null
    private var inp: BufferedReader? = null

    /** Отдельный поток для общения с движком — чтобы можно было ставить таймаут. */
    private val exec = Executors.newSingleThreadExecutor { r ->
        Thread(r, "uci").apply { isDaemon = true }
    }

    @Volatile
    var engineName: String = "Stockfish"
        private set

    val running: Boolean get() = process?.isAlive == true

    fun start(threads: Int, hashMb: Int, elo: Int?) {
        if (running) return
        binary.setExecutable(true)
        val p = ProcessBuilder(binary.absolutePath).redirectErrorStream(true).start()
        process = p
        out = p.outputStream.bufferedWriter()
        inp = p.inputStream.bufferedReader()

        send("uci")
        var line: String?
        while (true) {
            line = readLine() ?: break
            if (line.startsWith("id name ")) engineName = line.removePrefix("id name ").trim()
            if (line == "uciok") break
        }
        setOption("Threads", threads.toString())
        setOption("Hash", hashMb.toString())
        if (elo != null) {
            setOption("UCI_LimitStrength", "true")
            setOption("UCI_Elo", elo.toString())
        } else {
            setOption("UCI_LimitStrength", "false")
        }
        isReady()
    }

    private fun isReady() {
        send("isready")
        while (true) {
            val l = readLine() ?: break
            if (l == "readyok") break
        }
    }

    fun setOption(name: String, value: String) {
        send("setoption name $name value $value")
    }

    private fun send(cmd: String) {
        val w = out ?: return
        w.write(cmd)
        w.write("\n")
        w.flush()
    }

    private fun readLine(): String? = try {
        inp?.readLine()
    } catch (e: Exception) {
        null
    }

    /** Анализ позиции на заданное время. */
    fun analyse(fen: String, ms: Int, multipv: Int = 3): Analysis {
        if (!running) return Analysis(null, "движок не запущен", null, null, 0, emptyList(), emptyList(), 0)
        // сторожевой таймер: если движок не ответил, убиваем его и вернём заглушку,
        // иначе блокирующее чтение подвешивает весь цикл навсегда
        val future = exec.submit(Callable { analyseBlocking(fen, ms, multipv) })
        return try {
            future.get((ms + 8000).toLong(), TimeUnit.MILLISECONDS)
        } catch (e: TimeoutException) {
            future.cancel(true)
            kill()
            Analysis(null, "движок завис", null, null, 0, emptyList(), emptyList(), 0)
        } catch (e: Exception) {
            Analysis(null, "ошибка движка", null, null, 0, emptyList(), emptyList(), 0)
        }
    }

    private fun kill() {
        try {
            process?.destroy()
        } catch (_: Exception) {
        }
        process = null
        out = null
        inp = null
    }

    private fun analyseBlocking(fen: String, ms: Int, multipv: Int): Analysis {
        val t0 = System.currentTimeMillis()
        setOption("MultiPV", multipv.toString())
        send("position fen $fen")
        send("go movetime $ms")

        var bestMove: String? = null
        var depth = 0
        val infos = sortedMapOf<Int, String>()   // multipv -> последний info
        while (true) {
            val line = readLine() ?: break
            if (line.startsWith("bestmove")) {
                bestMove = line.split(" ").getOrNull(1)
                break
            }
            if (line.startsWith("info ") && line.contains(" pv ")) {
                val mp = Regex("multipv (\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull() ?: 1
                infos[mp] = line
                val d = Regex("depth (\\d+)").find(line)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                if (d > depth) depth = d
            }
        }
        val elapsed = System.currentTimeMillis() - t0

        fun parseScore(s: String): Pair<Int?, Int?> {
            val cp = Regex("score cp (-?\\d+)").find(s)?.groupValues?.get(1)?.toIntOrNull()
            val mate = Regex("score mate (-?\\d+)").find(s)?.groupValues?.get(1)?.toIntOrNull()
            return cp to mate
        }

        val lines = ArrayList<Line>()
        for ((_, info) in infos) {
            val pv = Regex(" pv (.+)$").find(info)?.groupValues?.get(1)?.trim()?.split(" ")
                ?: continue
            if (pv.isEmpty()) continue
            val (cp, mate) = parseScore(info)
            val text = when {
                mate != null -> if (mate > 0) "мат в $mate" else "мат нам в ${-mate}"
                cp != null -> String.format("%+.2f", cp / 100.0)
                else -> "-"
            }
            lines.add(Line(pv[0], text, cp, mate))
        }
        lines.sortByDescending { it.cp ?: if ((it.mate ?: 0) > 0) 100000 else -100000 }

        val main = lines.firstOrNull()
        val pvSan = main?.let {
            Regex(" pv (.+)$").find(infos[1] ?: "")?.groupValues?.get(1)?.trim()?.split(" ")?.take(6)
                ?: emptyList()
        } ?: emptyList()

        return Analysis(
            best = bestMove ?: main?.move,
            scoreText = main?.scoreText ?: "-",
            cp = main?.cp, mate = main?.mate, depth = depth,
            pv = pvSan, lines = lines, elapsedMs = elapsed,
        )
    }

    /** Легальные ходы позиции через perft. */
    fun legalMoves(fen: String): List<String> {
        if (!running) return emptyList()
        val future = exec.submit(Callable { legalMovesBlocking(fen) })
        return try {
            future.get(4000, TimeUnit.MILLISECONDS)
        } catch (e: Exception) {
            future.cancel(true)
            kill()
            emptyList()
        }
    }

    private fun legalMovesBlocking(fen: String): List<String> {
        setOption("MultiPV", "1")
        send("position fen $fen")
        send("go perft 1")
        val moves = ArrayList<String>(64)
        while (true) {
            val line = readLine() ?: break
            if (line.startsWith("Nodes searched")) break
            val m = Regex("^([a-h][1-8][a-h][1-8][qrbn]?): ").find(line)
            if (m != null) moves.add(m.groupValues[1])
        }
        return moves
    }

    fun quit() {
        try {
            send("quit")
            process?.waitFor()
        } catch (_: Exception) {
        } finally {
            process = null
            out = null
            inp = null
        }
    }
}
