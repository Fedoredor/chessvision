"""Запуск Chess Vision.

    python run.py
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from chess_vision.app import main  # noqa: E402

if __name__ == "__main__":
    main()
