"""Обёртка над Stockfish: поиск бинарника, оценка позиции, лучший ход."""

from __future__ import annotations

import glob
import os
import shutil
import sys
import time
from dataclasses import dataclass, field

import chess
import chess.engine

__all__ = ["ChessEngine", "EngineLine", "Analysis", "find_engine", "PRESETS"]

# Профили силы. elo=None — без ограничения (максимальная игра).
# threads=0 — использовать все ядра.
PRESETS: dict[str, dict] = {
    "weak":   {"title": "Слабо",    "elo": 1400, "threads": 2, "hash": 64,  "ms": 300},
    "medium": {"title": "Средне",   "elo": 1900, "threads": 4, "hash": 128, "ms": 500},
    "strong": {"title": "Сильно",   "elo": 2500, "threads": 8, "hash": 256, "ms": 800},
    "max":    {"title": "Максимум", "elo": None, "threads": 0, "hash": 2048, "ms": 6000},
}
PRESET_ORDER = ("weak", "medium", "strong", "max")


def _app_dir() -> str:
    if getattr(sys, "frozen", False):  # pragma: no cover
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def find_engine(explicit: str | None = None) -> str | None:
    """Ищет Stockfish: явный путь -> переменная окружения -> папка engine -> PATH."""
    candidates: list[str] = []
    if explicit and os.path.isfile(explicit):
        return explicit
    env = os.environ.get("CHESSVISION_ENGINE")
    if env and os.path.isfile(env):
        return env
    for root in (_app_dir(), os.path.dirname(_app_dir())):
        for pattern in ("engine/stockfish*.exe", "engine/**/stockfish*.exe",
                        "engine/**/*.exe", "stockfish*.exe"):
            candidates.extend(glob.glob(os.path.join(root, pattern), recursive=True))
    if os.path.isdir(os.path.join(_app_dir(), "engine")):
        candidates.extend(glob.glob(os.path.join(_app_dir(), "engine", "**", "*.exe"), recursive=True))
    for c in candidates:
        base = os.path.basename(c).lower()
        if base.startswith("stockfish") and os.path.isfile(c):
            return c
    return shutil.which("stockfish")


@dataclass
class EngineLine:
    move: chess.Move
    san: str
    score_text: str
    mate: int | None = None
    cp: int | None = None


@dataclass
class Analysis:
    best: chess.Move | None
    san: str = ""
    score_text: str = "-"
    cp: int | None = None
    mate: int | None = None
    depth: int = 0
    pv_san: list[str] = field(default_factory=list)
    lines: list[EngineLine] = field(default_factory=list)
    elapsed: float = 0.0
    engine_name: str = ""


class ChessEngine:
    """Один процесс Stockfish, используется только из рабочего потока."""

    def __init__(self, path: str | None = None, profile: str = "max"):
        self.path = find_engine(path)
        self._engine: chess.engine.SimpleEngine | None = None
        self._name = ""
        self.profile = profile if profile in PRESETS else "max"
        self._options: dict = {}
        self._cpu = os.cpu_count() or 4
        self._build_options()

    # ------------------------------------------------------------- профиль
    def _build_options(self) -> None:
        p = PRESETS[self.profile]
        threads = p["threads"] or self._cpu
        self._options = {
            "Threads": max(1, min(threads, self._cpu)),
            "Hash": int(p["hash"]),
            "UCI_LimitStrength": p["elo"] is not None,
        }
        if p["elo"] is not None:
            self._options["UCI_Elo"] = int(p["elo"])

    def set_profile(self, name: str) -> None:
        """Сменить силу. Движок перезапускается при следующем анализе."""
        if name not in PRESETS or name == self.profile:
            return
        self.profile = name
        self._build_options()
        self.close()

    @property
    def info(self) -> dict:
        p = PRESETS[self.profile]
        return {
            "profile": self.profile,
            "title": p["title"],
            "threads": self._options.get("Threads", 1),
            "hash": self._options.get("Hash", 16),
            "elo": p["elo"],
            "default_ms": p["ms"],
        }

    # ------------------------------------------------------------------ жизнь
    @property
    def available(self) -> bool:
        return bool(self.path)

    @property
    def name(self) -> str:
        return self._name or (os.path.basename(self.path) if self.path else "нет")

    def start(self) -> None:
        if self._engine is not None or not self.path:
            return
        self._engine = chess.engine.SimpleEngine.popen_uci(self.path, timeout=30)
        try:
            self._engine.configure(self._options)
        except chess.engine.EngineError:
            # старые сборки могут не знать UCI_Elo
            self._engine.configure({"Threads": self._options["Threads"],
                                    "Hash": self._options["Hash"]})
        self._name = self._engine.id.get("name", self.name)

    def close(self) -> None:
        if self._engine is not None:
            try:
                self._engine.quit()
            except Exception:
                pass
            self._engine = None

    # ---------------------------------------------------------------- анализ
    def analyse(self, board: chess.Board, seconds: float = 0.8,
                multipv: int = 1) -> Analysis:
        t0 = time.time()
        if not self.path:
            return Analysis(None, score_text="Stockfish не найден")
        if board.king(chess.WHITE) is None or board.king(chess.BLACK) is None:
            return Analysis(None, score_text="позиция не распознана")
        if not board.is_valid():
            return Analysis(None, score_text="позиция некорректна")
        self.start()
        assert self._engine is not None

        limit = chess.engine.Limit(time=max(0.05, seconds))
        infos = self._analyse_with_watchdog(board, limit, max(1, multipv))

        lines: list[EngineLine] = []
        for info in infos:
            pv = info.get("pv") or []
            if not pv:
                continue
            move = pv[0]
            pov = info["score"].pov(board.turn)
            mate = pov.mate() if pov.is_mate() else None
            cp = None if mate is not None else pov.score(mate_score=None)
            if mate is not None:
                text = f"мат в {mate}" if mate > 0 else f"мат нам в {-mate}"
            elif cp is not None:
                text = f"{cp / 100:+.2f}"
            else:
                text = "-"
            lines.append(EngineLine(move, board.san(move), text, mate, cp))

        if not lines:
            return Analysis(None, score_text="нет хода", elapsed=time.time() - t0,
                            engine_name=self.name)

        main = lines[0]
        best_pv = infos[0].get("pv") or []
        b2 = board.copy()
        pv_san = []
        for mv in best_pv[:6]:
            try:
                pv_san.append(b2.san(mv))
                b2.push(mv)
            except Exception:
                break

        return Analysis(
            best=main.move, san=main.san, score_text=main.score_text,
            cp=main.cp, mate=main.mate, depth=int(infos[0].get("depth") or 0),
            pv_san=pv_san, lines=lines, elapsed=time.time() - t0,
            engine_name=self.name,
        )

    def _analyse_with_watchdog(self, board, limit, multipv):
        """Анализ в отдельном потоке: если движок завис — перезапускаем его."""
        import threading

        box: dict = {}

        def work() -> None:
            try:
                box["infos"] = self._engine.analyse(board, limit, multipv=multipv)
            except Exception as exc:  # noqa: BLE001
                box["error"] = exc

        limit_s = getattr(limit, "time", None) or 5.0
        for attempt in range(2):
            worker = threading.Thread(target=work, daemon=True)
            worker.start()
            worker.join(float(limit_s) + 8.0)
            if worker.is_alive() or "error" in box:
                self.close()
                self.start()
                if attempt == 1:
                    raise chess.engine.EngineError("движок не отвечает")
                box.pop("error", None)
                continue
            break
        return box.get("infos") or []

    # ------------------------------------------------------------------ утилиты
    def quick_eval(self, board: chess.Board, seconds: float = 0.2) -> str:
        res = self.analyse(board, seconds, multipv=1)
        return res.score_text
