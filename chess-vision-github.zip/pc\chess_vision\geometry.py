"""Геометрия доски: перевод шахматных клеток в координаты экрана и обратно."""

from __future__ import annotations

import chess

__all__ = ["BoardGeometry"]


class BoardGeometry:
    """Прямоугольник доски на экране (ровно 8x8 клеток, без внешней рамки).

    ``flipped=True`` означает, что чёрные снизу (доска перевёрнута).
    """

    __slots__ = ("left", "top", "width", "height", "flipped")

    def __init__(self, left: float, top: float, width: float, height: float, flipped: bool = False):
        self.left = float(left)
        self.top = float(top)
        self.width = float(width)
        self.height = float(height)
        self.flipped = bool(flipped)

    # ---------------------------------------------------------------- размеры
    @property
    def cell_w(self) -> float:
        return self.width / 8.0

    @property
    def cell_h(self) -> float:
        return self.height / 8.0

    @property
    def right(self) -> float:
        return self.left + self.width

    @property
    def bottom(self) -> float:
        return self.top + self.height

    @property
    def cell(self) -> float:
        return (self.cell_w + self.cell_h) / 2.0

    # ------------------------------------------------------------------ клетки
    def square_to_rowcol(self, square: int) -> tuple[int, int]:
        """Клетка -> (столбец 0..7 слева направо, строка 0..7 сверху вниз)."""
        file_idx = chess.square_file(square)
        rank_idx = chess.square_rank(square)
        if self.flipped:
            return 7 - file_idx, rank_idx
        return file_idx, 7 - rank_idx

    def rowcol_to_square(self, col: int, row: int) -> int:
        if self.flipped:
            return chess.square(7 - col, row)
        return chess.square(col, 7 - row)

    def square_rect(self, square: int) -> tuple[float, float, float, float]:
        """Экранный прямоугольник клетки: (x0, y0, x1, y1)."""
        col, row = self.square_to_rowcol(square)
        x0 = self.left + col * self.cell_w
        y0 = self.top + row * self.cell_h
        return x0, y0, x0 + self.cell_w, y0 + self.cell_h

    def square_center(self, square: int, fx: float = 0.5, fy: float = 0.5) -> tuple[float, float]:
        """Центр клетки; fx/fy задают смещение внутри клетки (0..1)."""
        col, row = self.square_to_rowcol(square)
        return (self.left + (col + fx) * self.cell_w,
                self.top + (row + fy) * self.cell_h)

    def square_at(self, x: float, y: float) -> int | None:
        """Экранная точка -> клетка (или None, если мимо доски)."""
        if not (self.left <= x < self.right and self.top <= y < self.bottom):
            return None
        col = int((x - self.left) / self.cell_w)
        row = int((y - self.top) / self.cell_h)
        return self.rowcol_to_square(max(0, min(7, col)), max(0, min(7, row)))

    # ---------------------------------------------------------------------- IO
    def to_dict(self) -> dict:
        return {
            "left": round(self.left, 2),
            "top": round(self.top, 2),
            "width": round(self.width, 2),
            "height": round(self.height, 2),
            "flipped": self.flipped,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "BoardGeometry":
        return cls(
            data["left"], data["top"], data["width"], data["height"],
            bool(data.get("flipped", False)),
        )

    def with_flipped(self, flipped: bool) -> "BoardGeometry":
        return BoardGeometry(self.left, self.top, self.width, self.height, flipped)

    def __repr__(self) -> str:  # pragma: no cover - только для отладки
        return (f"BoardGeometry({self.left:.0f},{self.top:.0f} "
                f"{self.width:.0f}x{self.height:.0f} flipped={self.flipped})")
