@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
where python >nul 2>nul
if errorlevel 1 goto nopython
python "%~dp0run.py"
if errorlevel 1 goto failed
exit /b 0

:nopython
echo Python не найден в PATH.
echo Поставьте Python 3.10+ с python.org и включите "Add Python to PATH".
pause
exit /b 1

:failed
echo.
echo Не удалось запустить. Проверьте пакеты:
echo    python -m pip install -r requirements.txt
pause
exit /b 1
