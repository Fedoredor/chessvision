package com.chessvision

import android.content.Context

/** Настройки силы и времени (хранятся в SharedPreferences). */
object Prefs {

    private const val NAME = "chessvision"

    const val WEAK = "weak"
    const val MEDIUM = "medium"
    const val STRONG = "strong"
    const val MAX = "max"

    fun labels(): List<String> = listOf("Слабо", "Средне", "Сильно", "Максимум")

    fun keys(): List<String> = listOf(WEAK, MEDIUM, STRONG, MAX)

    fun strength(ctx: Context): String =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString("strength", MAX) ?: MAX

    fun setStrength(ctx: Context, key: String) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putString("strength", key).apply()
    }

    fun thinkMs(ctx: Context): Int {
        val def = when (strength(ctx)) {
            WEAK -> 400
            MEDIUM -> 800
            STRONG -> 2000
            else -> 6000
        }
        return ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getInt("think", def)
    }

    fun setThinkMs(ctx: Context, ms: Int) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putInt("think", ms).apply()
    }

    fun hash(ctx: Context): Int = when (strength(ctx)) {
        WEAK -> 32
        MEDIUM -> 128
        STRONG -> 256
        else -> 1024
    }

    fun elo(ctx: Context): Int? = when (strength(ctx)) {
        WEAK -> 1400
        MEDIUM -> 1900
        STRONG -> 2500
        else -> null
    }

    /**
     * Потоки движка: половина ядер. На big.LITTLE лишние «медленные» потоки
     * только тормозят поиск, поэтому не берём все ядра.
     */
    fun threads(): Int =
        (Runtime.getRuntime().availableProcessors() / 2).coerceIn(2, 6)

    fun savedGeometry(ctx: Context): String? =
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString("geometry", null)

    fun setGeometry(ctx: Context, value: String) {
        ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putString("geometry", value).apply()
    }
}
