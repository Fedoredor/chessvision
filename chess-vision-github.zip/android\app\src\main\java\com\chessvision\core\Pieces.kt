package com.chessvision.core

/**
 * Фигуры и позиция.
 *
 * Кодировка как в python-версии: 0 — пусто, иначе (цвет << 3) | тип,
 * где тип 1..6 = P N B R Q K, цвет 0 = белые, 1 = чёрные.
 */
object Piece {
    const val EMPTY = 0
    const val PAWN = 1
    const val KNIGHT = 2
    const val BISHOP = 3
    const val ROOK = 4
    const val QUEEN = 5
    const val KING = 6

    const val WHITE = 0
    const val BLACK = 1

    fun of(type: Int, color: Int): Int = (color shl 3) or type
    fun type(code: Int): Int = code and 7
    fun color(code: Int): Int = (code ushr 3) and 1
    fun isEmpty(code: Int): Boolean = code == 0

    private const val LETTERS = " PNBRQK"

    fun symbol(code: Int): Char {
        val t = type(code)
        if (t == 0) return ' '
        val c = LETTERS[t]
        return if (color(code) == BLACK) c.lowercaseChar() else c
    }

    fun letter(type: Int): Char = LETTERS.getOrElse(type) { '?' }
}

/** Позиция: 64 поля, индекс = rank * 8 + file (a1 = 0). */
class Position(
    val cells: IntArray = IntArray(64),
    var whiteToMove: Boolean = true,
    var castling: String = "KQkq",
) {
    fun copy(): Position = Position(cells.copyOf(), whiteToMove, castling)

    fun get(sq: Int): Int = cells[sq]
    fun set(sq: Int, code: Int) {
        cells[sq] = code
    }

    fun isEmpty(sq: Int): Boolean = cells[sq] == 0

    fun placementEquals(other: Position): Boolean = cells.contentEquals(other.cells)

    fun fenPlacement(): String {
        val sb = StringBuilder()
        for (rank in 7 downTo 0) {
            var empty = 0
            for (file in 0..7) {
                val c = cells[rank * 8 + file]
                if (c == 0) {
                    empty++
                } else {
                    if (empty > 0) {
                        sb.append(empty)
                        empty = 0
                    }
                    sb.append(Piece.symbol(c))
                }
            }
            if (empty > 0) sb.append(empty)
            if (rank > 0) sb.append('/')
        }
        return sb.toString()
    }

    fun fen(): String =
        "${fenPlacement()} ${if (whiteToMove) "w" else "b"} $castling - 0 1"

    fun kingSquare(color: Int): Int = cells.indexOfFirst { it != 0 && Piece.type(it) == Piece.KING && Piece.color(it) == color }

    companion object {
        fun startPosition(): Position {
            val p = Position()
            val back = intArrayOf(Piece.ROOK, Piece.KNIGHT, Piece.BISHOP, Piece.QUEEN,
                Piece.KING, Piece.BISHOP, Piece.KNIGHT, Piece.ROOK)
            for (f in 0..7) {
                p.cells[f] = Piece.of(back[f], Piece.WHITE)
                p.cells[8 + f] = Piece.of(Piece.PAWN, Piece.WHITE)
                p.cells[48 + f] = Piece.of(Piece.PAWN, Piece.BLACK)
                p.cells[56 + f] = Piece.of(back[f], Piece.BLACK)
            }
            return p
        }

        /** Права на рокировку по картинке: король и ладья на исходных полях. */
        fun castlingFromPlacement(cells: IntArray): String {
            val sb = StringBuilder()
            if (cells[4] == Piece.of(Piece.KING, Piece.WHITE) &&
                cells[7] == Piece.of(Piece.ROOK, Piece.WHITE)
            ) sb.append('K')
            if (cells[4] == Piece.of(Piece.KING, Piece.WHITE) &&
                cells[0] == Piece.of(Piece.ROOK, Piece.WHITE)
            ) sb.append('Q')
            if (cells[60] == Piece.of(Piece.KING, Piece.BLACK) &&
                cells[63] == Piece.of(Piece.ROOK, Piece.BLACK)
            ) sb.append('k')
            if (cells[60] == Piece.of(Piece.KING, Piece.BLACK) &&
                cells[56] == Piece.of(Piece.ROOK, Piece.BLACK)
            ) sb.append('q')
            return if (sb.isEmpty()) "-" else sb.toString()
        }

        fun fromPlacement(cells: IntArray, whiteToMove: Boolean): Position =
            Position(cells.copyOf(), whiteToMove, castlingFromPlacement(cells))
    }
}

object Square {
    fun name(sq: Int): String = "${('a' + (sq and 7))}${(sq ushr 3) + 1}"
    fun of(file: Int, rank: Int): Int = rank * 8 + file
}
