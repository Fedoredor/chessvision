package com.chessvision.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class VisionTest {

    private fun startCells() = Position.startPosition().cells

    @Test
    fun `автоопределение находит синтетическую доску`() {
        val frame = SyntheticBoard.render(startCells(), cell = 80, margin = 20)
        val rect = Vision.autodetect(frame)
        assertNotNull("доска должна найтись", rect)
        val r = rect!!
        assertEquals(20f, r[0], 12f)
        assertEquals(20f, r[1], 12f)
        assertEquals(640f, r[2], 16f)
        assertEquals(640f, r[3], 16f)
    }

    @Test
    fun `автоопределение работает и в другой теме`() {
        val frame = SyntheticBoard.render(startCells(), cell = 64, margin = 12, darkTheme = true)
        val rect = Vision.autodetect(frame)
        assertNotNull(rect)
        assertEquals(512f, rect!![2], 20f)
    }

    @Test
    fun `калибровка читает начальную позицию`() {
        val frame = SyntheticBoard.render(startCells())
        val rect = Vision.autodetect(frame)!!
        val cal = Vision.calibrate(frame, rect)
        assertTrue("калибровка должна пройти: ${cal.problems}", cal.ok)
        assertEquals(32, cal.matched)

        val res = Vision.read(cal.reader, frame, cal.geometry)
        assertEquals(32, res.count)
        assertEquals(startCells().toList(), res.pieces.toList())
    }

    @Test
    fun `трекер распознаёт ход`() {
        val cells = startCells()
        val frame = SyntheticBoard.render(cells)
        val cal = Vision.calibrate(frame, Vision.autodetect(frame)!!)
        assertTrue(cal.ok)

        val after = cells.copyOf()
        after[12] = 0                                   // e2 пусто
        after[28] = Piece.of(Piece.PAWN, Piece.WHITE)   // e4 пешка
        val frame2 = SyntheticBoard.render(after)
        val res2 = Vision.read(cal.reader, frame2, cal.geometry)
        assertEquals(0, res2.pieces[12])
        assertEquals(Piece.of(Piece.PAWN, Piece.WHITE), res2.pieces[28])

        val tracker = Tracker { listOf("e2e4") }
        tracker.adopt(cells, true)
        val upd = tracker.observe(res2.pieces)
        assertEquals(Status.MOVE, upd.status)
        assertEquals("e2e4", upd.move)
    }

    @Test
    fun `перекрытая доска видна как перекрытая`() {
        val frame = SyntheticBoard.render(startCells())
        val rect = Vision.autodetect(frame)!!
        val geom = BoardGeometry(rect[0], rect[1], rect[2], rect[3], false)
        assertEquals("чистая доска не должна считаться закрытой",
            0, Vision.boardHealth(frame, geom).covered)

        // «пузырь чата» поверх левого верхнего угла доски
        val px = frame.argb.copyOf()
        val w = frame.width
        for (y in 30 until 220) for (x in 30 until 320) px[y * w + x] = 0xFFFFFFFF.toInt()
        val dirty = Frame(frame.width, frame.height, px)
        val h = Vision.boardHealth(dirty, geom)
        assertTrue("перекрытие должно замечаться, а закрыто ${h.covered}", h.covered > 4)
    }

}
