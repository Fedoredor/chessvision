"""Распознавание шахматной позиции по скриншоту доски.

Почему так, а не «в лоб»:

* Для каждой клетки фон оценивается отдельно (мода гистограммы), поэтому
  подсветка последнего хода, тема доски и градиенты не мешают.
* Тип фигуры определяется по СИЛУЭТУ (маска «пиксель отличается от фона»),
  а не по яркости. Это принципиально: белая фигура на кремовой клетке
  темнее фона, а на бирюзовой — светлее, поэтому знак контраста «мигает»
  от клетки к клетке. Силуэт же одинаков для белых и чёрных фигур.
* Цвет (белая/чёрная) определяется отдельно — по яркости пикселей силуэта,
  с порогом по Отсу на всей доске.
* Шаблоны не нарисованы руками, а снимаются с самой доски в начальной
  позиции, поэтому работают с любым набором фигур и любой темой.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field

import chess
import cv2
import numpy as np

from .geometry import BoardGeometry

__all__ = [
    "CELL", "PieceReader", "Calibration", "calibrate", "autodetect_board",
    "shape_map", "annotate",
]

CELL = 48              # сторона карты силуэта (пиксели)
MIN_SCORE = 0.62       # порог NCC по силуэту
MIN_AREA = 0.07        # доля «нефоновых» пикселей, ниже — клетка пустая
SHIFT = 2              # поиск сдвига ±2 px


# --------------------------------------------------------------------- утилиты
def bg_level(gray: np.ndarray) -> float:
    """Фоновый уровень клетки = мода гистограммы (фон занимает больше площади)."""
    g = np.asarray(gray, np.uint8)
    hist = np.bincount((g >> 2).ravel(), minlength=64).astype(np.float32)
    hist = np.convolve(hist, np.array([1, 2, 3, 2, 1], np.float32) / 9.0, mode="same")
    b = int(np.argmax(hist))
    lo, hi = max(0, (b - 1) * 4), min(256, (b + 2) * 4)
    sel = gray[(gray >= lo) & (gray < hi)]
    if sel.size < 16:
        return float(np.median(gray))
    return float(sel.mean())


def bg_colour(cell_bgr: np.ndarray) -> np.ndarray:
    """Фоновый ЦВЕТ клетки: мода отдельно по каждому каналу BGR.

    Цвет важнее яркости: светлая фигура на кремовой клетке почти не отличается
    по яркости, зато отличается по синему каналу (кремовый «желтит»).
    """
    flat = cell_bgr.reshape(-1, 3)
    out = np.empty(3, np.float32)
    for ch in range(3):
        hist = np.bincount(flat[:, ch], minlength=256)
        b = int(hist.argmax())
        lo, hi = max(0, b - 6), min(256, b + 7)
        sel = flat[:, ch][(flat[:, ch] >= lo) & (flat[:, ch] < hi)]
        out[ch] = float(sel.mean()) if sel.size else float(b)
    return out


def shape_map(cell_bgr: np.ndarray) -> tuple[np.ndarray, float, float]:
    """Клетка -> (карта силуэта CELL x CELL, яркость фигуры, доля площади).

    Силуэт = маска «цвет пикселя заметно отличается от фона клетки»
    (максимум по каналам BGR). Так одинаково хорошо ловятся и тёмные фигуры
    на светлом, и светлые на светлом, и любой набор фигур.
    """
    if cell_bgr.size == 0 or min(cell_bgr.shape[:2]) < 8:
        return np.zeros((CELL, CELL), np.float32), 0.0, 0.0
    cell = cell_bgr.astype(np.int16)
    bg = bg_colour(cell_bgr).astype(np.int16)
    dist = np.abs(cell - bg[None, None, :]).max(axis=2)
    peak = float(np.percentile(dist, 99.5))
    if peak < 22.0:
        return np.zeros((CELL, CELL), np.float32), float(bg.mean()), 0.0

    thr = max(16.0, 0.12 * peak)
    mask = (dist > thr).astype(np.uint8)
    k = max(2, int(min(mask.shape) * 0.025))
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((k, k), np.uint8))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((k * 2 + 1, k * 2 + 1), np.uint8))
    area = float(mask.mean())
    if area < 0.02:
        return np.zeros((CELL, CELL), np.float32), float(bg.mean()), 0.0

    # цвет фигуры — по «ядру» силуэта, без обводки: у белых фигур обводка тёмная,
    # и по ней легко принять белую фигуру за чёрную
    gray = cv2.cvtColor(cell_bgr, cv2.COLOR_BGR2GRAY).astype(np.float32)
    core = cv2.erode(mask, np.ones((5, 5), np.uint8))
    sel = core > 0 if core.any() else mask > 0
    lum = float(np.median(gray[sel]))

    shape = cv2.resize(mask.astype(np.float32), (CELL, CELL), interpolation=cv2.INTER_AREA)
    shape = cv2.GaussianBlur(shape, (3, 3), 0)
    return shape, lum, area


def corner_colour(cell_bgr: np.ndarray) -> np.ndarray:
    """Цвет фона клетки по её четырём углам (быстро, фигура в центре не мешает)."""
    h, w = cell_bgr.shape[:2]
    k = max(3, int(min(h, w) * 0.18))
    patches = [cell_bgr[2:2 + k, 2:2 + k], cell_bgr[2:2 + k, w - 2 - k:w - 2],
               cell_bgr[h - 2 - k:h - 2, 2:2 + k], cell_bgr[h - 2 - k:h - 2, w - 2 - k:w - 2]]
    return np.median(np.concatenate([p.reshape(-1, 3) for p in patches]), axis=0)


def board_health(shot: np.ndarray, geom, origin: tuple[int, int] = (0, 0)) -> dict:
    """Проверка «доска видна целиком?».

    Раньше смотрели только углы клетки — пузырь чата, накрывший середину,
    не замечался, и позиция читалась обрезанной. Теперь берём 8 точек по
    периметру клетки (там фон, а не фигура) и сравниваем ЦВЕТ, а не яркость:
    белый пузырь и кремовая клетка по яркости почти совпадают.
    """
    ox, oy = origin
    pos = (0.15, 0.5, 0.85)
    colors = np.zeros((64, 8, 3), np.float32)
    for sq in range(64):
        x0, y0, x1, y1 = geom.square_rect(sq)
        cw = max(1.0, x1 - x0)
        ch = max(1.0, y1 - y0)
        k = 0
        for sy in pos:
            for sx in pos:
                if sx == 0.5 and sy == 0.5:
                    continue
                cx = x0 + sx * cw - ox
                cy = y0 + sy * ch - oy
                r = max(1, int(cw * 0.04))
                r2 = max(1, int(ch * 0.04))
                cell = _crop(shot, int(cx) - r, int(cy) - r2, int(cx) + r + 1, int(cy) + r2 + 1)
                colors[sq, k] = cell.reshape(-1, 3).mean(axis=0) if cell.size else 0.0
                k += 1

    lum = colors.mean(axis=2)
    hist, _ = np.histogram(lum, bins=32, range=(0, 256))
    b1 = int(np.argmax(hist))
    masked = hist.astype(np.int64).copy()
    masked[max(0, b1 - 2):min(32, b1 + 3)] = -1
    b2 = int(np.argmax(masked))
    if b1 == b2:
        return {"covered": 64, "light": [0, 0, 0], "dark": [0, 0, 0]}

    bins = np.clip((lum / 8).astype(int), 0, 31)

    def ref(b: int) -> np.ndarray:
        sel = bins == b
        if not sel.any():
            return np.array([b * 8, b * 8, b * 8], np.float32)
        return colors[sel].mean(axis=0)

    ref_a, ref_b = ref(b1), ref(b2)
    near_a = np.abs(colors - ref_a).sum(axis=2) < 60
    near_b = np.abs(colors - ref_b).sum(axis=2) < 60
    ok = (near_a | near_b).sum(axis=1)
    covered = int((ok < 5).sum())
    return {"covered": covered,
            "light": ref_a.astype(int).tolist(),
            "dark": ref_b.astype(int).tolist()}


def board_palette_ok(health: dict) -> bool:
    """Похоже ли это на шахматную доску вообще (фон светлый + тёмный)."""
    light = np.array(health.get("light") or [0, 0, 0], float)
    dark = np.array(health.get("dark") or [0, 0, 0], float)
    return float(np.abs(light - dark).sum()) > 90.0


def last_move_hint(shot: np.ndarray, geom, pieces: dict, origin: tuple[int, int] = (0, 0)) -> int | None:
    """Поле, КУДА пришла фигура последним ходом (по подсветке хода).

    chess.com подсвечивает два поля последнего хода тонировкой. Находим поля,
    чей фон сильнее всего отличается от обычного цвета светлых/тёмных клеток,
    и берём из пары то, где стоит фигура, — это поле назначения.
    По нему восстанавливается, чей сейчас ход.
    """
    ox, oy = origin
    cols = np.zeros((64, 3), np.float32)
    for sq in range(64):
        x0, y0, x1, y1 = geom.square_rect(sq)
        cell = _crop(shot, x0 - ox, y0 - oy, x1 - ox, y1 - oy)
        cols[sq] = corner_colour(cell) if cell.size else 0.0

    lum = cols.mean(axis=1)
    mid = float(np.median(lum))
    light = lum > mid
    if light.all() or not light.any():
        return None
    ref_light = np.median(cols[light], axis=0)
    ref_dark = np.median(cols[~light], axis=0)
    dev_light = np.abs(cols - ref_light).sum(axis=1)
    dev_dark = np.abs(cols - ref_dark).sum(axis=1)
    dev = np.where(light, dev_light, dev_dark)

    order = np.argsort(dev)[::-1]
    cands = [int(sq) for sq in order if dev[sq] > 30][:4]
    best = None
    for i in range(len(cands)):
        for j in range(i + 1, len(cands)):
            a, b = cands[i], cands[j]
            pa, pb = pieces.get(a), pieces.get(b)
            if (pa is None) != (pb is None):  # ровно одна клетка с фигурой
                score = dev[a] + dev[b]
                if best is None or score > best[0]:
                    best = (score, b if pb is not None else a)
    return best[1] if best else None


def _crop(shot: np.ndarray, x0: float, y0: float, x1: float, y1: float) -> np.ndarray:
    h, w = shot.shape[:2]
    a, b = int(round(x0)), int(round(y0))
    c, d = int(round(x1)), int(round(y1))
    a, b = max(0, a), max(0, b)
    c, d = min(w, c), min(h, d)
    if c <= a or d <= b:
        return np.zeros((1, 1, 3), np.uint8)
    return shot[b:d, a:c]


def shift_stack(cells: np.ndarray, r: int = SHIFT) -> np.ndarray:
    """Все сдвиги (2r+1)^2; индекс 0 — без сдвига."""
    out = [cells]
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            if dx or dy:
                out.append(np.roll(np.roll(cells, dy, axis=1), dx, axis=2))
    return np.stack(out)


def colour_threshold(lums: np.ndarray) -> float:
    """Порог «белая/чёрная» по яркости силуэтов (метод Отсу, с запасным 150)."""
    vals = np.asarray(lums, np.float32)
    if vals.size < 2 or float(vals.max() - vals.min()) < 60:
        return 150.0
    lo, hi = float(vals.min()), float(vals.max())
    hist, edges = np.histogram(vals, bins=32, range=(lo - 0.5, hi + 0.5))
    centers = (edges[:-1] + edges[1:]) / 2.0
    total = hist.sum()
    best_t, best_v = 150.0, -1.0
    for i in range(1, len(hist)):
        w0, w1 = hist[:i].sum(), hist[i:].sum()
        if w0 < 1 or w1 < 1:
            continue
        m0 = float((hist[:i] * centers[:i]).sum() / w0)
        m1 = float((hist[i:] * centers[i:]).sum() / w1)
        v = w0 * w1 * (m1 - m0) ** 2
        if v > best_v:
            best_v, best_t = v, (m0 + m1) / 2.0
    return float(best_t)


# ------------------------------------------------------------------ результат
@dataclass
class ReadResult:
    pieces: dict[int, chess.Piece]
    scores: np.ndarray            # (64,) лучший NCC по клетке
    areas: np.ndarray             # (64,) доля силуэта
    lums: np.ndarray              # (64,) яркость силуэта
    confident: np.ndarray         # (64,) bool
    threshold: float = 150.0

    @property
    def mean_score(self) -> float:
        return float(self.scores[self.confident].mean()) if self.confident.any() else 0.0

    def as_board(self, turn: bool = chess.WHITE, castling: str = "-") -> chess.Board:
        return chess.Board(placement_fen(self.pieces, turn, castling))


def placement_fen(pieces: dict[int, chess.Piece], turn: bool, castling: str) -> str:
    rows = []
    for rank in range(7, -1, -1):
        empty = 0
        row = ""
        for file_idx in range(8):
            p = pieces.get(chess.square(file_idx, rank))
            if p is None:
                empty += 1
            else:
                if empty:
                    row += str(empty)
                    empty = 0
                row += p.symbol()
        if empty:
            row += str(empty)
        rows.append(row)
    return f"{'/'.join(rows)} {'w' if turn == chess.WHITE else 'b'} {castling} - 0 1"


_placement_fen = placement_fen  # прежнее имя


# ------------------------------------------------------------------- читатель
class PieceReader:
    """Сопоставление силуэтов клеток с шаблонами типов фигур."""

    def __init__(self, keys, templates: np.ndarray):
        self.keys = [int(k) for k in keys]
        self.templates = np.asarray(templates, np.float32).reshape(len(self.keys), CELL, CELL)
        flat = self.templates.reshape(len(self.keys), -1)
        centered = flat - flat.mean(axis=1, keepdims=True)
        norm = np.linalg.norm(centered, axis=1, keepdims=True)
        self._unit = (centered / np.maximum(norm, 1e-6)).astype(np.float32)
        self._dim = flat.shape[1]

    # ------------------------------------------------------------------ чтение
    def read(self, shot: np.ndarray, geom, origin: tuple[int, int] = (0, 0)) -> ReadResult:
        ox, oy = origin
        shapes = np.empty((64, CELL, CELL), np.float32)
        lums = np.zeros(64, np.float32)
        areas = np.zeros(64, np.float32)
        for sq in range(64):
            x0, y0, x1, y1 = geom.square_rect(sq)
            shapes[sq], lums[sq], areas[sq] = shape_map(
                _crop(shot, x0 - ox, y0 - oy, x1 - ox, y1 - oy))

        variants = shift_stack(shapes, SHIFT)
        k = variants.shape[0]
        x = variants.reshape(k * 64, -1)
        x = x - x.mean(axis=1, keepdims=True)
        norm = np.linalg.norm(x, axis=1)
        xn = x / np.maximum(norm, 1e-6)[:, None]
        scores = (xn @ self._unit.T).reshape(k, 64, len(self.keys)).max(axis=0)

        best = scores.argmax(axis=1)
        top = scores[np.arange(64), best]
        confident = (top >= MIN_SCORE) & (areas >= MIN_AREA)
        thr = colour_threshold(lums[confident]) if confident.any() else 150.0

        pieces: dict[int, chess.Piece] = {}
        for sq in range(64):
            if not confident[sq]:
                continue
            white = bool(lums[sq] >= thr)
            pieces[sq] = chess.Piece(self.keys[best[sq]], chess.WHITE if white else chess.BLACK)
        return ReadResult(pieces, top.astype(np.float32), areas, lums,
                           confident, thr)

    # ---------------------------------------------------------------------- IO
    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        np.savez_compressed(path, keys=np.array(self.keys, np.int32), tpl=self.templates)

    @classmethod
    def load(cls, path: str) -> "PieceReader":
        with np.load(path) as data:
            return cls(data["keys"], data["tpl"])

    def similarity(self, shape: np.ndarray, code: int) -> float:
        idx = self.keys.index(code)
        a = shape.ravel() - shape.mean()
        b = self.templates[idx].ravel() - self.templates[idx].mean()
        na, nb = np.linalg.norm(a), np.linalg.norm(b)
        return float(a @ b / max(na * nb, 1e-6))


# ---------------------------------------------------------------- калибровка
@dataclass
class Calibration:
    reader: PieceReader
    geometry: object
    matched: int
    total: int
    problems: list[str] = field(default_factory=list)
    samples: dict = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        # matched считается по 32 полям начальной расстановки
        return self.matched >= 30 and not self.problems


START_BOARD = chess.Board()


def _build_reader(samples_by_type: dict[int, list[np.ndarray]]) -> PieceReader:
    keys = sorted(samples_by_type)
    tpl = np.stack([np.mean(np.stack(samples_by_type[k]), axis=0) for k in keys])
    return PieceReader(keys, tpl)


def _validate_start(by_type: dict[int, list[np.ndarray]], reader: PieceReader,
                    res: ReadResult | None = None) -> list[str]:
    problems: list[str] = []
    total = sum(len(v) for v in by_type.values())
    if total != 32:
        problems.append(f"на доске {total} фигур вместо 32 — нужна начальная позиция")
    pair = by_type.get(chess.PAWN)
    if pair and len(pair) >= 8:
        sims = [reader.similarity(s, chess.PAWN) for s in pair]
        good = sum(1 for s in sims if s >= 0.65)
        if good < len(pair) - 2:
            problems.append("фигуры на доске не похожи на начальную позицию")

    # Самая надёжная проверка: в начальной позиции середина доски ПУСТАЯ.
    # Если рамка сдвинута на полклетки, в середине окажутся «обрезки» фигур,
    # и такая калибровка не должна пройти.
    if res is not None:
        start_squares = set(START_BOARD.piece_map())
        extra = [sq for sq in res.pieces if sq not in start_squares]
        if len(extra) > 8:
            problems.append(f"рамка сдвинута: в середине доски {len(extra)} фигур")
        elif len(extra) > 1:
            problems.append("партия уже начата — позиция не начальная")
        if len(res.pieces) < 31:
            problems.append("распознано меньше 31 фигуры")
        if res.confident.any() and res.mean_score < 0.84:
            problems.append("фигуры распознаны неуверенно")
    return problems


def calibrate(shot: np.ndarray, left: float, top: float, width: float, height: float,
              origin: tuple[int, int] = (0, 0)) -> Calibration:
    """Снимает шаблоны силуэтов со стартовой позиции и определяет ориентацию."""
    best: Calibration | None = None
    for flipped in (False, True):
        geom = BoardGeometry(left, top, width, height, flipped)
        by_type: dict[int, list[np.ndarray]] = {}
        ox, oy = origin
        for sq, piece in START_BOARD.piece_map().items():
            x0, y0, x1, y1 = geom.square_rect(sq)
            shape, _lum, _area = shape_map(_crop(shot, x0 - ox, y0 - oy, x1 - ox, y1 - oy))
            by_type.setdefault(piece.piece_type, []).append(shape)
        reader = _build_reader(by_type)
        res = reader.read(shot, geom, origin)
        matched = sum(1 for sq, p in START_BOARD.piece_map().items()
                      if (q := res.pieces.get(sq)) is not None
                      and q.piece_type == p.piece_type and q.color == p.color)
        problems = _validate_start(by_type, reader, res)
        cand = Calibration(reader, geom, matched, 32, problems, by_type)
        if best is None or (not cand.problems, cand.matched) > (not best.problems, best.matched):
            best = cand
    assert best is not None
    return best


# ------------------------------------------------------- автоопределение доски
def _checker_score(crop: np.ndarray) -> float:
    if crop.size == 0 or min(crop.shape[:2]) < 120:
        return 0.0
    g = crop.astype(np.float32) if crop.ndim == 2 else \
        cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY).astype(np.float32)
    cells = cv2.resize(g, (8, 8), interpolation=cv2.INTER_AREA)
    idx = (np.add.outer(np.arange(8), np.arange(8)) % 2).astype(bool)
    a, b = cells[idx], cells[~idx]
    gap = abs(float(a.mean() - b.mean()))
    spread = float(a.std() + b.std())
    if gap < 8.0:
        return 0.0
    return gap / (spread + 4.0)


def _checker_template(c: int, phase: int = 0) -> np.ndarray:
    t = np.empty((8 * c, 8 * c), np.float32)
    for i in range(8):
        for j in range(8):
            t[i * c:(i + 1) * c, j * c:(j + 1) * c] = 1.0 if (i + j + phase) % 2 == 0 else -1.0
    return t


def _refine_board(gray: np.ndarray, left: float, top: float, width: float, height: float):
    """Локальный поиск границ доски: координатный спуск по 4 параметрам.

    Ширина и высота подстраиваются независимо — доска на экране бывает
    не идеально квадратной (зум, масштабирование экрана, обрезка окна).
    """
    h, w = gray.shape
    f = 2
    g = cv2.resize(gray, (max(1, w // f), max(1, h // f)), interpolation=cv2.INTER_AREA)
    gh, gw = g.shape

    def score(rect) -> float:
        l, t, ww, hh = rect
        if ww < 80 or hh < 80 or l < -6 or t < -6 or l + ww > gw + 6 or t + hh > gh + 6:
            return -1.0
        l2 = int(min(max(l, 0), gw - 2))
        t2 = int(min(max(t, 0), gh - 2))
        w2 = int(min(ww, gw - l2))
        h2 = int(min(hh, gh - t2))
        return _checker_score(g[t2:t2 + h2, l2:l2 + w2])

    rect = [left / f, top / f, width / f, height / f]
    best = score(rect)
    steps = [max(1.0, rect[2] / 40), max(1.0, rect[3] / 40),
             max(1.0, rect[2] / 40), max(1.0, rect[3] / 40)]
    for _ in range(8):
        improved = False
        for i in range(4):
            for delta in (-steps[i], steps[i]):
                cand = list(rect)
                cand[i] += delta
                sc = score(cand)
                if sc > best + 1e-4:
                    best, rect = sc, cand
                    improved = True
        if not improved:
            steps = [s / 2.0 for s in steps]
    return best, rect[0] * f, rect[1] * f, rect[2] * f, rect[3] * f


def autodetect_candidates(shot: np.ndarray, origin: tuple[int, int] = (0, 0),
                          limit: int = 6) -> list[tuple[float, int, int, int, int]]:
    """Несколько лучших гипотез «где доска» — от лучшей к худшей."""
    h, w = shot.shape[:2]
    if h < 200 or w < 200:
        return []
    gray = cv2.cvtColor(shot, cv2.COLOR_BGR2GRAY)

    f = 4
    small = cv2.resize(gray, (max(1, w // f), max(1, h // f)), interpolation=cv2.INTER_AREA)
    small_f = small.astype(np.float32)
    H, W = small_f.shape

    cands: list[tuple[float, float, float, float]] = []
    for phase in (0, 1):
        for c in range(max(5, min(H, W) // 220), min(H, W) // 8 + 1):
            size = 8 * c
            if size > H or size > W:
                continue
            tpl = _checker_template(c, phase)
            res = cv2.matchTemplate(small_f, tpl, cv2.TM_CCOEFF_NORMED)
            _, mx, _, loc = cv2.minMaxLoc(res)
            if mx > 0.08:
                cands.append((float(mx), loc[0] * f, loc[1] * f, size * f))

    if not cands:
        return []
    cands.sort(key=lambda c: c[0], reverse=True)

    out: list[tuple[float, int, int, int, int]] = []
    seen: list[tuple[float, float, float]] = []
    for _, left, top, side in cands:
        if any(abs(left - s[0]) < side * 0.15 and abs(top - s[1]) < side * 0.15
               for s in seen):
            continue
        seen.append((left, top, side))
        sc, l, t, ww, hh = _refine_board(gray, left, top, side, side)
        if sc < 1.4 or min(ww, hh) < 180:
            continue
        if l < -2 or t < -2 or l + ww > w + 2 or t + hh > h + 2:
            continue  # гипотеза вылезла за пределы экрана — это не доска
        l, t = max(0.0, l), max(0.0, t)
        out.append((sc, int(round(l + origin[0])), int(round(t + origin[1])),
                    int(round(ww)), int(round(hh))))
        if len(out) >= limit:
            break
    out.sort(key=lambda r: r[0], reverse=True)
    return out


def autodetect_board(shot: np.ndarray, origin: tuple[int, int] = (0, 0)):
    """Лучшая гипотеза о доске: ``(score, left, top, width, height)`` или None."""
    found = autodetect_candidates(shot, origin, limit=1)
    return found[0] if found else None


# ------------------------------------------------------------------- отладка
def annotate(shot: np.ndarray, geom, res: ReadResult,
             origin: tuple[int, int] = (0, 0)) -> np.ndarray:
    """Картинка с сеткой и распознанными фигурами — для проверки калибровки."""
    img = shot.copy()
    ox, oy = origin
    for sq in range(64):
        x0, y0, x1, y1 = geom.square_rect(sq)
        p0 = (int(x0 - ox), int(y0 - oy))
        p1 = (int(x1 - ox), int(y1 - oy))
        color = (0, 200, 0) if res.confident[sq] else (0, 0, 255)
        cv2.rectangle(img, p0, p1, color, 1)
        p = res.pieces.get(sq)
        label = p.symbol() if p else "-"
        cx, cy = (p0[0] + p1[0]) // 2, (p0[1] + p1[1]) // 2
        cv2.putText(img, label, (cx - 8, cy + 8), cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                    (0, 0, 0), 3, cv2.LINE_AA)
        cv2.putText(img, label, (cx - 8, cy + 8), cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                    (0, 255, 255), 1, cv2.LINE_AA)
    return img
