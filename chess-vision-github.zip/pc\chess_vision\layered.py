"""Прозрачное окно поверх всех окон: Win32 layered window с per-pixel alpha.

Обычное Tk-окно с ``-transparentcolor`` даёт рваные края и «дрожащую»
прозрачность. Layered window через ``UpdateLayeredWindow`` умеет настоящую
альфу, поэтому стрелка выглядит как нарисованная поверх игры.
"""

from __future__ import annotations

import ctypes
import os
from ctypes import byref, wintypes

import numpy as np

__all__ = ["OverlayWindow"]

user32 = ctypes.WinDLL("user32", use_last_error=True)
gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

LRESULT = ctypes.c_ssize_t
WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wintypes.HWND, wintypes.UINT,
                             wintypes.WPARAM, wintypes.LPARAM)

WS_POPUP = 0x80000000
WS_EX_LAYERED = 0x00080000
WS_EX_TRANSPARENT = 0x00000020
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_TOPMOST = 0x00000008
WS_EX_NOACTIVATE = 0x08000000
SW_SHOWNOACTIVATE = 4
SW_HIDE = 0
ULW_ALPHA = 0x00000002
AC_SRC_OVER = 0x00
AC_SRC_ALPHA = 0x01
HWND_TOPMOST = wintypes.HWND(-1)
SWP_NOMOVE = 0x0002
SWP_NOSIZE = 0x0001
SWP_NOACTIVATE = 0x0010


class WNDCLASSEXW(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.UINT),
        ("style", wintypes.UINT),
        ("lpfnWndProc", WNDPROC),
        ("cbClsExtra", ctypes.c_int),
        ("cbWndExtra", ctypes.c_int),
        ("hInstance", wintypes.HINSTANCE),
        ("hIcon", wintypes.HICON),
        ("hCursor", wintypes.HANDLE),
        ("hbrBackground", wintypes.HBRUSH),
        ("lpszMenuName", wintypes.LPCWSTR),
        ("lpszClassName", wintypes.LPCWSTR),
        ("hIconSm", wintypes.HICON),
    ]


class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [
        ("biSize", wintypes.DWORD),
        ("biWidth", wintypes.LONG),
        ("biHeight", wintypes.LONG),
        ("biPlanes", wintypes.WORD),
        ("biBitCount", wintypes.WORD),
        ("biCompression", wintypes.DWORD),
        ("biSizeImage", wintypes.DWORD),
        ("biXPelsPerMeter", wintypes.LONG),
        ("biYPelsPerMeter", wintypes.LONG),
        ("biClrUsed", wintypes.DWORD),
        ("biClrImportant", wintypes.DWORD),
    ]


class BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", wintypes.DWORD * 3)]


class BLENDFUNCTION(ctypes.Structure):
    _fields_ = [
        ("BlendOp", ctypes.c_ubyte),
        ("BlendFlags", ctypes.c_ubyte),
        ("SourceConstantAlpha", ctypes.c_ubyte),
        ("AlphaFormat", ctypes.c_ubyte),
    ]


user32.DefWindowProcW.restype = LRESULT
user32.DefWindowProcW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.CreateWindowExW.restype = wintypes.HWND
user32.CreateWindowExW.argtypes = [wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR,
                                   wintypes.DWORD, ctypes.c_int, ctypes.c_int,
                                   ctypes.c_int, ctypes.c_int, wintypes.HWND, wintypes.HMENU,
                                   wintypes.HINSTANCE, wintypes.LPVOID]
user32.UpdateLayeredWindow.restype = wintypes.BOOL
user32.UpdateLayeredWindow.argtypes = [wintypes.HWND, wintypes.HDC, ctypes.POINTER(wintypes.POINT),
                                       ctypes.POINTER(wintypes.SIZE), wintypes.HDC,
                                       ctypes.POINTER(wintypes.POINT), wintypes.DWORD,
                                       ctypes.POINTER(BLENDFUNCTION), wintypes.DWORD]

# Без явных argtypes ctypes режет 64-битные HANDLE до int32
HGDI = ctypes.c_void_p
user32.RegisterClassExW.restype = wintypes.ATOM
user32.RegisterClassExW.argtypes = [ctypes.POINTER(WNDCLASSEXW)]
user32.LoadCursorW.restype = wintypes.HANDLE
user32.LoadCursorW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR]
user32.GetDC.restype = HGDI
user32.GetDC.argtypes = [wintypes.HWND]
user32.ReleaseDC.restype = ctypes.c_int
user32.ReleaseDC.argtypes = [wintypes.HWND, HGDI]
user32.ShowWindow.restype = wintypes.BOOL
user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
user32.SetWindowPos.restype = wintypes.BOOL
user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
                                ctypes.c_int, ctypes.c_int, wintypes.UINT]
user32.DestroyWindow.restype = wintypes.BOOL
user32.DestroyWindow.argtypes = [wintypes.HWND]
gdi32.CreateCompatibleDC.restype = HGDI
gdi32.CreateCompatibleDC.argtypes = [HGDI]
gdi32.CreateDIBSection.restype = HGDI
gdi32.CreateDIBSection.argtypes = [HGDI, ctypes.POINTER(BITMAPINFO), wintypes.UINT,
                                   ctypes.POINTER(ctypes.c_void_p), wintypes.HANDLE, wintypes.DWORD]
gdi32.SelectObject.restype = HGDI
gdi32.SelectObject.argtypes = [HGDI, HGDI]
gdi32.DeleteObject.restype = wintypes.BOOL
gdi32.DeleteObject.argtypes = [HGDI]
gdi32.DeleteDC.restype = wintypes.BOOL
gdi32.DeleteDC.argtypes = [HGDI]
kernel32.GetModuleHandleW.restype = wintypes.HMODULE
kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]


def _wnd_proc(hwnd, msg, wparam, lparam):
    return user32.DefWindowProcW(hwnd, msg, wparam, lparam)


_WNDPROC = WNDPROC(_wnd_proc)
_registered: set[str] = set()


def _register_class(name: str) -> None:
    if name in _registered:
        return
    hinst = kernel32.GetModuleHandleW(None)
    wc = WNDCLASSEXW()
    wc.cbSize = ctypes.sizeof(WNDCLASSEXW)
    wc.style = 0
    wc.lpfnWndProc = _WNDPROC
    wc.hInstance = hinst
    wc.hCursor = user32.LoadCursorW(None, wintypes.LPCWSTR(32512))  # IDC_ARROW
    wc.lpszClassName = name
    if not user32.RegisterClassExW(byref(wc)):
        err = ctypes.get_last_error()
        if err != 1410:  # ERROR_CLASS_ALREADY_EXISTS
            raise OSError(f"RegisterClassExW failed: {err}")
    _registered.add(name)


class OverlayWindow:
    """Один слой-окно. Показывает RGBA-картинку в заданной точке экрана."""

    def __init__(self, name: str = "chessv"):
        self._class = f"ChessVisionOverlay_{os.getpid()}_{name}"
        self._hwnd: int | None = None
        self._visible = False

    # ------------------------------------------------------------------ окно
    def _create(self) -> int:
        if self._hwnd:
            return self._hwnd
        _register_class(self._class)
        ex = (WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW
              | WS_EX_TOPMOST | WS_EX_NOACTIVATE)
        hwnd = user32.CreateWindowExW(ex, self._class, "chess-vision", WS_POPUP,
                                      0, 0, 1, 1, None, None,
                                      kernel32.GetModuleHandleW(None), None)
        if not hwnd:
            raise OSError(f"CreateWindowExW failed: {ctypes.get_last_error()}")
        self._hwnd = hwnd
        return hwnd

    def _paint(self, x: int, y: int, w: int, h: int, bgra: bytes) -> None:
        hwnd = self._create()
        screen_dc = user32.GetDC(None)
        mem_dc = gdi32.CreateCompatibleDC(screen_dc)
        bmi = BITMAPINFO()
        bmi.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        bmi.bmiHeader.biWidth = w
        bmi.bmiHeader.biHeight = -h
        bmi.bmiHeader.biPlanes = 1
        bmi.bmiHeader.biBitCount = 32
        bmi.bmiHeader.biCompression = 0  # BI_RGB
        bits = ctypes.c_void_p()
        hbmp = gdi32.CreateDIBSection(mem_dc, byref(bmi), 0, byref(bits), None, 0)
        old = gdi32.SelectObject(mem_dc, hbmp)
        ctypes.memmove(bits, bgra, w * h * 4)

        dst = wintypes.POINT(int(x), int(y))
        size = wintypes.SIZE(int(w), int(h))
        src = wintypes.POINT(0, 0)
        blend = BLENDFUNCTION(AC_SRC_OVER, 0, 255, AC_SRC_ALPHA)
        ok = user32.UpdateLayeredWindow(hwnd, screen_dc, byref(dst), byref(size),
                                        mem_dc, byref(src), 0, byref(blend), ULW_ALPHA)

        gdi32.SelectObject(mem_dc, old)
        gdi32.DeleteObject(hbmp)
        gdi32.DeleteDC(mem_dc)
        user32.ReleaseDC(None, screen_dc)
        if not ok:
            raise OSError(f"UpdateLayeredWindow failed: {ctypes.get_last_error()}")

    def set_display_affinity(self, enabled: bool = True) -> bool:
        """WDA_EXCLUDEFROMCAPTURE: окно не попадает в скриншоты (и в наш захват)."""
        hwnd = self._create()
        try:
            user32.SetWindowDisplayAffinity.argtypes = [wintypes.HWND, wintypes.DWORD]
            user32.SetWindowDisplayAffinity.restype = wintypes.BOOL
            return bool(user32.SetWindowDisplayAffinity(hwnd, 0x11 if enabled else 0))
        except Exception:
            return False

    # ------------------------------------------------------------------- API
    def show(self, x: int, y: int, image) -> None:
        """Показать PIL RGBA-картинку в точке (x, y) в пикселях экрана."""
        w, h = image.size
        if w <= 0 or h <= 0:
            return
        arr = np.asarray(image.convert("RGBA"), dtype=np.uint8)
        bgra = np.empty((h, w, 4), np.uint8)
        bgra[..., 0] = arr[..., 2]
        bgra[..., 1] = arr[..., 1]
        bgra[..., 2] = arr[..., 0]
        bgra[..., 3] = arr[..., 3]
        self._paint(x, y, w, h, bgra.tobytes())
        hwnd = self._create()
        user32.SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0,
                            SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE)
        user32.ShowWindow(hwnd, SW_SHOWNOACTIVATE)
        self._visible = True

    def hide(self) -> None:
        if self._hwnd and self._visible:
            user32.ShowWindow(self._hwnd, SW_HIDE)
        self._visible = False

    @property
    def visible(self) -> bool:
        return self._visible

    def destroy(self) -> None:
        if self._hwnd:
            user32.DestroyWindow(self._hwnd)
            self._hwnd = None
        self._visible = False
