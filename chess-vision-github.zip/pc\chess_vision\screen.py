"""Захват экрана и сведения о рабочем столе (Windows)."""

from __future__ import annotations

import ctypes

import numpy as np

__all__ = ["enable_dpi_awareness", "virtual_screen", "ScreenCapture"]


def enable_dpi_awareness() -> None:
    """Включает физические пиксели: иначе на масштабе 125% координаты «плывут»."""
    try:
        if ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4)):
            return
    except Exception:
        pass
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
        return
    except Exception:
        pass
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass


def virtual_screen() -> tuple[int, int, int, int]:
    """Границы виртуального рабочего стола: (x, y, width, height)."""
    u = ctypes.windll.user32
    x = u.GetSystemMetrics(76)  # SM_XVIRTUALSCREEN
    y = u.GetSystemMetrics(77)  # SM_YVIRTUALSCREEN
    w = u.GetSystemMetrics(78)  # SM_CXVIRTUALSCREEN
    h = u.GetSystemMetrics(79)  # SM_CYVIRTUALSCREEN
    if w <= 0 or h <= 0:
        w = u.GetSystemMetrics(0)
        h = u.GetSystemMetrics(1)
        x = y = 0
    return x, y, w, h


class ScreenCapture:
    """Быстрый захват прямоугольника экрана (BGR numpy)."""

    def __init__(self) -> None:
        import mss  # локальный импорт: тянем зависимость только при работе

        self._sct = mss.mss()

    def grab(self, left: int, top: int, width: int, height: int) -> np.ndarray:
        width = max(1, int(width))
        height = max(1, int(height))
        shot = self._sct.grab({"left": int(left), "top": int(top),
                               "width": width, "height": height})
        # mss отдаёт BGRA
        return np.asarray(shot)[:, :, :3].copy()

    def grab_full(self) -> tuple[np.ndarray, int, int]:
        x, y, w, h = virtual_screen()
        return self.grab(x, y, w, h), x, y

    def close(self) -> None:
        try:
            self._sct.close()
        except Exception:
            pass
