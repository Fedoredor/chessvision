package com.chessvision.core

/** Что изменилось между кадрами. */
enum class Status { SAME, MOVE, RESYNC, LOST }

class Update(val status: Status, val move: String? = null, val detail: String = "")

/**
 * Ведение партии: сверяет распознанную позицию с историей.
 *
 * Легальные ходы берутся у Stockfish (`go perft 1`), поэтому собственный
 * генератор ходов не нужен — а значит нечему и ошибаться в правилах.
 */
class Tracker(private val legalMoves: (String) -> List<String>) {

    var position: Position? = null
        private set
    var playerColor: Int = Piece.WHITE
    var resynced: Boolean = false
        private set

    fun adopt(cells: IntArray, whiteToMove: Boolean) {
        position = Position.fromPlacement(cells, whiteToMove)
        resynced = true
    }

    fun reset() {
        position = Position.startPosition()
        resynced = false
    }

    fun setTurn(whiteToMove: Boolean) {
        position?.whiteToMove = whiteToMove
    }

    fun observe(cells: IntArray, turnHint: Boolean? = null): Update {
        val cur = position ?: run {
            position = Position.fromPlacement(cells, turnHint ?: (playerColor == Piece.WHITE))
            resynced = true
            return Update(Status.LOST, null, "доска не была инициализирована")
        }
        if (cur.cells.contentEquals(cells)) return Update(Status.SAME)

        val fen = cur.fen()
        val legal = try {
            legalMoves(fen)
        } catch (e: Exception) {
            emptyList()
        }

        val cand = deriveMove(cur.cells, cells)
        if (cand != null) {
            val variants = promotionVariants(cand, cur.cells)
            val found = variants.firstOrNull { it in legal } ?: variants.firstOrNull()
            if (found != null && (legal.isEmpty() || found in legal)) {
                applyMove(cur, found)
                return Update(Status.MOVE, found)
            }
        }

        // очередь могла быть перепутана: пробуем отдать ход другой стороне
        val alt = Position.fromPlacement(cells, !cur.whiteToMove)
        alt.castling = cur.castling
        val altFen = alt.fen()
        val cand2 = deriveMove(cur.cells, cells)
        if (cand2 != null) {
            val altLegal = try {
                legalMoves(altFen)
            } catch (e: Exception) {
                emptyList()
            }
            if (altLegal.isNotEmpty()) {
                position = alt
                resynced = true
                return Update(Status.RESYNC, cand2, "очередь хода была перепутана — исправлено")
            }
        }

        position = Position.fromPlacement(cells, turnHint ?: (playerColor == Piece.WHITE))
        resynced = true
        return Update(Status.LOST, null, "позиция не следует из предыдущей")
    }

    // ---------------------------------------------------------------- ходы

    private fun promotionVariants(uci: String, cells: IntArray): List<String> {
        val from = sq(uci.substring(0, 2))
        val to = sq(uci.substring(2, 4))
        val piece = cells[from]
        val isPawn = piece != 0 && Piece.type(piece) == Piece.PAWN
        val lastRank = (to ushr 3) == 0 || (to ushr 3) == 7
        if (!isPawn || !lastRank) return listOf(uci)
        val base = uci.take(4)
        return if (uci.length == 5) listOf(uci) else listOf(
            base + "q", base + "r", base + "b", base + "n",
        )
    }

    private fun deriveMove(old: IntArray, cur: IntArray): String? {
        val gone = ArrayList<Int>(4)
        val appeared = ArrayList<Int>(4)
        for (sq in 0 until 64) {
            if (old[sq] == cur[sq]) continue
            if (cur[sq] == 0) gone.add(sq) else appeared.add(sq)
        }
        if (gone.isEmpty() || appeared.isEmpty()) return null

        // обычный ход / взятие / превращение
        if (gone.size == 1 && appeared.size == 1) {
            return name(gone[0]) + name(appeared[0])
        }
        // рокировка: ушли две фигуры (король и ладья) — берём ход короля
        if (gone.size == 2 && appeared.size == 2) {
            val kingFrom = gone.firstOrNull { old[it] != 0 && Piece.type(old[it]) == Piece.KING }
            val kingTo = appeared.firstOrNull { cur[it] != 0 && Piece.type(cur[it]) == Piece.KING }
            if (kingFrom != null && kingTo != null) {
                return name(kingFrom) + name(kingTo)
            }
            return null
        }
        // взятие на проходе: ушли две фигуры, пришла одна
        if (gone.size == 2 && appeared.size == 1) {
            val pawnFrom = gone.firstOrNull { old[it] != 0 && Piece.type(old[it]) == Piece.PAWN }
            if (pawnFrom != null) return name(pawnFrom) + name(appeared[0])
        }
        return null
    }

    fun applyMove(pos: Position, uci: String) {
        val from = sq(uci.substring(0, 2))
        val to = sq(uci.substring(2, 4))
        val promo = if (uci.length == 5) uci[4] else null
        val piece = pos.cells[from]
        if (piece == 0) return
        val type = Piece.type(piece)
        val color = Piece.color(piece)

        // взятие на проходе
        if (type == Piece.PAWN && (from and 7) != (to and 7) && pos.cells[to] == 0) {
            val capFile = to and 7
            val capRank = from ushr 3
            pos.cells[capRank * 8 + capFile] = 0
        }

        pos.cells[from] = 0
        val placed = if (promo != null) {
            val t = when (promo) {
                'q' -> Piece.QUEEN
                'r' -> Piece.ROOK
                'b' -> Piece.BISHOP
                else -> Piece.KNIGHT
            }
            Piece.of(t, color)
        } else piece
        pos.cells[to] = placed

        // рокировка: двигаем ладью
        if (type == Piece.KING && kotlin.math.abs((to and 7) - (from and 7)) == 2) {
            if ((to and 7) == 6) { // g1/g8
                pos.cells[to - 1] = pos.cells[to + 1]
                pos.cells[to + 1] = 0
            } else { // c1/c8
                pos.cells[to + 1] = pos.cells[to - 2]
                pos.cells[to - 2] = 0
            }
        }

        // права на рокировку
        val c = pos.castling
        var rights = c
        if (type == Piece.KING) {
            rights = if (color == Piece.WHITE) rights.replace("K", "").replace("Q", "")
            else rights.replace("k", "").replace("q", "")
        }
        if (from == 7 || to == 7) rights = rights.replace("K", "")   // h1
        if (from == 0 || to == 0) rights = rights.replace("Q", "")   // a1
        if (from == 63 || to == 63) rights = rights.replace("k", "") // h8
        if (from == 56 || to == 56) rights = rights.replace("q", "") // a8
        pos.castling = if (rights.isEmpty()) "-" else rights

        pos.whiteToMove = !pos.whiteToMove
    }

    private fun name(sq: Int): String = Square.name(sq)

    private fun sq(s: String): Int {
        val file = s[0] - 'a'
        val rank = s[1] - '1'
        return rank * 8 + file
    }

    val fen: String get() = position?.fen() ?: "-"
}
